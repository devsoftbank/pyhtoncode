-- MySQL dump 10.13  Distrib 5.5.53, for Win32 (AMD64)
--
-- Host: localhost    Database: it_db
-- ------------------------------------------------------
-- Server version	5.5.53

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attach`
--

DROP TABLE IF EXISTS `attach`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attach` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `ext` varchar(255) DEFAULT NULL,
  `save_name` varchar(255) DEFAULT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `table_id` int(11) DEFAULT NULL,
  `upload_time` datetime DEFAULT NULL,
  `upload_user` int(11) DEFAULT NULL,
  `del_time` datetime DEFAULT NULL,
  `del_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attach`
--

LOCK TABLES `attach` WRITE;
/*!40000 ALTER TABLE `attach` DISABLE KEYS */;
/*!40000 ALTER TABLE `attach` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hr_dep`
--

DROP TABLE IF EXISTS `hr_dep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hr_dep` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `input_status` tinyint(1) NOT NULL DEFAULT '-1',
  `name` varchar(255) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `parent_ids` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hr_dep`
--

LOCK TABLES `hr_dep` WRITE;
/*!40000 ALTER TABLE `hr_dep` DISABLE KEYS */;
/*!40000 ALTER TABLE `hr_dep` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hr_employee`
--

DROP TABLE IF EXISTS `hr_employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hr_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `input_status` tinyint(1) NOT NULL DEFAULT '-1',
  `name` varchar(255) DEFAULT NULL,
  `no` varchar(255) DEFAULT NULL,
  `sex` tinyint(1) NOT NULL DEFAULT '0',
  `dep_id` int(11) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `is_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `create_user_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hr_employee`
--

LOCK TABLES `hr_employee` WRITE;
/*!40000 ALTER TABLE `hr_employee` DISABLE KEYS */;
/*!40000 ALTER TABLE `hr_employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `it_account`
--

DROP TABLE IF EXISTS `it_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `it_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `input_status` tinyint(1) NOT NULL DEFAULT '-1',
  `company_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `login_address` varchar(255) DEFAULT NULL,
  `account` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `attach_ids` varchar(255) DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `it_account`
--

LOCK TABLES `it_account` WRITE;
/*!40000 ALTER TABLE `it_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `it_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `it_asset`
--

DROP TABLE IF EXISTS `it_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `it_asset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `input_status` int(11) DEFAULT '-1',
  `company_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `no` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `diy_no` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `sn` varchar(255) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `amount` int(11) NOT NULL DEFAULT '0',
  `used` int(11) NOT NULL DEFAULT '0',
  `scrap_amount` int(11) NOT NULL DEFAULT '0',
  `inbound_date` date DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `use_dep_id` int(11) DEFAULT NULL,
  `use_employee_id` int(11) DEFAULT NULL,
  `is_repair` tinyint(1) NOT NULL DEFAULT '0',
  `stock_warning_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `submit_time` datetime DEFAULT NULL,
  `attach_ids` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `it_asset`
--

LOCK TABLES `it_asset` WRITE;
/*!40000 ALTER TABLE `it_asset` DISABLE KEYS */;
/*!40000 ALTER TABLE `it_asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `it_asset_repair_record`
--

DROP TABLE IF EXISTS `it_asset_repair_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `it_asset_repair_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `input_status` int(11) DEFAULT '-1',
  `asset_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `repair_date` date DEFAULT NULL,
  `finish_date` date DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '维修状态',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `create_time` datetime DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `it_asset_repair_record`
--

LOCK TABLES `it_asset_repair_record` WRITE;
/*!40000 ALTER TABLE `it_asset_repair_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `it_asset_repair_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `it_asset_scrap_record`
--

DROP TABLE IF EXISTS `it_asset_scrap_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `it_asset_scrap_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `input_status` int(11) NOT NULL DEFAULT '-1',
  `asset_id` int(11) DEFAULT NULL,
  `scrap_date` date DEFAULT NULL,
  `amount` int(11) NOT NULL DEFAULT '0',
  `reason` varchar(255) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `it_asset_scrap_record`
--

LOCK TABLES `it_asset_scrap_record` WRITE;
/*!40000 ALTER TABLE `it_asset_scrap_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `it_asset_scrap_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `it_asset_stock_warning`
--

DROP TABLE IF EXISTS `it_asset_stock_warning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `it_asset_stock_warning` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `input_status` tinyint(4) NOT NULL DEFAULT '-1',
  `name` varchar(255) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `warning_value` int(11) NOT NULL DEFAULT '0',
  `remarks` varchar(255) DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `it_asset_stock_warning`
--

LOCK TABLES `it_asset_stock_warning` WRITE;
/*!40000 ALTER TABLE `it_asset_stock_warning` DISABLE KEYS */;
/*!40000 ALTER TABLE `it_asset_stock_warning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `it_asset_type`
--

DROP TABLE IF EXISTS `it_asset_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `it_asset_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `input_status` tinyint(1) NOT NULL DEFAULT '-1',
  `name` varchar(255) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `parent_ids` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `it_asset_type`
--

LOCK TABLES `it_asset_type` WRITE;
/*!40000 ALTER TABLE `it_asset_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `it_asset_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `it_asset_use_record`
--

DROP TABLE IF EXISTS `it_asset_use_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `it_asset_use_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `input_status` int(11) NOT NULL DEFAULT '-1',
  `no` varchar(255) DEFAULT NULL,
  `record_type` varchar(10) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `record_date` date DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `employee_name` varchar(255) DEFAULT NULL,
  `dep_name` varchar(255) DEFAULT NULL,
  `dep_id` int(11) DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `amount` int(11) NOT NULL DEFAULT '0',
  `place` varchar(255) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `submit_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `it_asset_use_record`
--

LOCK TABLES `it_asset_use_record` WRITE;
/*!40000 ALTER TABLE `it_asset_use_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `it_asset_use_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `it_asset_use_record_detail`
--

DROP TABLE IF EXISTS `it_asset_use_record_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `it_asset_use_record_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) DEFAULT NULL,
  `amount` int(11) NOT NULL DEFAULT '0',
  `employee_id` int(11) DEFAULT NULL,
  `dep_id` int(11) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `detail_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `it_asset_use_record_detail`
--

LOCK TABLES `it_asset_use_record_detail` WRITE;
/*!40000 ALTER TABLE `it_asset_use_record_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `it_asset_use_record_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `it_contract`
--

DROP TABLE IF EXISTS `it_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `it_contract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `input_status` tinyint(1) NOT NULL DEFAULT '-1',
  `no` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `sign_date` date DEFAULT NULL,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `is_remind` tinyint(1) NOT NULL DEFAULT '0',
  `attach_ids` varchar(255) DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `it_contract`
--

LOCK TABLES `it_contract` WRITE;
/*!40000 ALTER TABLE `it_contract` DISABLE KEYS */;
/*!40000 ALTER TABLE `it_contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `it_contract_pay_record`
--

DROP TABLE IF EXISTS `it_contract_pay_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `it_contract_pay_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contract_id` int(11) DEFAULT NULL,
  `pay_date` date DEFAULT NULL,
  `pay_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `remarks` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `it_contract_pay_record`
--

LOCK TABLES `it_contract_pay_record` WRITE;
/*!40000 ALTER TABLE `it_contract_pay_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `it_contract_pay_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `it_network`
--

DROP TABLE IF EXISTS `it_network`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `it_network` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `input_status` tinyint(1) NOT NULL DEFAULT '-1',
  `company_id` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `parent_ids` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `admin_address` varchar(255) DEFAULT NULL,
  `account` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `it_network`
--

LOCK TABLES `it_network` WRITE;
/*!40000 ALTER TABLE `it_network` DISABLE KEYS */;
/*!40000 ALTER TABLE `it_network` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `it_supplier`
--

DROP TABLE IF EXISTS `it_supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `it_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `input_status` tinyint(1) NOT NULL DEFAULT '-1',
  `company_id` int(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contacts` varchar(255) DEFAULT NULL,
  `bank` varchar(255) DEFAULT NULL,
  `supplier_type` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `attach_ids` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `it_supplier`
--

LOCK TABLES `it_supplier` WRITE;
/*!40000 ALTER TABLE `it_supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `it_supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_company`
--

DROP TABLE IF EXISTS `sys_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `is_disabled` int(1) DEFAULT '0',
  `create_user_name` varchar(255) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `settlement_price_total` decimal(10,2) NOT NULL,
  `payment_price_total` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_company`
--

LOCK TABLES `sys_company` WRITE;
/*!40000 ALTER TABLE `sys_company` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_config`
--

DROP TABLE IF EXISTS `sys_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_config` (
  `key` varchar(255) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_config`
--

LOCK TABLES `sys_config` WRITE;
/*!40000 ALTER TABLE `sys_config` DISABLE KEYS */;
INSERT INTO `sys_config` VALUES ('company_name','菜工集团','公司名称，显示在底部'),('login','on','系统能否登录，开启是on，关闭是off，登录关闭后只能用超级用户登录'),('m_version','20190202001','手机端版本号'),('system_title','IT部门信息管理系统','系统标题，包括网页的标题，及登录页上面的名称'),('version','20190219001','PC端网页版本号');
/*!40000 ALTER TABLE `sys_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_factory`
--

DROP TABLE IF EXISTS `sys_factory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_factory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `is_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_factory`
--

LOCK TABLES `sys_factory` WRITE;
/*!40000 ALTER TABLE `sys_factory` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_factory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_mail`
--

DROP TABLE IF EXISTS `sys_mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_mail` (
  `id` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `smtp_host` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `port` varchar(255) DEFAULT NULL,
  `is_ssl` tinyint(1) NOT NULL DEFAULT '0',
  `sender_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_mail`
--

LOCK TABLES `sys_mail` WRITE;
/*!40000 ALTER TABLE `sys_mail` DISABLE KEYS */;
INSERT INTO `sys_mail` VALUES ('DEFAULT','59001731@qq.com','smtp.qq.com','','','',0,'IT中心');
/*!40000 ALTER TABLE `sys_mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_mail_template`
--

DROP TABLE IF EXISTS `sys_mail_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_mail_template` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title_template` varchar(255) DEFAULT NULL,
  `content_template` text,
  `is_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `tips` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_mail_template`
--

LOCK TABLES `sys_mail_template` WRITE;
/*!40000 ALTER TABLE `sys_mail_template` DISABLE KEYS */;
INSERT INTO `sys_mail_template` VALUES ('IT_ASSET_USE','IT资产领用后给领用员工发送邮件','IT资产领用通知[[no]]','[user]，您好，您于 [date] 领用了以下IT资产，请您确认。\n领用单编号：[no]\n使用地点：[place]\n备注：[remarks]\n[asset_list]\n如不是您本人领用，请及时与IT中心联系。',0,'[no]：领用单编号\r\n[user]：领用员工姓名\r\n[date]：代表领用日期\r\n[place]：使用地点\r\n[remarks]：领用备注\r\n[asset_list]：领用的资产列表'),('IT_ASSET_RETURN','IT资产交还后给交还员工发送邮件','IT资产交还通知[[no]]','[user]，您好，您于 [date] 交还了以下IT资产，请您确认。\n交还单编号：[no]\n归还地点：[place]\n备注：[remarks]\n[asset_list]\n如不是您本人交还的，请及时与IT中心联系。',0,'[no]：交还单编号\r\n[user]：交还员工姓名\r\n[date]：交还日期\r\n[place]：归还地点\r\n[remarks]：领用备注\r\n[asset_list]：交还的资产列表');
/*!40000 ALTER TABLE `sys_mail_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_menu`
--

DROP TABLE IF EXISTS `sys_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `parent_ids` varchar(255) DEFAULT NULL,
  `is_hidden` tinyint(1) DEFAULT NULL COMMENT '是否隐藏',
  `order` int(11) NOT NULL DEFAULT '99',
  `api` varchar(255) DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_menu`
--

LOCK TABLES `sys_menu` WRITE;
/*!40000 ALTER TABLE `sys_menu` DISABLE KEYS */;
INSERT INTO `sys_menu` VALUES (39,'IT中心','it',NULL,NULL,NULL,NULL,1,'',NULL,NULL,NULL,-1,'2019-02-10 18:43:24'),(150,'IT资产','asset',NULL,39,'39',NULL,1,'',NULL,NULL,NULL,-1,'2019-02-10 18:43:19'),(151,'资产管理','edit',NULL,150,'39,150',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),(152,'资产统计','statistic',NULL,150,'39,150',NULL,7,'',NULL,NULL,NULL,-1,'2019-02-10 18:43:32'),(153,'时段统计','time',NULL,152,'39,150,152',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),(154,'资产领用','use',NULL,150,'39,150',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL),(155,'资产交还','return',NULL,150,'39,150',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL),(156,'资产维修','repair',NULL,150,'39,150',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL),(157,'资产报废','scrap',NULL,150,'39,150',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL),(158,'资产查询','query',NULL,150,'39,150',NULL,6,'',NULL,NULL,NULL,-1,'2019-02-10 18:43:29'),(159,'领用状态列表','useStatus',NULL,158,'39,150,158',NULL,3,'',NULL,NULL,NULL,-1,'2019-01-30 13:47:11'),(160,'人力资源','hr',NULL,NULL,NULL,NULL,2,'',NULL,NULL,NULL,-1,'2019-02-10 18:44:33'),(161,'部门管理','dep',NULL,160,'160',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),(162,'员工管理','employee',NULL,160,'160',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL),(163,'资产类型管理','type',NULL,150,'39,150',NULL,8,NULL,NULL,NULL,NULL,NULL,NULL),(164,'合同管理','contract',NULL,39,'39',NULL,3,'',NULL,NULL,NULL,-1,'2019-02-10 18:44:14'),(165,'账号管理','account',NULL,39,'39',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL),(166,'网络结构','network',NULL,39,'39',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL),(167,'供应合作商','supplier',NULL,39,'39',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL),(168,'系统设置','sys',NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,NULL,-1,'2019-01-25 21:58:01'),(169,'用户管理','user',NULL,168,'168',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),(170,'角色管理','role',NULL,168,'168',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL),(171,'菜单管理','menu',NULL,168,'168',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL),(172,'公司管理','company',NULL,168,'168',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL),(173,'系统参数','config',NULL,168,'168',NULL,6,NULL,NULL,NULL,NULL,12,'2019-01-24 10:59:19'),(174,'系统更新记录','updateRecord',NULL,168,'168',NULL,8,'',NULL,NULL,NULL,-1,'2019-02-03 20:00:26'),(175,'库存预警','stockWarning',NULL,150,'39,150',NULL,9,NULL,NULL,NULL,NULL,NULL,NULL),(181,'IT资产查询','asset',NULL,158,'39,150,158',NULL,1,NULL,'超级用户',-1,'2019-01-30 13:46:46',-1,'2019-01-30 13:46:46'),(182,'领用交还明细','useReturn',NULL,158,'39,150,158',NULL,2,'','超级用户',-1,'2019-01-30 13:47:04',-1,'2019-01-30 13:47:16'),(183,'合同录入','edit',NULL,164,'39,164',NULL,1,NULL,'超级用户',-1,'2019-02-01 13:05:09',-1,'2019-02-01 13:05:09'),(184,'合同付款','pay',NULL,164,'39,164',NULL,2,NULL,'超级用户',-1,'2019-02-01 13:05:46',-1,'2019-02-01 13:05:46'),(185,'查询','query',NULL,164,'39,164',NULL,3,NULL,'超级用户',-1,'2019-02-01 13:05:56',-1,'2019-02-01 13:05:56'),(186,'合同查询','contract',NULL,185,'39,164,185',NULL,1,NULL,'超级用户',-1,'2019-02-01 13:06:06',-1,'2019-02-01 13:06:06'),(187,'合同付款明细','pay',NULL,185,'39,164,185',NULL,2,NULL,'超级用户',-1,'2019-02-01 13:06:15',-1,'2019-02-01 13:06:15'),(188,'统计','statistic',NULL,164,'39,164',NULL,4,NULL,'超级用户',-1,'2019-02-01 13:06:24',-1,'2019-02-01 13:06:24'),(189,'合同统计','contract',NULL,188,'39,164,188',NULL,1,'','超级用户',-1,'2019-02-01 13:06:35',-1,'2019-02-01 22:43:00'),(190,'合同付款统计','pay',NULL,188,'39,164,188',NULL,2,'','超级用户',-1,'2019-02-01 13:06:48',-1,'2019-02-01 22:42:24'),(191,'邮件通知设置','mail',NULL,168,'168',NULL,7,NULL,'超级用户',-1,'2019-02-03 20:00:18',-1,'2019-02-03 20:00:18');
/*!40000 ALTER TABLE `sys_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_message`
--

DROP TABLE IF EXISTS `sys_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `is_disabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_message`
--

LOCK TABLES `sys_message` WRITE;
/*!40000 ALTER TABLE `sys_message` DISABLE KEYS */;
INSERT INTO `sys_message` VALUES (1,'IT_ASSET_CREATE','','IT资产入库',1),(2,'IT_CONTRACT_CREATE','','IT部门合同创建',1);
/*!40000 ALTER TABLE `sys_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role`
--

DROP TABLE IF EXISTS `sys_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `menu_ids` varchar(255) DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role`
--

LOCK TABLES `sys_role` WRITE;
/*!40000 ALTER TABLE `sys_role` DISABLE KEYS */;
INSERT INTO `sys_role` VALUES (-1,'超级角色','系统内置的超级角色，拥有全部菜单，禁止修改删除！','*',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sys_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_update_record`
--

DROP TABLE IF EXISTS `sys_update_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_update_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `input_status` tinyint(1) NOT NULL DEFAULT '-1',
  `title` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `update_date` date DEFAULT NULL,
  `attach_ids` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_update_record`
--

LOCK TABLES `sys_update_record` WRITE;
/*!40000 ALTER TABLE `sys_update_record` DISABLE KEYS */;
INSERT INTO `sys_update_record` VALUES (63,0,'增加IT中心功能','增加IT中心的IT资产入库、领用交还单、维修、报废功能',NULL,'2019-01-15',NULL,'2019-01-25 09:07:46','蔡锦钿',12,12,'2019-01-25 09:08:21'),(64,0,'增加IT中心功能','增加IT中心的网络结构管理、账号管理、供应商管理功能',NULL,'2019-01-18',NULL,'2019-01-25 09:09:02','蔡锦钿',12,12,'2019-01-25 09:09:02'),(65,0,'增加IT中心功能','增加IT中心的合同管理功能',NULL,'2019-01-20',NULL,'2019-01-25 09:09:27','蔡锦钿',12,12,'2019-01-25 09:09:27'),(66,0,'增加IT中心功能','增加IT中心的库存预警功能',NULL,'2019-01-22',NULL,'2019-01-25 09:09:53','蔡锦钿',12,12,'2019-01-25 09:10:03'),(67,0,'增加系统设置功能','增加系统设置的用户管理、角色管理、菜单管理、工厂管理、公司管理、系统参数、系统更新记录管理功能',NULL,'2019-01-24',NULL,'2019-01-25 09:10:40','蔡锦钿',12,12,'2019-01-25 09:10:40'),(68,0,'增加系统权限控制','增加了对后台api调用的验证，可在菜单管理中增加对应的api接口，增加的api接口，会在调用时进行验证用户是否具有该菜单的权限',NULL,'2019-01-28',NULL,'2019-01-30 15:04:19','超级用户',-1,-1,'2019-01-30 15:04:19'),(69,0,'优化IT中心首页','增加了IT中心首页的近期领用、资产维修、库存预警、近期合同、即将到期合同的提示。',NULL,'2019-01-30',NULL,'2019-01-30 15:05:19','超级用户',-1,-1,'2019-01-30 15:05:19'),(70,0,'增加邮件通知功能','增加IT资产领用交还后对领用或交还人进行邮件的提醒功能。',NULL,'2019-02-03',NULL,'2019-02-03 20:19:56','超级用户',-1,-1,'2019-02-03 20:19:56'),(71,-1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,-1,NULL,NULL);
/*!40000 ALTER TABLE `sys_update_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user`
--

DROP TABLE IF EXISTS `sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_name` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `name2` varchar(255) DEFAULT NULL,
  `pwd` varchar(255) DEFAULT NULL,
  `employee` varchar(255) DEFAULT NULL,
  `last_login_time` datetime DEFAULT NULL COMMENT '最近一次登录时间',
  `qywx_user` varchar(255) DEFAULT NULL,
  `role_ids` varchar(255) DEFAULT NULL,
  `company_ids` varchar(255) DEFAULT NULL,
  `area_ids` varchar(255) DEFAULT NULL,
  `factory_ids` varchar(255) DEFAULT NULL,
  `type_ids` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `create_user_name` varchar(255) DEFAULT NULL,
  `update_user_id` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login_name` (`login_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user`
--

LOCK TABLES `sys_user` WRITE;
/*!40000 ALTER TABLE `sys_user` DISABLE KEYS */;
INSERT INTO `sys_user` VALUES (-1,'admin','超级用户',NULL,'123456',NULL,'2019-03-25 12:36:36',NULL,'-1','*','*','*','*',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sys_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_login_log`
--

DROP TABLE IF EXISTS `sys_user_login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_user_login_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `login_time` datetime DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_login_log`
--

LOCK TABLES `sys_user_login_log` WRITE;
/*!40000 ALTER TABLE `sys_user_login_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_user_login_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-25 17:07:09
