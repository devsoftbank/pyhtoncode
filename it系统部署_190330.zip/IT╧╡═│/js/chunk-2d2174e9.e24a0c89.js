(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-2d2174e9"],{c5bc:function(p,c,n){p.exports=n.p+"img/wx.a0170fc8.jpg"}}]);
//# sourceMappingURL=chunk-2d2174e9.e24a0c89.js.map