(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-2d0ab82b"],{"161a":function(p,n,o){p.exports=o.p+"img/img2.631c7066.jpg"}}]);
//# sourceMappingURL=chunk-2d0ab82b.ac46035b.js.map