(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-2d0f0bd0"],{"9e3a":function(p,n,w){p.exports=w.p+"img/wx.a0170fc8.jpg"}}]);
//# sourceMappingURL=chunk-2d0f0bd0.c26b9e3e.js.map