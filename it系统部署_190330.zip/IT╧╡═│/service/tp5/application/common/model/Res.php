<?php
namespace app\common\model;

class Res{
	public $success = true;
	public $data;
	public $total;
	public $message='';
	public $msg;
	public $custom;
	public $code=-1;
}