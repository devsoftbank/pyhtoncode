<?php
namespace app\api\controller;
use think\Db;
use app\api\controller\Auth;

class UpdateRecord extends Auth {

	private $tableName = 'sys_update_record';

	/**
	* 获取商务成本报告列表
	* @param 
	*/
	public function getList($currentPage,$pageSize) {
		$res=model('Res');
		try{
			$where = [];
			$keyword = input('get.keyword');
			if($keyword) {
				$where['title|content'] = ['like','%'.$keyword.'%'];
			}		

			$data['list']=Db::table($this->tableName)
				->where($where)
				->order('update_date desc')
				->page($currentPage,$pageSize)
				->select();
			$data['total']=Db::table($this->tableName)
				->where($where)
				->count();
			$res->data = $data;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}
}
