<?php
namespace app\api\controller;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use think\Db;

//登录验证基类
class Test {
	public function index(){
		// return '123';
		$spreadsheet = new Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();
		$sheet->setCellValue('A1', 'Hello World !');
		//告诉浏览器输出07Excel文件
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		//header('Content-Type:application/vnd.ms-excel');//告诉浏览器将要输出Excel03版本文件
		header('Content-Disposition: attachment;filename="01simple.xlsx"');;//告诉浏览器输出浏览器名称
		header('Cache-Control: max-age=0');//禁止缓存
		$writer = new Xlsx($spreadsheet);
		$writer->save('php://output');

		exit;
	}

	public function test1(){
		Db::startTrans();
		$res=model('Res');
		try{
			$data = importExcel(2,['D']);
			$message = [];
			foreach($data as $d){
				$projectNo = $d[0];
				$project = Db::table('yyzx_project')->where('no',$projectNo)->find();
				if($project){
					$invoiceNo = $d[2];
					if(!$invoiceNo){
						continue;
					}
					$companyName = $d[1];
					$company = Db::table('yyzx_company')->where('name',$companyName)->find();

					$invoiceDate = $d[3];
					$invoicePrice = $d[4];
					$remarks = $d[5];
					$a=[
						'create_user'=>27,
						'update_user'=>27,
						'create_time'=>date('Y-m-d H:i:s'),
						'update_time'=>date('Y-m-d H:i:s'),
						'company_id'=>$company['id'],
						'project_id'=>$project['id'],
						'contract_id'=>$project['contract_id'],
						'invoice_no'=>$invoiceNo,
						'invoice_date'=>$invoiceDate,
						'invoice_price'=>$invoicePrice,
						'remarks'=>$remarks
					];
					Db::table('cw_invoice_record')->insert($a);
				}
			}
			Db::commit();
			$res->data = $message;
			$res->code = 0;
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);

	}

	public function test2(){
		Db::startTrans();
		$res=model('Res');
		try{
			$data = importExcel(2);
			$message = [];
			foreach($data as $d){
				$projectNo = $d[0];
				$project = Db::table('yyzx_project')->where('no',$projectNo)->find();
				if($project){
					$contractNo = $d[2];
					if($contractNo!=$project['contract_no']){
						$message[] = $project['no'].'合同号不一致';
					}
					$contract = Db::table('yyzx_contract')->where('contract_no',$contractNo)->find();

					$ccc = explode('-',$contractNo);
					$b=$ccc[1];
					$companyId;
					if($b=='TZ'){
						$companyId=32;
					}elseif($b=='SZXC'||$b=='SZXC(T）'){
						$companyId = 24;
					}elseif($b=='GD'){
						$companyId=31;
					}elseif($b=='SH'){
						$companyId=25;
					}elseif($b=='SZLJ'){
						$companyId=27;
					}
					$paymentDate = $d[6];
					$paymentPrice = $d[7];
					if(!$paymentPrice){
						continue;
					}
					$no_prefix = 'CWHK'.date('ym'); //编号前缀
					$last_no = Db::table( 'cw_receive_payment_record' )->where('no','like',$no_prefix.'%')->max("no",false);
					$no = $no_prefix.sprintf("%03d",substr($last_no,-3)+1);
					$fields=[
						'no','project_id','company_id','customer_id','payment_price','payment_currency','payment_date','currency_price',
						'payment_method','create_time','create_user','update_time','update_user'
					];
					$a=[
						'create_user'=>27,
						'update_user'=>27,
						'customer_id'=>$project['customer_id'],
						'create_time'=>date('Y-m-d H:i:s'),
						'payment_currency'=>'CNY',
						'update_time'=>date('Y-m-d H:i:s'),
						'company_id'=>$companyId,
						'project_id'=>$project['id'],
						'contract_id'=>$project['contract_id'],
						'no'=>$no,
						'payment_date'=>$paymentDate,
						'payment_price'=>$paymentPrice,
						'payment_method'=>'电汇'
					];
					Db::table('cw_receive_payment_record')->insert($a);
				}
			}
			Db::commit();
			$res->data = $message;
			$res->code = 0;
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}
	public function test3(){
		$orderList = Db::table('yyzx_order')->select();
		foreach ($orderList as $order) {
			Db::table('sc_product')->where('order_id',$order['id'])->select();
		}
	}

	public function test4(){
		$list = Db::table('sc_check_glass')->field('order_id,model,sn,width,height,no,produce_date,flow_no,count(*) as amount')->group('order_id,sn')->select();
		$insertData = [];
		foreach($list as $l){
			$insertData[] = $l;
		}
		Db::table('sc_glass')->insertAll($insertData);
	}

	public function test5(){
		Db::startTrans();
		set_time_limit(100);
		try{
			$list = Db::table('sc_check_glass')
				->alias('check')
				->field('check.code,glass.id glass_id,glass.order_id')
				->join('sc_glass glass','check.order_id = glass.order_id and check.sn=glass.sn')
				->select();
			$insertData = [];
			foreach($list as $l){
				$d['code'] = $l['code'];
				$d['glass_id'] = $l['glass_id'];
				$d['order_id'] = $l['order_id'];
				Db::table('sc_glass_code')->insert($d);
			}
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
		}		
	}
	public function test6(){
		$a = date('Y-m',strtotime('-6 month'));
		exit($a);
	}

	public function test7(){
		$a=[
			'a'=>[1],
			'b'=>2
		];
		$b = [
			'a'=>1,
			'c'=>4
		];
		dump($a+$b);
		exit;
	}

	public function test8(){
		$str = "w*h=500*600";
		$preg="/([\d]+)\*([\d]+)/is";
		if (preg_match($preg,$str,$arr)) {
		  echo "ok";
		  dump($arr);
		}else{
			echo '123';
		}		
		exit;
	}

	public function test9(){
		$str = "w*h=(500+1）*(600+500";
		// $preg="/\([\d]+[\+[\d]+]+\)\*([\d]+)/i";
		$preg="/(?<w>[\d]+(\+[\d]+)*)[\)）]?\*[\(（]?(?<h>[\d]+(\+[\d]+)*)\)?/iu";
mb_regex_encoding('utf-8');
		if (preg_match($preg,$str,$arr)) {
		  echo "ok";
		  dump($arr);
		  dump($arr['w']);
		  $arr['w'];
		  $a = array_sum(explode('+', $arr['w']));
		  // $a = eval($arr['w'].';');
		  dump($a);
		  dump($arr['h']);
		}else{
			echo '123';
		}		
		exit;
	}

	public function test10(){
		$str = "1";
		$preg="/1[abcd]?/is";
		if (preg_match($preg,$str,$arr)) {
		  echo "ok";
		  dump($arr);
		}else{
			echo '123';
		}		
		exit;
	}

	public function test12($id){
		$r = request();
		dump($r);
		dump($r->controller());
		dump($r->action());
		return '';

	}

	public function test13(){
		set_time_limit(0);
		Db::startTrans();
		try{
			$list = Db::table('it_asset_use_record')->where('id','>=',3114)->select();
			foreach ($list as $item) {
				$data = [
					'record_id' => $item['id'],
					'asset_id' => $item['asset_id'],
					'employee_id'=>$item['employee_id'],
					'dep_id'=>$item['dep_id'],
					'amount'=>$item['amount']
				];
				Db::table('it_asset_use_record_detail')->insert($data);	
			}
			Db::commit();
			return 'ok';
		}catch(\Exception $e){
			Db::rollback();
			return 'fail';
		}
	}

	public function test14(){
		set_time_limit(0);
		Db::startTrans();
		try{
			$list = Db::table('it_asset_use_record')->where('state',2)->select();
			foreach ($list as $item) {
				$data1 = [
					'asset_id'=>$item['asset_id'],
					'scrap_date'=>$item['return_time'],
					'reason'=>$item['return_remarks'],
					'company_id'=>31,
					'input_status'=>0,
					'amount'=>$item['amount'],
					'create_time'=>$item['return_time']
				];
				$id = Db::table('it_asset_scrap_record')->insertGetId($data1);	
				// $detailId = Db::table('it_asset_scrap_record')->where('record_id',$item['id'])->value('id');
				// $data = [
				// 	'record_id' => $id,
				// 	'asset_id' => $item['asset_id'],
				// 	'employee_id'=>$item['employee_id'],
				// 	'dep_id'=>$item['dep_id'],
				// 	'detail_id'=>$detailId,
				// 	'amount'=>$item['amount']
				// ];
				// Db::table('it_asset_use_record_detail')->insert($data);	
			}
			Db::commit();
			return 'ok';
		}catch(\Exception $e){
			Db::rollback();
			return 'fail';
		}
	}

	public function test15(){
		set_time_limit(0);
		Db::startTrans();
		try{
			$list = Db::table('it_asset')->where('used','>',0)->select();
			foreach ($list as $item) {
				$d = Db::table('it_asset_use_record_detail')
					->alias('d')
					->field('d.*')
					->join('it_asset_use_record r','r.id=d.record_id')
					->where('d.asset_id',$item['id'])
					->order('r.submit_time desc')
					->find();
				if($d['detail_id']==null){
					Db::table('it_asset')->where('id',$item['id'])->update([
						'use_dep_id'=>$d['dep_id'],
						'use_employee_id'=>$d['employee_id'],
					]);
				}
				// $detailId = Db::table('it_asset_scrap_record')->where('record_id',$item['id'])->value('id');
				// $data = [
				// 	'record_id' => $id,
				// 	'asset_id' => $item['asset_id'],
				// 	'employee_id'=>$item['employee_id'],
				// 	'dep_id'=>$item['dep_id'],
				// 	'detail_id'=>$detailId,
				// 	'amount'=>$item['amount']
				// ];
				// Db::table('it_asset_use_record_detail')->insert($data);	
			}
			Db::commit();
			return 'ok';
		}catch(\Exception $e){
			Db::rollback();
			return 'fail';
		}
	}
}