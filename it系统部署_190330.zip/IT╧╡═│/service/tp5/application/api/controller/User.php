<?php
namespace app\api\controller;
use think\Db;
use app\api\controller\Auth;
//登录验证基类
class User extends Auth {
	public function getUserInfo() {
		$res=model('Res');
		try{
			if($this->userId!=-1){
				$value = Db::table('sys_config')->where('key','login')->value('value');
				if($value=='off'){
					// $res->code=0;
					throw new \Exception('升级正在升级中，暂时无法登录。');
				}
			}
			$user = Db::table('sys_user')->find($this->userId);
			$fields = [
				'm1.id',
				'm1.title',
				'm1.path',
				'm1.parent_id'
			];
			if(in_array('-1',explode(',',$user['role_ids']))){
				$menuList = Db::table('sys_menu')
					->alias('m1')
					->field($fields)
					->order('m1.order')
					->select();
			}else{
				$menuIds = Db::table('sys_role')->where('id','in',$user['role_ids'])->column('menu_ids');
				$menuIds = array_unique(explode(',',implode(',',$menuIds)));
				$menuList=Db::table('sys_menu')
					->alias('m1')					
					->distinct(true)
					->field($fields)
					->join('sys_menu m2','FIND_IN_SET(m1.id,concat(m2.parent_ids,",",m2.id))')
					->where('m2.id','in',$menuIds)
					->order('m1.order')
					->select();		
			}
			// if(in_array('*',$menuIds)){
			// 	//超级权限
			// 	$menuList = Db::table('sys_menu')
			// 		->alias('m1')
			// 		->field($fields)
			// 		->order('m1.order')
			// 		->select();
			// }else{
						
			// }
			$res->data = [
				'userid'=>$this->userId,
				'username'=>$user['name'],
				'menuList' => $menuList
			];
			$res->code=0;
		}catch(\Exception $e){
			$res->message = $e->getMessage();
		}
		return json($res);
	}
}