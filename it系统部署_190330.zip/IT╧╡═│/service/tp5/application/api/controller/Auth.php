<?php
namespace app\api\controller;
use think\Controller;
use think\Db;
//登录验证基类
class Auth extends Controller{
	protected $user_id;
	protected $userId;
	protected $name;
	public function _initialize(){
		//这里写登录验证代码		
		if(session('?user_id')){
			$this->user_id = session('user_id');
			$this->userId = session('user_id');
			$apiUrl = '/'. request()->path();
			if(Db::table('sys_menu')->where('FIND_IN_SET("'.$apiUrl.'",replace(api,"\n",","))')->count()>0){
				$roleIds = Db::table('sys_user')->where('id',$this->userId)->value('role_ids');
				if(!in_array('-1',explode(',',$roleIds))){
					$menuIds = Db::table('sys_role')->where('id','in',$roleIds)->column('menu_ids');
					$menuIds = array_unique(explode(',',implode(',',$menuIds)));
					if(Db::table('sys_menu')->where('id','in',$menuIds)->where('FIND_IN_SET("'.$apiUrl.'",replace(api,"\n",","))')->count()==0){
						//没有权限		
						$res=model('Res');		 		
						$res->code=40002;
						$res->success=false;
						$res->message='您没有权限进行此操作！';
						exit(json_encode($res));
					}else{
						// exit('123');
					}
				}
			}
		}else{
			//未登录		
			$res=model('Res');		 		
			$res->code=40001;
			$res->success=false;
			$res->message='登录超时，请重新登录';
			exit(json_encode($res));
		}
	}
}