<?php
namespace app\api\controller\sys;
use think\Db;
use think\Controller;

class ConfigNoAuth extends Controller {

	private $tableName = 'sys_config';

	/**
	* 获取系统设置的某个值
	* @param 
	*/
	public function getValue($key) {
		$res=model('Res');
		try{
			$value = Db::table($this->tableName)->where('key',$key)->value('value');

			$res->data = $value;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 获取系统设置的某个值
	* @param 
	*/
	public function getValues($keys) {
		$res=model('Res');
		try{
			$values = Db::table($this->tableName)->where('key','in',$keys)->column('value','key');

			$res->data = $values;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

}