<?php
namespace app\api\controller\sys;
use think\Db;
use app\api\controller\Auth;

//
class Mail extends Auth{

	private $tableName = 'sys_mail_template';

	private function getWhere(){
		return function($query){
			//
			$name=input("name");
			if($name){
				$query->where('template.name','like','%'.$name.'%');
			}
		};
	}
			
	/*
	* 获取列表
	* 
	*/
	public function getList($currentPage=1,$pageSize=10,$noPage=0){
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$order = [];
			$sortProp=input('get.sortProp');
			if($sortProp){
				$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
			}else{
				$order['template.id'] = 'desc';
			}
			$fields = [
				'template.*'
			];
			$sql = Db::table( $this->tableName )
				->alias('template')
				->field($fields)
				->where($where)
				->order($order);
			if($noPage){
				$list = $sql->select();
				$total = count($list);
			}else{
				$list = $sql->page($currentPage,$pageSize)->select();	
				$total = Db::table( $this->tableName )
					->alias('template')					
					->where($where)
					->count();
			}
			$data['list'] = $list;
			$data['total'] = $total;					
			$res->data=$data;	
			$res->code = 0;
		}catch(\Exception $e){
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 创建或更新
	* @param 
	*/
	public function save() {
		$res=model('Res');
		Db::startTrans();
		try{
			$data = []; 
			$fields=[
				'is_disabled','title_template','content_template'
			];
			$now = date('Y-m-d H:i:s');
			$post=input('post.');
			if(!$post['id']){				
				$post['id']=Db::table($this->tableName)->field($fields)->insertGetId($post);
			}else{
				$data = Db::table($this->tableName)->find($post['id']);
				if(!$data){
					throw new \Exception('找不到该公司信息！');
				}
				Db::table($this->tableName)->field($fields)->update($post);
			}
			$data = array_merge($data,$post);
			$res->data = [
				'id'=>$data['id']
			];
			$res->code=0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message = $e->getMessage();
		}
		return json($res);
	}

	/*
	* 删除
	*/
	public function getMailDetails($id){
		$res=model('Res');
		try{
			$mail = Db::table('sys_mail')->where('id',$id)->find();
			$res->data = $mail;
			$res->code = 0;
		}catch(\Exception $e){
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 创建或更新
	* @param 
	*/
	public function saveMail() {
		$res=model('Res');
		Db::startTrans();
		try{
			$data = []; 
			$fields=[
				'mail','sender_name','smtp_host','is_ssl','port','user_name','password'
			];
			$post=input('post.');
			sendMail($post,[
				'mail'=>$post['mail'],
				'title'=>'测试邮件',
				'content'=>'这是由IT部门信息管理系统发送的一封测试邮件'
			]);
			if(!$post['id']){
				$post['id']=Db::table('sys_mail')->field($fields)->insertGetId($post);
			}else{
				$data = Db::table('sys_mail')->find($post['id']);
				if(!$data){
					throw new \Exception('找不到该邮箱信息！');
				}
				Db::table('sys_mail')->field($fields)->update($post);
			}
			$data = array_merge($data,$post);
			$res->data = [
				'id'=>$data['id']
			];
			$res->code=0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message = $e->getMessage();
		}
		return json($res);
	}

	/*
	* 删除
	*/
	public function del($id){
		$res=model('Res');
		Db::startTrans();
		try{			
			$company = Db::table($this->tableName)->find($id);
			if(!$company){
				throw new \Exception('找不到该公司信息！');
			}
			Db::table( $this->tableName )->delete($id);
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}
	/**
	* 检查名称唯一性
	* @param 
	*/
	public function checkNameUnique($name,$id=null) {
		$res=model('Res');
		try{
			$where = [
				'name'=>$name
			];
			if($id){
				$where['id']=[ '<>', $id ];
			}
			$res->data = Db::table($this->tableName)->where($where)->count();
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}
}