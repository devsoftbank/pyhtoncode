<?php
namespace app\api\controller\sys;
use think\Db;
use app\api\controller\Auth;

class Config extends Auth {

	private $tableName = 'sys_config';
	private function getWhere(){
		return function($query){
			$key=input("key");
			if($key){
				$query->where('config.key','like','%'.$key.'%');
			}
		};
	}
	/**
	* 获取系统设置的某个值
	* @param 
	*/
	public function getValue($key) {
		$res=model('Res');
		try{
			$value = Db::table($this->tableName)->where('key',$key)->value('value');

			$res->data = $value;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/*
	* 获取列表
	* 
	*/
	public function getList($currentPage=1,$pageSize=10,$noPage=0){
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$order = [];
			$sortProp=input('get.sortProp');
			if($sortProp){
				$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
			}else{
				$order['key'] = 'desc';
			}
			$fields = [
				'config.*'
			];
			$sql = Db::table( $this->tableName )
				->alias('config')
				->field($fields)
				->where($where)
				->order($order);
			if($noPage){
				$list = $sql->select();
				$total = count($list);
			}else{
				$list = $sql->page($currentPage,$pageSize)->select();	
				$total = Db::table( $this->tableName )
					->alias('config')					
					->where($where)
					->count();
			}
			$data['list'] = $list;
			$data['total'] = $total;					
			$res->data=$data;	
			$res->code = 0;
		}catch(\Exception $e){
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 检查名称唯一性
	* @param 
	*/
	public function checkKeyUnique($key) {
		$res=model('Res');
		try{
			$where = [
				'key'=>$key
			];
			$res->data = Db::table($this->tableName)->where($where)->count();
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}


	/**
	* 创建或更新
	* @param 
	*/
	public function save($key) {
		$res=model('Res');
		Db::startTrans();
		try{
			$data = []; 
			$now = date('Y-m-d H:i:s');
			$post=input('post.');
			if($post['action']==0){
				Db::table($this->tableName)->insert($post);
			}else{
				$data = Db::table($this->tableName)->find($post['key']);
				if(!$data){
					throw new \Exception('找不到该参数信息！');
				}
				Db::table($this->tableName)->field('key',true)->update($post);
			}
			$res->code=0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message = $e->getMessage();
		}
		return json($res);
	}

	/*
	* 删除
	*/
	public function del($key){
		$res=model('Res');
		Db::startTrans();
		try{			
			$config = Db::table($this->tableName)->find($key);
			if(!$config){
				throw new \Exception('找不到该参数信息！');
			}
			Db::table( $this->tableName )->delete($key);
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}
}