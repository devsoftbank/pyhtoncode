<?php
namespace app\api\controller\sys;
use think\Db;
use app\api\controller\Auth;

//
class Role extends Auth{

	private $tableName = 'sys_role';

	private function getWhere(){
		return function($query){			
			$name = input("name");
			if($name){
				$query->where('role.name','like','%'.$name.'%');
			}
			$remarks = input("remarks");
			if($remarks){
				$query->where('role.remarks','like','%'.$remarks.'%');
			}
			//近期
			$isNear = input('get.isNear');
			if($isNear) {
				$nearDate = date('Y-m-d',strtotime('-10 days'));
				$query->where('asset.create_time','>=',$nearDate);
			}
		};
	}
			
	/*
	* 获取列表
	* 
	*/
	public function getList($currentPage=1,$pageSize=10,$noPage=0){
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$order = [];
			$sortProp=input('get.sortProp');
			if($sortProp){
				$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
			}else{
				$order['role.create_time'] = 'desc';
			}
			$fields = [
				'role.*'
			];
			$sql = Db::table( $this->tableName )
				->alias('role')
				->field($fields)
				->where($where)
				->order($order);
			if($noPage){
				$list = $sql->select();
				$total = count($list);
			}else{
				$list = $sql->page($currentPage,$pageSize)->select();	
				$total = Db::table( $this->tableName )
					->alias('role')					
					->where($where)
					->count();
			}
			$data['list'] = $list;
			$data['total'] = $total;					
			$res->data=$data;	
			$res->code = 0;
		}catch(\Exception $e){
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	
	/**
	* 根据记录id获取表单数据
	* @param 
	*/
	public function getForm($id) {
		$res=model('Res');
		try{
			$data = Db::table($this->tableName)
				->find($id);
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	

	/**
	* 创建或更新
	* @param 
	*/
	public function save() {
		$res=model('Res');
		Db::startTrans();
		try{
			$data = []; 
			$fields=[
				'name','remarks','menu_ids','update_time','update_user_id'
			];
			$now = date('Y-m-d H:i:s');
			$post=input('post.');
			$post['update_time'] = $now;
			$post['update_user_id'] = $this->user_id;
			if(!$post['id']){
				$fields[] = 'create_time';
				$fields[] = 'create_user_id';
				$fields[] = 'create_user_name';
				$post['create_time'] = $now;				 
				$post['create_user_id'] = $this->userId;				 
				$post['create_user_name'] = Db::table('sys_user')->where('id',$this->user_id)->value('name');
				$post['id']=Db::table($this->tableName)->field($fields)->insertGetId($post);
			}else{
				$data = Db::table($this->tableName)->find($post['id']);
				if(!$data){
					throw new \Exception('找不到该角色信息！');
				}
				if($data['id']==-1){
					throw new \Exception('该角色为系统超级角色，禁止修改！');
				}
				Db::table($this->tableName)->field($fields)->update($post);
			}
			$data = array_merge($data,$post);
			$res->data = [
				'id'=>$data['id']
			];
			$res->code=0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message = $e->getMessage();
		}
		return json($res);
	}

	/*
	* 删除
	*/
	public function del($id){
		$res=model('Res');
		Db::startTrans();
		try{
			if($id==-1){
				throw new \Exception('该角色为系统超级角色，禁止删除！');
			}
			$role = Db::table($this->tableName)->find($id);
			Db::table( $this->tableName )->delete($id);
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 根据记录id获取表单数据
	* @param 
	*/
	public function getSummaryData() {
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$data = Db::table( $this->tableName )
				->alias('car')
				->field([
					'count(*)'=>'car_total',
					'sum(amount_total)'=>'amount_total',
					'sum(area_total)'=>'area_total',
				])
				->join('yyzx_delivery_task task','car.task_id=task.id')
				->where($where)
				->where('car.input_status','>=',0)
				->find();
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 根据记录id获取
	* @param 
	*/
	public function getDetails($id) {
		$res=model('Res');
		try{
			$data = Db::table( $this->tableName )
				->alias('asset')
				->field([
					'asset.*',
					'asset.amount - asset.scrap_amount - asset.used'=>'remain',
					'asset.amount - asset.scrap_amount'=>'avaiable_amount'
				])
				->where('asset.id',$id)
				->find();
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 导出excel
	* @param 
	*/
	public function exportExcel(){
		$titles = [ 
			'no'=>'车辆编号',
			'status'=>'车辆状态',
			'task_no'=>'任务编号',
			'project' => '项目名称',//项目名称
			'contract_no' => '合同号',//客户名称
			'salesman_unit' => '销售公司',//业绩公司
			'salesman_name'=>'业务员',
			'salesman_tel'=>'业务员联系电话',
			'db_no'=>'调拨单号',
			'fh_no'=>'发货申请编号',
			'area_name'=>'发货工厂',
			'receive_unit'=>'收货单位',
			'receive_address'=>'收货地址',
			'receive_name'=>'收货人',
			'receive_tel'=>'收货人联系电话',
			'amount_total'=>'装车数量',
			'area_total'=>'装车面积（㎡）',
			'delivery_time'=>'发货时间',
			'receive_time'=>'签收时间',
			'review_time'=>'审核完成时间',
			'create_user_name'=>'录入员',
			'create_time'=>'创建时间',
			'submit_time'=>'提交时间',
		];		
		$where = $this->getWhere();
		$order = [];
		$sortProp=input('get.sortProp');
		if($sortProp){
			$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
		}else{
			$order['car.id'] = 'desc';
		}
		$fields = [
			'car.*',
			'task.no'=>'task_no',
			'task.area_name'=>'area_name',
			'task.project',
			'task.contract_no',
			'task.db_no',
			'task.fh_no',
			'task.salesman_unit',
			'task.salesman_name',
			'task.salesman_tel',
			'task.plan_send_date',
			'task.receive_unit',
			'task.method',
			'task.receive_address',
			'task.receive_name',
			'task.receive_tel'
		];
		$list = Db::table( $this->tableName )
			->alias('car')
			->field($fields)
			->join('yyzx_delivery_task task','car.task_id=task.id')
			->where($where)
			->where('car.input_status','>=',0)
			->order($order)
			->select();
		exportExcel($list,$titles,'发货车辆列表');
	}

	/**
	* 获取最近6个月的统计数据
	* @param 
	*/
	public function getNearMonthSummary(){
		$res = model('Res');
		try{
			$data=[];
			for($i=5;$i>=0;$i--){
				$m = date('n',strtotime('-'.$i.' month'));
				$d=[
					'month'=>$m.'月',
					'delivery_area'=>0,
					'receive_area'=>0,
					'finish_area'=>0
				];
				$data[]=$d;
			}
			$beginDate = date('Y-m-01',strtotime('-5 month'));
			
			$deliveryData = Db::table($this->tableName)
				->field([
					'month(delivery_time)'=>'m',
					'ifnull(sum(area_total),0)'=>'delivery_area',
				])
				->where('delivery_time','>=',$beginDate)
				->group('month(delivery_time)')
				->order('delivery_time')
				->select();
			$receiveData = Db::table($this->tableName)
				->field([
					'month(receive_time)'=>'m',
					'ifnull(sum(area_total),0)'=>'receive_area',
				])
				->where('receive_time','>=',$beginDate)
				->group('month(receive_time)')
				->order('receive_time')
				->select();
			$finishData = Db::table($this->tableName)
				->field([
					'month(review_time)'=>'m',
					'ifnull(sum(area_total),0)'=>'finish_area',
				])
				->where('review_time','>=',$beginDate)
				->group('month(review_time)')
				->order('review_time')
				->select();
			foreach($data as &$d){
				foreach($deliveryData as $item){
					if($d['month']==$item['m'].'月'){
						$d['delivery_area'] = $item['delivery_area'];
						break;
					}
				}
				foreach($receiveData as $item){
					if($d['month']==$item['m'].'月'){
						$d['receive_area'] = $item['receive_area'];
						break;
					}
				}
				foreach($finishData as $item){
					if($d['month']==$item['m'].'月'){
						$d['finish_area'] = $item['finish_area'];
						break;
					}
				}
			}
			
			$res->data = $data;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	public function getDetailsQrcode($id){
		$url = MOBILE_URL.'#/it/asset/details/'.$id;
		qrcodeImg($url,'Q',4);
	}

	/**
	* 获取统计数据
	* @param 
	*/
	public function getTimeStatistic($unit,$time_begin=null,$time_end=null){
		$res = model('Res');
		try{
			if(!$time_end){
				$time_end = date('Y-m-d');
			}
			if(!$time_begin){
				$time_begin = date('Y-m-d',strtotime($time_begin.' -9 '.$unit));
			}
			if($unit=='year'){
				$sqlFormat = '%Y';
				$format = 'Y';
				$time_begin = date('Y-01-01',strtotime($time_begin));
				$time_end = date('Y-12-31',strtotime($time_end));
			}elseif($unit=='month'){
				$sqlFormat = '%Y-%m';
				$format = 'Y-m';
				$time_begin = date('Y-m-01',strtotime($time_begin));
				$time_end = date('Y-m-31',strtotime($time_end));
			}elseif($unit=='day'){
				$sqlFormat = '%Y-%m-%d';
				$format = 'Y-m-d';
			}

			$data=[];
			$timeTemp = $time_begin;
			while ($timeTemp <= $time_end) {
				$u = date($format,strtotime($timeTemp));
				$d=[
					'unit'=>$u,
					'price'=>0,
					'amount'=>0
				];
				$data[]=$d;
				$timeTemp = date('Y-m-d',strtotime($timeTemp.' +1 '.$unit));
			}
			$where = $this->getWhere();
			$list = Db::table( $this->tableName )
				->alias('asset')
				->field([
					'date_format(asset.buy_date,\''.$sqlFormat.'\')'=>'unit',
					'ifnull(sum(asset.price),0)'=>'price',
					'sum(asset.amount)'=>'amount',
				])
				->where($where)
				->where('asset.buy_date','>=',$time_begin)
				->where('asset.buy_date','<=',$time_end)
				->group('date_format(asset.buy_date,\''.$sqlFormat.'\')')
				->select();
			foreach($data as &$d){
				foreach($list as $item){
					if($d['unit']==$item['unit']){
						$d['price'] = $item['price'];
						$d['amount'] = $item['amount'];
						break;
					}
				}
			}
			$res->data = $data;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 检查登录名唯一性
	* @param 
	*/
	public function checkLoginNameUnique($login_name,$id=null) {
		$res=model('Res');
		try{
			$where = [
				'login_name'=>$login_name
			];
			if($id){
				$where['id']=[ '<>', $id ];
			}
			$res->data = Db::table($this->tableName)->where($where)->count();
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}
}