<?php
namespace app\api\controller;
use think\Db;
use app\api\controller\Auth;

class Attach extends Auth {
	private $tableName = 'attach';
	
	private function getWhere(){
		return function($query){
			$name = input('get.name');
			if($name) {
				$query->where('attach.name','like','%'.$name.'%');
			}
			$isDel = input('get.isDel');
			if($isDel){
				$query->where('attach.del_time','not null');
			}else{
				$query->where('attach.del_time',null);
			}
			$attach_ids = input('get.attach_ids');
			$isAttachIds = input('get.isAttachIds');
			if($attach_ids||$isAttachIds){
				$query->where('attach.id','in',$attach_ids);
			}
		};			
	}

	/**
	* 获取附件列表
	* @param 
	*/
	public function getList($currentPage=1,$pageSize=10,$noPage=0) {
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$order = [];
			$sortProp=input('get.sortProp');
			if($sortProp){
				$order[$sortProp]=input('get.sortOrder')=='descending'?'desc':'';
			}
			$sql = Db::table( $this->tableName )
				->alias( 'attach' )
				->where($where)
				->order($order);
			if($noPage){
				$list = $sql->select();
				$total = count($list);
			}else{
				$list = $sql->page($currentPage,$pageSize)->select();
				$total = Db::table( $this->tableName )
					->alias( 'attach' )
					->where($where)
					->count();
			}
			$data['list'] = $list;
			$data['total'] = $total;
			$res->data = $data;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 上传附件
	* @param 
	*/
	public function upload($table_name,$table_id=null,$name='file',$field='attach_ids') {
		$res=model('Res');
		Db::startTrans();
		try{
			if($error = getUploadFileError()){
				throw new \Exception($error);
			}
			$file = request()->file($name);
			if($file){
				$info = $file
					->validate(['size'=>10*1024*1024 ])
					->move(WEB_PATH . 'upload' . DS . 'attach' . DS .$table_name);
				if($info){
					$data = [
						'table_name'=>$table_name,
						'table_id'=>$table_id,
						'name'=>$info->getInfo()['name'],
						'size'=>$info->getSize(),
						'ext'=>$info->getExtension(),
						'save_name'=>($table_name?($table_name . DS):'') . $info->getSaveName(),
						'upload_user'=>session('user_id'),
						'upload_time'=>date('Y-m-d H:i:s')
					];
					$id = Db::table( $this->tableName )->insertGetId($data);
					if($table_id){
						Db::table( $table_name )->where('id',$table_id)->update([
							'attach_ids'=>['exp','CONCAT(if(attach_ids,CONCAT(attach_ids,","),""),'.$id.')']
						]);
					}
					$data['id'] = $id;
					$res->data = $data;
					$res->code = 0;
					Db::commit();
				}else{
					// 上传失败获取错误信息
					throw new \Exception($file->getError());
				}
			}else{
				throw new \Exception('检测不到上传文件！');
			}
			
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 删除附件（假删）
	* @param 
	*/
	public function del($id) {
		$res=model('Res');
		try{
			Db::startTrans();
			$attach = Db::table('attach')->find($id);
			$attach_ids = Db::table( $attach['table_name'] )->where('id',$attach['table_id'])->value('attach_ids');
			$attachIdList = explode(',',$attach_ids);
			$newAttachIdList = array_diff($attachIdList,[$id]);
			$new_attach_ids = implode(',', $newAttachIdList);
			Db::table( $attach['table_name'] )->where('id',$attach['table_id'])->setField('attach_ids',$new_attach_ids);
			// Db::table('attach')->delete($id);
			Db::table('attach')->where('id',$id)->update([
				'del_time'=>date('Y-m-d H:i:s'),
				'del_user_id'=>$this->userId
			]);
			// $file = WEB_PATH . 'upload' . DS . 'attach'.DS.$attach['save_name'];
			// if(file_exists($file)){
			// 	if(false===unlink($file)) throw new \Exception("附件删除失败！");
			// }
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 删除附件（真删）
	* @param 
	*/
	public function del2($id) {
		$res=model('Res');
		try{
			Db::startTrans();
			$attach = Db::table('attach')->find($id);
			if(!$attach['del_time']){
				throw new \Exception('此附件还未删除！');
			}
			Db::table('attach')->delete($id);
			$file = WEB_PATH . 'upload' . DS . 'attach'.DS.$attach['save_name'];
			if(file_exists($file)){
				if(false===unlink($file)) throw new \Exception("附件删除失败！");
			}
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 下载附件
	* 
	* @param $id 附件id
	*/
	public function download($id,$table_name=null){
		$where = [
			'id'=>$id
		];
		if($table_name){
			$where['table_name'] = $table_name;
		}
		$attach = Db::table($this->tableName)->where($where)->find();
		if($attach){
			$file_name = WEB_PATH . 'upload'.DS.'attach'.DS.$attach['save_name'];
			header("Content-type: application/octet-stream");
			header("Content-disposition:attachment;filename=\"".$attach["name"]."\"");
			header("Content-Length:".filesize($file_name));
			readfile($file_name);
			exit;
		}
		return '';
	}

	/**
	* 上传附件
	* @param 
	*/
	public function uploadImg($table_name,$table_id=null,$name='file',$attach_field='attach_ids') {
		$res=model('Res');
		Db::startTrans();
		try{
			if($error = getUploadFileError()){
				throw new \Exception($error);
			}
			$file = request()->file($name);
			if($file){
				$info = $file->validate(['size'=>10*1024*1024,'ext'=>'jpg,png,jpeg'])->move(WEB_PATH . 'upload' . DS . 'attach');
				if($info){
					$data = [
						'table_name'=>$table_name,
						'table_id'=>$table_id,
						'name'=>$info->getInfo()['name'],
						'size'=>$info->getSize(),
						'ext'=>$info->getExtension(),
						'save_name'=>$info->getSaveName(),
						'upload_user'=>session('user_id'),
						'upload_time'=>date('Y-m-d H:i:s')
					];
					$id = Db::table( $this->tableName )->insertGetId($data);
					$data['id'] = $id;
					if($table_id){
						Db::table( $table_name )->where('id',$table_id)->update([
							$attach_field=>['exp','CONCAT(if('.$attach_field.',CONCAT('.$attach_field.',","),""),'.$id.')']
						]);
					}
					$imgPath = WEB_PATH.'upload'.DS.'attach'.DS.$info->getSaveName();
					$image=\think\Image::open($imgPath);
					$image->thumb(300,300,\think\Image::THUMB_CENTER)->save($imgPath."_thumb_300.jpg");					
					$res->data = $data;
					$res->code = 0;
					Db::commit();
				}else{
					// 上传失败获取错误信息
					throw new \Exception($file->getError());
				}
			}else{
				throw new \Exception('检测不到上传文件！');
			}
			
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 删除附件
	* @param 
	*/
	public function delImg($id,$attach_field='attach_ids') {
		$res=model('Res');
		try{
			Db::startTrans();
			$attach = Db::table('attach')->find($id);
			$attach_ids = Db::table( $attach['table_name'] )->where('id',$attach['table_id'])->value($attach_field);
			$attachIdList = explode(',',$attach_ids);
			$newAttachIdList = array_diff($attachIdList,[$id]);
			$new_attach_ids = implode(',', $newAttachIdList);
			Db::table( $attach['table_name'] )->where('id',$attach['table_id'])->setField($attach_field,$new_attach_ids);
			Db::table('attach')->delete($id);
			$file = WEB_PATH . 'upload' . DS . 'attach'.DS.$attach['save_name'];
			if(file_exists($file)){
				if(false===unlink($file)) throw new \Exception("图片删除失败！");
			}
			if(file_exists($file.'_thumb_300.jpg')){
				if(false===unlink($file.'_thumb_300.jpg')) throw new \Exception("缩略图片删除失败！");
			}
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}
}