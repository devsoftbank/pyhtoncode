<?php
namespace app\api\controller;
use think\Db;
use app\api\controller\Auth;

class Index extends Auth {

	/**
	* 获取更新记录告列表
	* @param 
	*/
	public function getUpdateRecordList($currentPage,$pageSize) {
		$res=model('Res');
		$tableName = 'sys_update_record';
		try{
			$where = [];
			$keyword = input('get.keyword');
			if($keyword) {
				$where['title|content'] = ['like','%'.$keyword.'%'];
			}
			$data['list']=Db::table($tableName)
				->where($where)
				->where('input_status','>=',0)
				->order('update_date desc,id desc')
				->page($currentPage,$pageSize)
				->select();
			$data['total']=Db::table($tableName)
				->where('input_status','>=',0)
				->where($where)
				->count();
			$res->data = $data;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 获取更新记录告列表
	* @param 
	*/
	public function modifyPwd($oldPassword,$newPassword) {
		$res=model('Res');
		$tableName = 'sys_user';
		try{
			$user = Db::table($tableName)
				->find($this->user_id);
			if($user['pwd']!=$oldPassword){
				throw new \Exception('原密码不正确！');
			}
			Db::table($tableName)->where('id',$this->user_id)->setField('pwd',$newPassword);
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 获取登录日志列表
	* @param 
	*/
	public function getLoginLogList($currentPage,$pageSize) {
		$res=model('Res');
		$tableName = 'sys_user_login_log';
		try{
			$where = [
				'user_id'=>$this->user_id
			];
			$ip = input('get.ip');
			if($ip) {
				$where['ip'] = ['like','%'.$ip.'%'];
			}		

			$data['list']=Db::table($tableName)
				->where($where)
				->order('login_time desc')
				->page($currentPage,$pageSize)
				->select();
			$data['total']=Db::table($tableName)
				->where($where)
				->count();
			$res->data = $data;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}
}
