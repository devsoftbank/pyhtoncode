<?php
namespace app\api\controller\it;
use think\Db;
use app\api\controller\Auth;

//
class AssetUseStatus extends Auth{

	private $tableName = 'it_asset';

	private function getWhere(){
		return function($query){
			$input_status=input('input_status');
			if($input_status!=null){
				$query->where('asset.input_status',$input_status);
			}
			$inUser = input('inUser'); 
			if($inUser){
				$query->where('asset.create_user_id',$this->user_id);
			}
			$inCompany = input('inCompany');
			if($inCompany){
				$companyIds = Db::table('sys_user')->where('id',$this->user_id)->value('company_ids');
				if($companyIds!=='*'){
					$query->where('asset.company_id','in',$companyIds);
				}
			}
			$asset_no=input('asset_no');
			if($asset_no){
				$query->where('asset.no','like','%'.$asset_no.'%');
			}
			$asset_model=input('asset_model');
			if($asset_model){
				$query->where('asset.model','like','%'.$asset_model.'%');
			}		
			$diy_no=input('diy_no');
			if($diy_no){
				$query->where('asset.diy_no','like','%'.$diy_no.'%');
			}
			//
			$asset_id=input("asset_id");
			if($asset_id){
				$query->where('asset.id',$asset_id);
			}
			$not_detail_ids=input("not_detail_ids");
			if($not_detail_ids){
				$query->where('detail.id','not in',$not_detail_ids);
			}
			$dep_id=input("dep_id");
			if($dep_id){
				$hasSubDep = input('hasSubDep');
				if($hasSubDep){
					$query->where('FIND_IN_SET('.$dep_id.',CONCAT(ifnull(dep.parent_ids,""),",",dep.id))');
				}else{
					$query->where('employee.dep_id',$dep_id);
				}
			}
			//所属单位
			$employee_name=input("employee_name");
			if($employee_name){
				$query->where('employee.name','like','%'.$employee_name.'%');
			}
			//所属单位
			$company_name=input("company_name");
			if($company_name){
				$query->where('asset.company_name','like','%'.$company_name.'%');
			}
			$place=input("place");
			if($place){
				$query->where('record.place','like','%'.$place.'%');
			}
			$remarks=input("remarks");
			if($remarks){
				$query->where('record.remarks','like','%'.$remarks.'%');
			}
			//发货日期开始值
			$use_date_begin=input("use_date_begin");
			if($use_date_begin){
				$query->where('record.record_date','>=',$use_date_begin);
			}
			//发货日期结束值
			$use_date_end=input("use_date_end");
			if($use_date_end){
				$query->where('record.record_date','<=',$use_date_end);
			}
			//近期
			$isNear = input('get.isNear');
			if($isNear) {
				$nearDate = date('Y-m-d',strtotime('-10 days'));
				$query->where('asset.create_time','>=',$nearDate);
			}
		};
	}
			
	/*
	* 获取车辆列表
	* 
	*/
	public function getList($currentPage=1,$pageSize=10,$noPage=0){
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$order = [];
			$sortProp=input('get.sortProp');
			if($sortProp){
				$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
			}else{
				$order['record.submit_time'] = 'desc';
			}
			$subSql = Db::table('it_asset_use_record_detail')
				->field([
					'detail_id',
					'abs(sum(amount))'=>'return_amount'
				])
				->where('detail_id','not null')
				->group('detail_id')
				->buildSql();
			$sql = Db::table('it_asset_use_record_detail')
				->alias('detail')
				->field([
					'asset.id'=>'asset_id',
					'asset.model'=>'asset_model',
					'asset.no'=>'asset_no',
					'type.name'=>'asset_type_name',
					'record.record_date'=>'use_date',
					'record.place'=>'use_place',
					'record.remarks'=>'use_remarks',
					'detail.id'=>'detail_id',
					'detail.amount - ifnull(return_detail.return_amount,0)'=>'use_amount',
					'detail.dep_id',
					'detail.employee_id',
					'employee.name'=>'employee_name',
					'dep.name'=>'dep_name',
					'company.name'=>'company_name'
				])
				->join($subSql.' return_detail','return_detail.detail_id = detail.id','left')
				->join('it_asset_use_record record','record.id = detail.record_id')
				->join('hr_employee employee','employee.id = record.employee_id')
				->join('hr_dep dep','dep.id = record.dep_id')
				->join('it_asset asset','asset.id = detail.asset_id')
				->join('it_asset_type type','type.id = asset.type_id')
				->join('sys_company company','company.id = asset.company_id')
				->where($where)
				->where('asset.used','>',0)
				->where('detail.amount > ifnull(return_detail.return_amount,0)')
				->order($order);
			if($noPage){
				$list = $sql->select();
				$total = count($list);
			}else{
				$list = $sql->page($currentPage,$pageSize)->select();	
				$total = Db::table('it_asset_use_record_detail')
					->alias('detail')
					->join($subSql.' return_detail','return_detail.detail_id = detail.id','left')
					->join('it_asset_use_record record','record.id = detail.record_id')
					->join('hr_employee employee','employee.id = record.employee_id')
					->join('hr_dep dep','dep.id = record.dep_id')
					->join('it_asset asset','asset.id = detail.asset_id')
					->join('it_asset_type type','type.id = asset.type_id')
					->join('sys_company company','company.id = asset.company_id')
					->where($where)
					->where('asset.used','>',0)
					->where('detail.amount > ifnull(return_detail.return_amount,0)')
					->count();
			}
			$summary = Db::table('it_asset_use_record_detail')
				->alias('detail')
				->field([
					'sum(detail.amount) - sum(ifnull(return_detail.return_amount,0))'=>'use_amount'
				])
				->join($subSql.' return_detail','return_detail.detail_id = detail.id','left')
				->join('it_asset_use_record record','record.id = detail.record_id')
				->join('hr_employee employee','employee.id = record.employee_id')
				->join('hr_dep dep','dep.id = record.dep_id')
				->join('it_asset asset','asset.id = detail.asset_id')
				->join('it_asset_type type','type.id = asset.type_id')
				->join('sys_company company','company.id = asset.company_id')
				->where($where)
				->where('asset.used','>',0)
				->where('detail.amount > ifnull(return_detail.return_amount,0)')
				->find();
			$data['list'] = $list;
			$data['total'] = $total;			
			$data['summary'] = $summary;			
			$res->data=$data;	
			$res->code = 0;
		}catch(\Exception $e){
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 导出excel
	* @param 
	*/
	public function exportExcel(){
		$titles = [ 
			'no'=>'车辆编号',
			'status'=>'车辆状态',
			'task_no'=>'任务编号',
			'project' => '项目名称',//项目名称
			'contract_no' => '合同号',//客户名称
			'salesman_unit' => '销售公司',//业绩公司
			'salesman_name'=>'业务员',
			'salesman_tel'=>'业务员联系电话',
			'db_no'=>'调拨单号',
			'fh_no'=>'发货申请编号',
			'area_name'=>'发货工厂',
			'receive_unit'=>'收货单位',
			'receive_address'=>'收货地址',
			'receive_name'=>'收货人',
			'receive_tel'=>'收货人联系电话',
			'amount_total'=>'装车数量',
			'area_total'=>'装车面积（㎡）',
			'delivery_time'=>'发货时间',
			'receive_time'=>'签收时间',
			'review_time'=>'审核完成时间',
			'create_user_name'=>'录入员',
			'create_time'=>'创建时间',
			'submit_time'=>'提交时间',
		];		
		$where = $this->getWhere();
		$order = [];
		$sortProp=input('get.sortProp');
		if($sortProp){
			$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
		}else{
			$order['car.id'] = 'desc';
		}
		$fields = [
			'car.*',
			'task.no'=>'task_no',
			'task.area_name'=>'area_name',
			'task.project',
			'task.contract_no',
			'task.db_no',
			'task.fh_no',
			'task.salesman_unit',
			'task.salesman_name',
			'task.salesman_tel',
			'task.plan_send_date',
			'task.receive_unit',
			'task.method',
			'task.receive_address',
			'task.receive_name',
			'task.receive_tel'
		];
		$list = Db::table( $this->tableName )
			->alias('car')
			->field($fields)
			->join('yyzx_delivery_task task','car.task_id=task.id')
			->where($where)
			->where('car.input_status','>=',0)
			->order($order)
			->select();
		exportExcel($list,$titles,'发货车辆列表');
	}


}