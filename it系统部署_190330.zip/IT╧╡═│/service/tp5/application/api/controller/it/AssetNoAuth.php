<?php
namespace app\api\controller\it;
use think\Db;
use think\Controller;

//
class AssetNoAuth extends Controller{

	private $tableName = 'it_asset';

	private function getWhere(){
		return function($query){
			$input_status=input('input_status');
			if($input_status!=null){
				$query->where('asset.input_status',$input_status);
			}
			$inUser = input('inUser'); 
			if($inUser){
				$query->where('asset.create_user_id',$this->user_id);
			}
			$inCompany = input('inCompany');
			if($inCompany){
				$companyIds = Db::table('sys_user')->where('id',$this->user_id)->value('company_ids');
				if($companyIds!=='*'){
					$query->where('asset.company_id','in',$companyIds);
				}
			}
			$no=input('no');
			if($no){
				$query->where('asset.no','like','%'.$no.'%');
			}
			$asset_no=input('asset_no');
			if($asset_no){
				$query->where('asset.no','like','%'.$asset_no.'%');
			}
			$diy_no=input('diy_no');
			if($diy_no){
				$query->where('asset.diy_no','like','%'.$diy_no.'%');
			}
			$model=input('model');
			if($model){
				$query->where('asset.model','like','%'.$model.'%');
			}
			$abnormal_status=input('abnormal_status/a');
			if($abnormal_status){
				$query->where(function ($query2) use($abnormal_status){
					if(in_array('FREE',$abnormal_status)){
						$query2->whereOr('asset.amount - asset.scrap_amount > asset.used');
					}
					if(in_array('REPAIR',$abnormal_status)){
						$query2->whereOr('asset.is_repair',1);
					}
					if(in_array('SCRAP',$abnormal_status)){
						$query2->whereOr('asset.scrap_amount','>',0);
					}
				});
				
			}
			$remarks=input('remarks');
			if($remarks){
				$query->where('asset.remarks','like','%'.$remarks.'%');
			}
			$sn=input('sn');
			if($sn){
				$query->where('asset.sn','like','%'.$sn.'%');
			}
			$type_id = input('type_id');
			if($type_id){
				$hasSubType = input('hasSubType');
				if($hasSubType){
					$query->where('FIND_IN_SET('.$type_id.',CONCAT(ifnull(type.parent_ids,""),",",type.id))');
				}else{
					$query->where('asset.type_id',$type_id);
				}
			}
			//
			$ids=input("ids");
			if($ids){
				$query->where('asset.id','in',$ids);
			}
			$not_ids=input("not_ids");
			if($not_ids){
				$query->where('asset.id','not in',$not_ids);
			}
			$isFree=input("isFree");
			if($isFree){
				$query->where('asset.amount - asset.scrap_amount > asset.used');
			}
			$isRepair=input("isRepair");
			if($isRepair!=null){
				$query->where('asset.is_repair',$isRepair);
			}
			//所属单位
			$company_name=input("company_name");
			if($company_name){
				$query->where('company.name','like','%'.$company_name.'%');
			}
			//
			$price_begin=input("price_begin");
			if($price_begin){
				$query->where('asset.price','>=',$price_begin);
			}
			//
			$price_end=input("price_end");
			if($price_end){
				$query->where('asset.price','<=',$price_end);
			}
			//创建时间开始值
			$create_time_begin=input("create_time_begin");
			if($create_time_begin){
				$query->where('asset.create_time','>=',$create_time_begin);
			}
			//提交日期结束值
			$create_time_end=input("create_time_end");
			if($create_time_end){
				$query->where('asset.create_time','<=',$create_time_end.' 24:00');
			}
			//入库日期开始值
			$inbound_date_begin=input("inbound_date_begin");
			if($inbound_date_begin){
				$query->where('asset.inbound_date','>=',$inbound_date_begin);
			}
			//发货日期结束值
			$inbound_date_end=input("inbound_date_end");
			if($inbound_date_end){
				$query->where('asset.inbound_date','<=',$inbound_date_end);
			}
			//近期
			$isNear = input('get.isNear');
			if($isNear) {
				$nearDate = date('Y-m-d',strtotime('-10 days'));
				$query->where('asset.create_time','>=',$nearDate);
			}
		};
	}
			
	/*
	* 获取车辆列表
	* 
	*/
	public function getList($currentPage=1,$pageSize=10,$noPage=0){
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$order = [];
			$sortProp=input('get.sortProp');
			if($sortProp){
				$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
			}else{
				$order['asset.create_time'] = 'desc';
			}
			$fields = [
				'asset.*',
				'asset.amount -asset.scrap_amount - asset.used' =>'remain',
				'asset.amount -asset.scrap_amount' =>'avaiable_amount',
				'employee.name'=>'use_employee_name',
				'dep.name'=>'use_dep_name',
				'type.name'=>'type_name',
				'supplier.name'=>'supplier_name',
				'company.name'=>'company_name'
			];
			$sql = Db::table( $this->tableName )
				->alias('asset')
				->field($fields)
				->join('hr_employee employee','employee.id = asset.use_employee_id','left')
				->join('hr_dep dep','dep.id = asset.use_dep_id','left')
				->join('it_asset_type type','asset.type_id = type.id')
				->join('sys_company company','asset.company_id = company.id')
				->join('it_supplier supplier','asset.supplier_id = supplier.id','left')
				->where($where)
				->where('asset.input_status','>=',0)
				->order($order);
			if($noPage){
				$list = $sql->select();
				$total = count($list);
			}else{
				$list = $sql->page($currentPage,$pageSize)->select();	
				$total = Db::table( $this->tableName )
					->alias('asset')
					->join('hr_employee employee','employee.id = asset.use_employee_id','left')
					->join('hr_dep dep','dep.id = asset.use_dep_id','left')
					->join('it_asset_type type','type.id = asset.type_id')
					->join('sys_company company','asset.company_id = company.id')
					->join('it_supplier supplier','asset.supplier_id = supplier.id','left')
					->where($where)
					->where('asset.input_status','>=',0)
					->count();
			}
			$summary = Db::table( $this->tableName )
				->alias('asset')
				->field([
					'sum(price)'=>'price'
				])
				->join('hr_employee employee','employee.id = asset.use_employee_id','left')
				->join('hr_dep dep','dep.id = asset.use_dep_id','left')
				->join('it_asset_type type','type.id = asset.type_id')
				->join('sys_company company','asset.company_id = company.id')
				->join('it_supplier supplier','asset.supplier_id = supplier.id','left')
				->where($where)
				->where('asset.input_status','>=',0)
				->find();
			$data['list'] = $list;
			$data['total'] = $total;			
			$data['summary'] = $summary;			
			$res->data=$data;	
			$res->code = 0;
		}catch(\Exception $e){
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	
	/**
	* 根据记录id获取表单数据
	* @param 
	*/
	public function getForm($id) {
		$res=model('Res');
		try{
			$data = Db::table($this->tableName)
				->find($id);
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 新增资产
	*
	*/
	public function create(){	
		$res=model('Res');
		Db::startTrans();
		try{
			$data = Db::table($this->tableName)
				->field('id,create_user_id,attach_ids')
				->where([			
				'create_user_id'=>$this->user_id,
				'input_status'=>-1
			])->find();
			if(!$data){
				$data['create_user_id'] = $this->user_id;				
				$id=Db::table( $this->tableName )->field('id',true)->insertGetId($data);
				if(!$id) throw new \Exception('新增失败');
				$data['id'] = $id;
			}
			$res->data = $data;
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->success = false;
			$res->message = $e->getMessage();
		}
		return json($res);
	}

	/**
	* 更新
	* @param 
	*/
	public function update($id) {
		$res=model('Res');
		Db::startTrans();
		try{
			$data = Db::table($this->tableName)->find($id);
			if(!$data){
				throw new \Exception('找不到该IT资产信息！');
			}
			$fields=[
				'input_status','company_id','company_name','type_id','model','diy_no','supplier_id','inbound_date','amount','price','sn','position','remarks','update_time','update_user_id'
			];
			$now = date('Y-m-d H:i:s');
			$post=input('post.');
			if($data['input_status']==-1){
				$fields[] = 'create_time';
				$fields[] = 'create_user_name';
				$fields[] = 'no';
				$post['create_time'] = $now;				
				$data['create_user_name'] = Db::table('sys_user')->where('id',$this->user_id)->value('name');
				$no_prefix = 'IT'.date('ym'); //编号前缀
				$last_no = Db::table($this->tableName)->where('no','like',$no_prefix.'%')->max("no",false);
				$no= $no_prefix.sprintf("%04d",substr($last_no,-4)+1);
				$post['no'] = $data['no']= $no;
			}
			if($post['action']==1){
				$post['input_status'] = 1;
			}elseif($post['action']==0){
				$post['input_status'] = 0;
			}
			$post['update_time'] = $now;
			$post['update_user_id'] = $this->user_id;
			Db::table($this->tableName)->field($fields)->update($post);
			$data = array_merge($data,$post);
			$res->data = [
				'no'=>$data['no'],
				'input_status'=>$data['input_status']
			];
			$res->code=0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message = $e->getMessage();
		}
		return json($res);
	}
	/*
	* 删除
	*/
	public function del($id){
		$res=model('Res');
		Db::startTrans();
		try{			
			$car = Db::table($this->tableName)->find($id);
			if(!$car){
				throw new \Exception('找不到该IT资产！');
			}
			Db::table( $this->tableName )->delete($id);
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	
	public function getPrintQrcode($id){
		$url = MOBILE_URL.'#/it/asset/details/'.$id;
		qrcodeImg($url,'Q',2.5);
	}
	/**
	* 根据记录id获取表单数据
	* @param 
	*/
	public function getSummaryData() {
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$data = Db::table( $this->tableName )
				->alias('car')
				->field([
					'count(*)'=>'car_total',
					'sum(amount_total)'=>'amount_total',
					'sum(area_total)'=>'area_total',
				])
				->join('yyzx_delivery_task task','car.task_id=task.id')
				->where($where)
				->where('car.input_status','>=',0)
				->find();
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}


	/**
	* 根据记录id获取
	* @param 
	*/
	public function getDetails($id) {
		$res=model('Res');
		try{
			$data = Db::table( $this->tableName )
				->alias('asset')
				->field([
					'asset.*',
					'asset.amount - asset.scrap_amount - asset.used'=>'remain',
					'asset.amount - asset.scrap_amount'=>'avaiable_amount',
					'type.name'=>'type_name',
					'company.name'=>'company_name'				
				])
				->join('it_asset_type type','type.id = asset.type_id')				
				->join('sys_company company','company.id = asset.company_id')
				->where('asset.id',$id)
				->find();

			$data['use_list'] = Db::table('it_asset_use_record_detail')
				->alias('detail')
				->field([
					'sum(detail.amount) - abs(sum(ifnull(return_detail.amount,0)))'=>'use_amount',
					'record.record_date',
					'record.remarks',
					'record.place',
					'dep.name'=>'dep_name',
					'employee.name'=>'employee_name'
				])
				->join('it_asset_use_record_detail return_detail','detail.id = return_detail.detail_id','left')
				->join('it_asset_use_record record','record.id = detail.record_id')
				->join('hr_employee employee','employee.id = record.employee_id')
				->join('hr_dep dep','dep.id = record.dep_id')
				->where('detail.asset_id',$id)
				->where('detail.detail_id',null)
				->group('detail.id')
				->having('use_amount > 0')
				->select();
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 导出excel
	* @param 
	*/
	public function exportExcel(){
		$titles = [ 
			'no'=>'资产编号',
			'model'=>'资产型号',
			'type_name' => '资产类型',//
			'diy_no' => '标识号',//
			'inbound_date' => '入库日期',//
			'supplier_name'=>'供应商',
			'price'=>'金额',
			'amount'=>'入库量',
			'avaiable_amount'=>'可用量',
			'remain'=>'库存量',
			'use_dep_name'=>'近期领用部门',
			'use_employee_name'=>'近期领用员工',
			'remarks'=>'备注',
			'sn'=>'序列号',
			'company_name'=>'资产所属公司',
			'is_repair'=>'维修中',
			'scrap_amount'=>'报废数量',
			'create_user_name'=>'录入员',
			'create_time'=>'创建时间',
			'update_time'=>'更新时间'
		];		
		$where = $this->getWhere();
		$order = [];
		$sortProp=input('get.sortProp');
		if($sortProp){
			$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
		}else{
			$order['asset.create_time'] = 'desc';
		}
		$fields = [
			'asset.*',
			'asset.amount -asset.scrap_amount - asset.used' =>'remain',
			'asset.amount -asset.scrap_amount' =>'avaiable_amount',
			'employee.name'=>'use_employee_name',
			'dep.name'=>'use_dep_name',
			'type.name'=>'type_name',
			'supplier.name'=>'supplier_name',
			'company.name'=>'company_name'
		];
		$list = Db::table( $this->tableName )
			->alias('asset')
			->field($fields)
			->join('hr_employee employee','employee.id = asset.use_employee_id','left')
			->join('hr_dep dep','dep.id = asset.use_dep_id','left')
			->join('it_asset_type type','asset.type_id = type.id')
			->join('sys_company company','asset.company_id = company.id')
			->join('it_supplier supplier','asset.supplier_id = supplier.id','left')
			->where($where)
			->where('asset.input_status','>=',0)
			->order($order)
			->select();
		exportExcel($list,$titles,'IT资产列表');
	}

	/**
	* 获取最近6个月的统计数据
	* @param 
	*/
	public function getNearMonthSummary(){
		$res = model('Res');
		try{
			$data=[];
			for($i=5;$i>=0;$i--){
				$m = date('n',strtotime('-'.$i.' month'));
				$d=[
					'month'=>$m.'月',
					'delivery_area'=>0,
					'receive_area'=>0,
					'finish_area'=>0
				];
				$data[]=$d;
			}
			$beginDate = date('Y-m-01',strtotime('-5 month'));
			
			$deliveryData = Db::table($this->tableName)
				->field([
					'month(delivery_time)'=>'m',
					'ifnull(sum(area_total),0)'=>'delivery_area',
				])
				->where('delivery_time','>=',$beginDate)
				->group('month(delivery_time)')
				->order('delivery_time')
				->select();
			$receiveData = Db::table($this->tableName)
				->field([
					'month(receive_time)'=>'m',
					'ifnull(sum(area_total),0)'=>'receive_area',
				])
				->where('receive_time','>=',$beginDate)
				->group('month(receive_time)')
				->order('receive_time')
				->select();
			$finishData = Db::table($this->tableName)
				->field([
					'month(review_time)'=>'m',
					'ifnull(sum(area_total),0)'=>'finish_area',
				])
				->where('review_time','>=',$beginDate)
				->group('month(review_time)')
				->order('review_time')
				->select();
			foreach($data as &$d){
				foreach($deliveryData as $item){
					if($d['month']==$item['m'].'月'){
						$d['delivery_area'] = $item['delivery_area'];
						break;
					}
				}
				foreach($receiveData as $item){
					if($d['month']==$item['m'].'月'){
						$d['receive_area'] = $item['receive_area'];
						break;
					}
				}
				foreach($finishData as $item){
					if($d['month']==$item['m'].'月'){
						$d['finish_area'] = $item['finish_area'];
						break;
					}
				}
			}			
			$res->data = $data;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	private function qywxNotice($id){
		$car = Db::table($this->tableName)
			->alias('car')
			->field([
				'car.*',
				'task.no'=>'task_no',
				'task.project',
				'task.area_name',
				'task.salesman_unit',
				'task.receive_unit',
				'task.cy_load_area_total',
				'task.cy_finish_area_total',
				'task.create_user'=>'task_create_user_id'
			])
			->join('yyzx_delivery_task task','car.task_id = task.id')
			->where('car.id',$id)
			->find();
		$qywxUser = Db::table('sys_user')->where('id',$car['task_create_user_id'])->value('qywx_user');
		if($car['status']=='SUBMIT'){
			$qywx=new \Qywx;
			if($qywxUser){				
				$notice['to']['touser']=$qywxUser;
				$notice['content']['title']='您的发货任务['.$car['task_no'].']已安排发货车辆';
				$notice['content']['description']=
					'<div>项目名称：'.$car['project'].'</div><div>销售公司：'.$car['salesman_unit'].'</div><div>收货单位：'.$car['receive_unit'].'</div><div>发货工厂：'.$car['area_name'].'</div><div></div><div>车辆编号：'.$car['no'].'</div><div>装车面积：'.$car['area_total'].'㎡</div><div>车辆录入：'.$car['create_user_name'].'</div>';
				$notice["content"]["url"] = MOBILE_URL.'#/yyzx/deliveryTask/details/'.$car['task_id'];
				$qywx->sendCard($notice);
			}
		}elseif($car['status']=='FINISH'){
			$qywx=new \Qywx;
			if($qywxUser){				
				$notice['to']['touser']=$qywxUser;
				$notice['content']['title']='您的发货任务['.$car['task_no'].']已有车辆审核完成';
				$notice['content']['description']=
					'<div>项目名称：'.$car['project'].'</div><div>销售公司：'.$car['salesman_unit'].'</div><div>收货单位：'.$car['receive_unit'].'</div><div>发货工厂：'.$car['area_name'].'</div><div>完成进度：'.$car['cy_finish_area_total'].'㎡ / '.$car['cy_load_area_total'].'㎡</div><div></div><div>车辆编号：'.$car['no'].'</div><div>装车面积：'.$car['area_total'].'㎡</div><div>审核人员：'.$car['review_user_name'].'</div>';				
				$notice["content"]["url"]=MOBILE_URL.'#/yyzx/deliveryTask/details/'.$car['task_id'];
				$qywx->sendCard($notice);
			}
			$qywxUser = Db::table('sys_user')->where('id',$car['create_user_id'])->value('qywx_user');
			if($qywxUser){				
				$notice['to']['touser']=$qywxUser;
				$notice['content']['title']='您的发货车辆['.$car['no'].']已审核完成';
				$notice['content']['description']=
					'<div>项目名称：'.$car['project'].'</div><div>销售公司：'.$car['salesman_unit'].'</div><div>收货单位：'.$car['receive_unit'].'</div><div>发货工厂：'.$car['area_name'].'</div><div>装车面积：'.$car['area_total'].'㎡</div><div>审核人员：'.$car['review_user_name'].'</div>';
				$notice["content"]["url"]=MOBILE_URL.'#/cy/deliveryCar/details/'.$car['id'];
				$qywx->sendCard($notice);
			}
		}
		
	}

	public function getDetailsQrcode($id){
		$url = MOBILE_URL.'#/it/asset/details/'.$id;
		qrcodeImg($url,'Q',4);
	}

	/**
	* 获取统计数据
	* @param 
	*/
	public function getTimeStatistic($unit,$time_begin=null,$time_end=null){
		$res = model('Res');
		try{
			if(!$time_end){
				$time_end = date('Y-m-d');
			}
			if(!$time_begin){
				$time_begin = date('Y-m-d',strtotime($time_begin.' -9 '.$unit));
			}
			if($unit=='year'){
				$sqlFormat = '%Y';
				$format = 'Y';
				$time_begin = date('Y-01-01',strtotime($time_begin));
				$time_end = date('Y-12-31',strtotime($time_end));
			}elseif($unit=='month'){
				$sqlFormat = '%Y-%m';
				$format = 'Y-m';
				$time_begin = date('Y-m-01',strtotime($time_begin));
				$time_end = date('Y-m-31',strtotime($time_end));
			}elseif($unit=='day'){
				$sqlFormat = '%Y-%m-%d';
				$format = 'Y-m-d';
			}

			$data=[];
			$timeTemp = $time_begin;
			while ($timeTemp <= $time_end) {
				$u = date($format,strtotime($timeTemp));
				$d=[
					'unit'=>$u,
					'price'=>0,
					'amount'=>0
				];
				$data[]=$d;
				$timeTemp = date('Y-m-d',strtotime($timeTemp.' +1 '.$unit));
			}
			$where = $this->getWhere();
			$list = Db::table( $this->tableName )
				->alias('asset')
				->field([
					'date_format(asset.inbound_date,\''.$sqlFormat.'\')'=>'unit',
					'ifnull(sum(asset.price),0)'=>'price',
					'sum(asset.amount)'=>'amount',
				])
				->where($where)
				->where('asset.inbound_date','>=',$time_begin)
				->where('asset.inbound_date','<=',$time_end)
				->group('date_format(asset.inbound_date,\''.$sqlFormat.'\')')
				->select();
			foreach($data as &$d){
				foreach($list as $item){
					if($d['unit']==$item['unit']){
						$d['price'] = $item['price'];
						$d['amount'] = $item['amount'];
						break;
					}
				}
			}
			$res->data = $data;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

		/**
	* 从Excel导入数据
	* @param 
	*/
	public function importExcel(){
		$res=model('Res');
		try{
			Db::startTrans();
			$excel = importExcel(3);
			$list = [];
			$res->data = 0;
			$userName = Db::table('sys_user')->where('id',$this->userId)->value('name');
			$nowTime = date('Y-m-d H:i:s');
			$res->data=0;
			$sum=0;
			foreach($excel as $index=>$row){
				if($row[0]&&$row[1]&&$row[2]&&$row[5]&&$row[6]){
					$companyId = Db::table('sys_company')->where('name',$row[0])->value('id');
					$typeId = Db::table('it_asset_type')->where('name',$row[2])->value('id');
					if(!$typeId){
						$typeId = Db::table('it_asset_type')->insertGetId([
							'input_status'=>0,
							'name'=>$row[2],
							'order'=>99,
							'create_user_id'=>$this->userId,
							'create_user_name'=>$userName,
							'create_time'=>$nowTime,
							'update_time'=>$nowTime,
							'update_user_id'=>$this->userId
						]);
					}
					if($companyId&&$typeId){
						$supplierId = Db::table('it_supplier')->where('name',$row[4])->value('id');
						$data = [
							'input_status'=>0,
							'company_id'=>$companyId,
							'model'=>$row[1],
							'type_id'=>$typeId,
							'supplier_id'=>$supplierId,
							'diy_no'=>$row[4],
							'inbound_date'=>$row[5],							
							'amount'=>$row[6],
							'price'=>$row[7],
							'sn'=>$row[8],
							'remarks'=>$row[9],							

							'create_user'=>$this->user_id,
							'create_user_name'=>$userName,
							'create_time'=>date('Y-m-d H:i:s'),
							'update_time'=>date('Y-m-d H:i:s'),
							'update_user_id'=>$this->user_id,
						];
						$no_prefix = 'IT'.date('ym'); //编号前缀
						$last_no = Db::table($this->tableName)->where('no','like',$no_prefix.'%')->max("no",false);
						$no= $no_prefix.sprintf("%04d",substr($last_no,-4)+1);
						$data['no']= $no;
						Db::table($this->tableName)->insertGetId($data);
						$sum++;
					}else{
						if(!$companyId){
							throw new \Exception('第'.($index+3).'行数据资产所属公司名字在系统中不存在！');
						}elseif(!$typeId){
							throw new \Exception('第'.($index+3).'行数据资产类型名字在系统中不存在！');
						}
					}					
				}else{
					throw new \Exception('第'.($index+3).'行数据有误，请检查必填项是否有填写！');
				}
			}
			$res->code = 0;
			$res->data = $sum;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}
}