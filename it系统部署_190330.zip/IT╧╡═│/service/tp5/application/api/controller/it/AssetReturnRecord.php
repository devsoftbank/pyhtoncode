<?php
namespace app\api\controller\it;
use think\Db;
use app\api\controller\Auth;

//送货任务书
class AssetReturnRecord extends Auth{

	private $tableName = 'it_asset_use_record';

	private function getWhere(){
		return function($query){
			$query->where('record.record_type','RETURN');
			$input_status=input('input_status');
			if($input_status!=null){
				$query->where('asset.input_status',$input_status);
			}
			$inUser = input('inUser'); 
			if($inUser){
				$query->where('asset.create_user_id',$this->user_id);
			}
			$inCompany = input('inCompany');
			if($inCompany){
				$companyIds = Db::table('sys_user')->where('id',$this->user_id)->value('company_ids');
				if($companyIds!=='*'){
					$query->where('record.company_id','in',$companyIds);
				}
			}
			$ids=input("ids");
			if($ids){
				$query->where('record.id','in',$ids);
			}
			$no=input('no');
			if($no){
				$query->where('record.no','like','%'.$no.'%');
			}
			//
			$remarks=input("remarks");
			if($remarks){
				$query->where('record.remarks','like','%'.$remarks.'%');
			}
			//
			$place=input("place");
			if($place){
				$query->where('record.place','like','%'.$place.'%');
			}		
			//所属单位
			$company_name=input("company_name");
			if($company_name){
				$query->where('asset.company_name','like','%'.$company_name.'%');
			}
			//发货日期开始值
			$return_date_begin=input("return_date_begin");
			if($return_date_begin){
				$query->where('record.record_date','>=',$return_date_begin);
			}
			//发货日期结束值
			$return_date_end=input("return_date_end");
			if($return_date_end){
				$query->where('record.record_date','<=',$return_date_end);
			}
			//近期
			$isNear = input('get.isNear');
			if($isNear) {
				$nearDate = date('Y-m-d',strtotime('-10 days'));
				$query->where('asset.create_time','>=',$nearDate);
			}
		};
	}
			
	/*
	* 获取列表
	* 
	*/
	public function getList($currentPage=1,$pageSize=10,$noPage=0){
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$order = [];
			$sortProp=input('get.sortProp');
			if($sortProp){
				$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
			}else{
				$order['record.submit_time'] = 'desc';
			}
			$fields = [
				'record.*',
				'abs(record.amount)'=>'amount',
				'company.name'=>'company_name'
			];
			$sql = Db::table( $this->tableName )
				->alias('record')
				->field($fields)
				->join('sys_company company','record.company_id = company.id')
				->where($where)
				->where('record.input_status','>=',0)
				->order($order);
			if($noPage){
				$list = $sql->select();
				$total = count($list);
			}else{
				$list = $sql->page($currentPage,$pageSize)->select();	
				$total = Db::table( $this->tableName )
					->alias('record')
					->join('sys_company company','record.company_id = company.id')
					->where($where)
					->where('record.input_status','>=',0)
					->count();
			}
			$summary = Db::table( $this->tableName )
				->alias('record')
				->field([
					'abs(sum(amount))'=>'amount'
				])
				->join('sys_company company','record.company_id = company.id')
				->where($where)
				->where('record.input_status','>=',0)
				->find();
			$data['list'] = $list;
			$data['total'] = $total;			
			$data['summary'] = $summary;			
			$res->data=$data;	
			$res->code = 0;
		}catch(\Exception $e){
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/*
	* 获取列表
	* 
	*/
	public function getPrintRecordList($currentPage=1,$pageSize=10,$noPage=0){
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$order = [];
			$sortProp=input('get.sortProp');
			if($sortProp){
				$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
			}else{
				$order['record.create_time'] = 'desc';
			}
			$fields = [
				'record.*',
			];
			$list = Db::table( $this->tableName )
				->alias('record')
				->field($fields)
				->where($where)
				->where('record.input_status','>=',0)
				->order($order)
				->select();
			foreach ($list as &$item) {
				$item['asset_list'] = Db::table('it_asset_use_record_detail')
					->field([
						'abs(sum(detail.amount))'=>'amount',
						'dep.name'=>'dep_name',
						'employee.name'=>'employee_name',
						'asset.no'=>'asset_no',
						'asset.model'=>'asset_model',
						'type.name'=>'asset_type_name'
					])
					->alias('detail')
					->join('it_asset asset','asset.id=detail.asset_id')
					->join('it_asset_type type','type.id = asset.type_id')
					->join('hr_employee employee','employee.id=detail.employee_id')
					->join('hr_dep dep','dep.id=detail.dep_id')
					->where('record_id',$item['id'])
					->group('detail.employee_id,detail.dep_id,detail.asset_id')
					->select();
			}			
			$data['list'] = $list;
			$res->data=$data;	
			$res->code = 0;
		}catch(\Exception $e){
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}
	
	/**
	* 根据记录id获取表单数据
	* @param 
	*/
	public function getForm($id) {
		$res=model('Res');
		try{
			$data = Db::table($this->tableName)
				->find($id);
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	*
	* @param 
	*/
	public function getTaskForm($id) {
		$res=model('Res');
		try{
			$data = Db::table('yyzx_delivery_task')
				->find($id);
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 新增资产
	*
	*/
	public function create(){	
		$res=model('Res');
		Db::startTrans();
		try{
			$data = Db::table($this->tableName)
				->field('id,create_user_id,create_user_name')
				->where([			
				'record_type'=>'RETURN',
				'create_user_id'=>$this->user_id,
				'input_status'=>-1
			])->find();
			if(!$data){
				$data['record_type'] = 'RETURN';
				$data['create_user_id'] = $data['update_user_id'] = $this->user_id;
				$data['create_user_name'] = Db::table('sys_user')->where('id',$this->user_id)->value('name');
				$id=Db::table( $this->tableName )->field('id',true)->insertGetId($data);
				if(!$id) throw new \Exception('新增失败');
				$data['id'] = $id;
			}
			$res->data = $data;
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->success = false;
			$res->message = $e->getMessage();
		}
		return json($res);
	}

	/**
	* 更新
	* @param 
	*/
	public function update($id) {
		$res=model('Res');
		Db::startTrans();
		try{
			$data = Db::table($this->tableName)->find($id);
			if(!$data){
				throw new \Exception('找不到该IT资产交还单信息！');
			}			
			$now = date('Y-m-d H:i:s');
			$post=input('post.');
			$post['update_time'] = $now;
			$post['update_user_id'] = $this->user_id;
			//记录还处于未提交状态
			if($data['input_status']<=0){
				$fields=[
					'input_status','company_id','record_date','amount','remarks','place','update_time','update_user_id'
				];
				//前端动作是提交
				if($post['action']==1){
					$post['input_status'] = 1;
					$fields[] = 'submit_time';
					$post['submit_time'] = $now;
				}elseif($post['action']==0){
					$post['input_status'] = 0;
				}
				//记录新增，创建编号及创建时间
				if($data['input_status']==-1){
					$fields[] = 'create_time';
					$post['create_time'] = $now;
					//设置编号
					$fields[] = 'no';
					$no_prefix = 'ITJH'.date('ym'); //编号前缀
					$last_no = Db::table($this->tableName)->where('no','like',$no_prefix.'%')->max("no",false);
					$no= $no_prefix.sprintf("%04d",substr($last_no,-4)+1);
					$post['no'] = $data['no']= $no;
				}
				$post['amount'] = 0;
				$assetList = $post['asset_list'];
				foreach($assetList as &$asset){
					$asset['record_id'] = $id;
					$asset['amount'] = -$asset['amount'];
					//记录提交的话，就需要修改资产的领用数量及领用部门、员工
					if($post['input_status']==1){
						Db::table('it_asset')
							->where('id',$asset['asset_id'])
							->inc('used',$asset['amount'])
							->update([
								'use_dep_id'=>null,
								'use_employee_id'=>null
							]);
					}					
					$post['amount'] += $asset['amount'];
				}
				Db::table('it_asset_use_record_detail')->insertAll($assetList);

			}elseif($data['input_status']==1){
				//记录已提交的情况下，只能修改记录日期、备注、更新时间、更新人员
				$fields=[
					'company_id','record_date','remarks','place','update_time','update_user_id'
				];
			}
			Db::table($this->tableName)->field($fields)->update($post);
			$data = array_merge($data,$post);
			$res->data = [
				'no'=>$data['no'],
				'input_status'=>$data['input_status']
			];
			$res->code=0;
			Db::commit();
			if($post['action']==1){
				$notice = controller('Notice','helper');
				$notice->sendMail('IT_ASSET_RETURN',$id);
			}
		}catch(\Exception $e){
			Db::rollback();
			$res->message = $e->getMessage();
		}
		return json($res);
	}

	/**
	* 根据记录id获取表单数据
	* @param 
	*/
	public function getSummaryData() {
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$data = Db::table( $this->tableName )
				->alias('car')
				->field([
					'count(*)'=>'car_total',
					'sum(amount_total)'=>'amount_total',
					'sum(area_total)'=>'area_total',
				])
				->join('yyzx_delivery_task task','car.task_id=task.id')
				->where($where)
				->where('car.input_status','>=',0)
				->find();
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 根据记录id获取
	* @param 
	*/
	public function getDetails($id) {
		$res=model('Res');
		try{
			$data = Db::table( $this->tableName )
				->alias('record')
				->field([
					'record.*',
					'company.name'=>'company_name',
				])
				->join('sys_company company','company.id = record.company_id')
				->where('record.id',$id)
				->find();
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 修改发货车辆司机信息
	* @param 
	*/
	public function driverSupply($id) {
		$res=model('Res');
		try{
			$post = input('post.');
			$data = Db::table( $this->tableName )
				->alias('car')
				->field([
					'driver_no',
					'driver_name',
					'driver_unit',
					'driver_tel'
				])
				->where('id',$id)
				->update($post);
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 导出excel
	* @param 
	*/
	public function exportExcel(){
		$titles = [ 
			'no'=>'车辆编号',
			'status'=>'车辆状态',
			'task_no'=>'任务编号',
			'project' => '项目名称',//项目名称
			'contract_no' => '合同号',//客户名称
			'salesman_unit' => '销售公司',//业绩公司
			'salesman_name'=>'业务员',
			'salesman_tel'=>'业务员联系电话',
			'db_no'=>'调拨单号',
			'fh_no'=>'发货申请编号',
			'area_name'=>'发货工厂',
			'receive_unit'=>'收货单位',
			'receive_address'=>'收货地址',
			'receive_name'=>'收货人',
			'receive_tel'=>'收货人联系电话',
			'amount_total'=>'装车数量',
			'area_total'=>'装车面积（㎡）',
			'delivery_time'=>'发货时间',
			'receive_time'=>'签收时间',
			'review_time'=>'审核完成时间',
			'create_user_name'=>'录入员',
			'create_time'=>'创建时间',
			'submit_time'=>'提交时间',
		];		
		$where = $this->getWhere();
		$order = [];
		$sortProp=input('get.sortProp');
		if($sortProp){
			$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
		}else{
			$order['car.id'] = 'desc';
		}
		$fields = [
			'car.*',
			'task.no'=>'task_no',
			'task.area_name'=>'area_name',
			'task.project',
			'task.contract_no',
			'task.db_no',
			'task.fh_no',
			'task.salesman_unit',
			'task.salesman_name',
			'task.salesman_tel',
			'task.plan_send_date',
			'task.receive_unit',
			'task.method',
			'task.receive_address',
			'task.receive_name',
			'task.receive_tel'
		];
		$list = Db::table( $this->tableName )
			->alias('car')
			->field($fields)
			->join('yyzx_delivery_task task','car.task_id=task.id')
			->where($where)
			->where('car.input_status','>=',0)
			->order($order)
			->select();
		exportExcel($list,$titles,'发货车辆列表');
	}

	/**
	* 获取最近6个月的统计数据
	* @param 
	*/
	public function getNearMonthSummary(){
		$res = model('Res');
		try{
			$data=[];
			for($i=5;$i>=0;$i--){
				$m = date('n',strtotime('-'.$i.' month'));
				$d=[
					'month'=>$m.'月',
					'delivery_area'=>0,
					'receive_area'=>0,
					'finish_area'=>0
				];
				$data[]=$d;
			}
			$beginDate = date('Y-m-01',strtotime('-5 month'));
			
			$deliveryData = Db::table($this->tableName)
				->field([
					'month(delivery_time)'=>'m',
					'ifnull(sum(area_total),0)'=>'delivery_area',
				])
				->where('delivery_time','>=',$beginDate)
				->group('month(delivery_time)')
				->order('delivery_time')
				->select();
			$receiveData = Db::table($this->tableName)
				->field([
					'month(receive_time)'=>'m',
					'ifnull(sum(area_total),0)'=>'receive_area',
				])
				->where('receive_time','>=',$beginDate)
				->group('month(receive_time)')
				->order('receive_time')
				->select();
			$finishData = Db::table($this->tableName)
				->field([
					'month(review_time)'=>'m',
					'ifnull(sum(area_total),0)'=>'finish_area',
				])
				->where('review_time','>=',$beginDate)
				->group('month(review_time)')
				->order('review_time')
				->select();
			foreach($data as &$d){
				foreach($deliveryData as $item){
					if($d['month']==$item['m'].'月'){
						$d['delivery_area'] = $item['delivery_area'];
						break;
					}
				}
				foreach($receiveData as $item){
					if($d['month']==$item['m'].'月'){
						$d['receive_area'] = $item['receive_area'];
						break;
					}
				}
				foreach($finishData as $item){
					if($d['month']==$item['m'].'月'){
						$d['finish_area'] = $item['finish_area'];
						break;
					}
				}
			}
			
			$res->data = $data;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	private function qywxNotice($id){
		$car = Db::table($this->tableName)
			->alias('car')
			->field([
				'car.*',
				'task.no'=>'task_no',
				'task.project',
				'task.area_name',
				'task.salesman_unit',
				'task.receive_unit',
				'task.cy_load_area_total',
				'task.cy_finish_area_total',
				'task.create_user'=>'task_create_user_id'
			])
			->join('yyzx_delivery_task task','car.task_id = task.id')
			->where('car.id',$id)
			->find();
		$qywxUser = Db::table('sys_user')->where('id',$car['task_create_user_id'])->value('qywx_user');
		if($car['status']=='SUBMIT'){
			$qywx=new \Qywx;
			if($qywxUser){				
				$notice['to']['touser']=$qywxUser;
				$notice['content']['title']='您的发货任务['.$car['task_no'].']已安排发货车辆';
				$notice['content']['description']=
					'<div>项目名称：'.$car['project'].'</div><div>销售公司：'.$car['salesman_unit'].'</div><div>收货单位：'.$car['receive_unit'].'</div><div>发货工厂：'.$car['area_name'].'</div><div></div><div>车辆编号：'.$car['no'].'</div><div>装车面积：'.$car['area_total'].'㎡</div><div>车辆录入：'.$car['create_user_name'].'</div>';
				$notice["content"]["url"] = MOBILE_URL.'#/yyzx/deliveryTask/details/'.$car['task_id'];
				$qywx->sendCard($notice);
			}
		}elseif($car['status']=='FINISH'){
			$qywx=new \Qywx;
			if($qywxUser){				
				$notice['to']['touser']=$qywxUser;
				$notice['content']['title']='您的发货任务['.$car['task_no'].']已有车辆审核完成';
				$notice['content']['description']=
					'<div>项目名称：'.$car['project'].'</div><div>销售公司：'.$car['salesman_unit'].'</div><div>收货单位：'.$car['receive_unit'].'</div><div>发货工厂：'.$car['area_name'].'</div><div>完成进度：'.$car['cy_finish_area_total'].'㎡ / '.$car['cy_load_area_total'].'㎡</div><div></div><div>车辆编号：'.$car['no'].'</div><div>装车面积：'.$car['area_total'].'㎡</div><div>审核人员：'.$car['review_user_name'].'</div>';				
				$notice["content"]["url"]=MOBILE_URL.'#/yyzx/deliveryTask/details/'.$car['task_id'];
				$qywx->sendCard($notice);
			}
			$qywxUser = Db::table('sys_user')->where('id',$car['create_user_id'])->value('qywx_user');
			if($qywxUser){				
				$notice['to']['touser']=$qywxUser;
				$notice['content']['title']='您的发货车辆['.$car['no'].']已审核完成';
				$notice['content']['description']=
					'<div>项目名称：'.$car['project'].'</div><div>销售公司：'.$car['salesman_unit'].'</div><div>收货单位：'.$car['receive_unit'].'</div><div>发货工厂：'.$car['area_name'].'</div><div>装车面积：'.$car['area_total'].'㎡</div><div>审核人员：'.$car['review_user_name'].'</div>';
				$notice["content"]["url"]=MOBILE_URL.'#/cy/deliveryCar/details/'.$car['id'];
				$qywx->sendCard($notice);
			}
		}
		
	}

	public function getDetailsQrcode($id){
		$url = MOBILE_URL.'#/it/asset/details/'.$id;
		qrcodeImg($url,'Q',4);
	}

	/**
	* 获取统计数据
	* @param 
	*/
	public function getTimeStatistic($unit,$time_begin=null,$time_end=null){
		$res = model('Res');
		try{
			if(!$time_end){
				$time_end = date('Y-m-d');
			}
			if(!$time_begin){
				$time_begin = date('Y-m-d',strtotime($time_begin.' -10 '.$unit));
			}
			if($unit=='year'){
				$sqlFormat = '%Y';
				$format = 'Y';
				$time_begin = date('Y-01-01',strtotime($time_begin));
				$time_end = date('Y-12-31',strtotime($time_end));
			}elseif($unit=='month'){
				$sqlFormat = '%Y-%m';
				$format = 'Y-m';
				$time_begin = date('Y-m-01',strtotime($time_begin));
				$time_end = date('Y-m-31',strtotime($time_end));
			}elseif($unit=='day'){
				$sqlFormat = '%Y-%m-%d';
				$format = 'Y-m-d';
			}

			$data=[];
			$timeTemp = $time_begin;
			while ($timeTemp < $time_end) {
				$u = date($format,strtotime($timeTemp));
				$d=[
					'unit'=>$u,
					'price'=>0,
					'amount'=>0
				];
				$data[]=$d;
				$timeTemp = date('Y-m-d',strtotime($timeTemp.' +1 '.$unit));
			}

			$where = $this->getWhere();
			$list = Db::table( $this->tableName )
				->alias('asset')
				->field([
					'date_format(asset.inbound_date,\''.$sqlFormat.'\')'=>'unit',
					'ifnull(sum(asset.price),0)'=>'price',
					'sum(asset.amount)'=>'amount',
				])
				->where($where)
				->where('asset.inbound_date','>=',$time_begin)
				->where('asset.inbound_date','<=',$time_end)
				->group('date_format(asset.inbound_date,\''.$sqlFormat.'\')')
				->select();
			foreach($data as &$d){
				foreach($list as $item){
					if($d['unit']==$item['unit']){
						$d['price'] = $item['price'];
						$d['amount'] = $item['amount'];
						break;
					}
				}
			}
			$res->data = $data;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}
}