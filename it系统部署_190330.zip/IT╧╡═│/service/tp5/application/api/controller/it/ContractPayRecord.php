<?php
namespace app\api\controller\it;
use think\Db;
use app\api\controller\Auth;

//
class ContractPayRecord extends Auth{

	private $tableName = 'it_contract_pay_record';

	private function getWhere(){
		return function($query){
			$input_status=input('input_status');
			if($input_status!=null){
				$query->where('contract.input_status',$input_status);
			}
			$inUser = input('inUser'); 
			if($inUser){
				$query->where('contract.create_user_id',$this->user_id);
			}
			$inCompany = input('inCompany');
			if($inCompany){
				$companyIds = Db::table('sys_user')->where('id',$this->user_id)->value('company_ids');
				if($companyIds!=='*'){
					$query->where('contract.company_id','in',$companyIds);
				}
			}
			$contract_no=input('contract_no');
			if($contract_no){
				$query->where('contract.no','like','%'.$contract_no.'%');
			}
			$supplier_name = input('supplier_name');
			if($supplier_name){
				$query->where('supplier.name','like','%'.$supplier_name.'%');
			}
			//所属单位
			$company_ids=input("company_ids/a");
			if($company_ids){
				$query->where('contract.company_id','in',$company_ids);
			}
			$remarks = input('remarks');
			if($remarks){
				$query->where('pay.remarks','like','%'.$remarks.'%');
			}
			//
			$conctract_name=input("conctract_name");
			if($conctract_name){
				$query->where('contract.name','like','%'.$conctract_name.'%');
			}
			$contract_id=input("contract_id");
			if($contract_id){
				$query->where('contract.id',$contract_id);
			}
			//
			$pay_price_begin=input("pay_price_begin");
			if($pay_price_begin){
				$query->where('pay.pay_price','>=',$pay_price_begin);
			}
			$pay_price_end=input("pay_price_end");
			if($pay_price_end){
				$query->where('pay.pay_price','<=',$pay_price_end);
			}
			//
			$pay_date_begin=input("pay_date_begin");
			if($pay_date_begin){
				$query->where('pay.pay_date','>=',$pay_date_begin);
			}
			$pay_date_end=input("pay_date_end");
			if($pay_date_end){
				$query->where('pay.pay_date','<=',$pay_date_end);
			}
			//近期
			$isNear = input('get.isNear');
			if($isNear) {
				$nearDate = date('Y-m-d',strtotime('-10 days'));
				$query->where('pay.create_time','>=',$nearDate);
			}
		};
	}
			
	/*
	* 获取列表
	* 
	*/
	public function getList($currentPage=1,$pageSize=10,$noPage=0){
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$order = [];
			$sortProp=input('get.sortProp');
			if($sortProp){
				$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
			}else{
				$order['contract.create_time'] = 'desc';
			}
			$fields = [
				'pay.*',
				'contract.no'=>'contract_no',
				'contract.name'=>'contract_name',
				'company.name'=>'company_name',
				'supplier.name'=>'supplier_name',
				'supplier.id'=>'supplier_id'
			];
			$sql = Db::table( $this->tableName )
				->alias('pay')
				->field($fields)
				->join('it_contract contract','contract.id = pay.contract_id')
				->join('sys_company company','contract.company_id = company.id')
				->join('it_supplier supplier','contract.supplier_id = supplier.id')
				->where($where)
				->order($order);
			if($noPage){
				$list = $sql->select();
				$total = count($list);
			}else{
				$list = $sql->page($currentPage,$pageSize)->select();	
				$total = Db::table( $this->tableName )
					->alias('pay')					
					->join('it_contract contract','contract.id = pay.contract_id')
					->join('sys_company company','contract.company_id = company.id')
					->join('it_supplier supplier','contract.supplier_id = supplier.id')
					->where($where)
					->count();
			}
			$summary = Db::table( $this->tableName )
				->alias('pay')				
				->field([
					 'sum(pay.pay_price)'=>'pay_price'
				])
				->join('it_contract contract','contract.id = pay.contract_id')
				->join('sys_company company','contract.company_id = company.id')
				->join('it_supplier supplier','contract.supplier_id = supplier.id')
				->where($where)
				->find();
			$data['list'] = $list;
			$data['total'] = $total;			
			$data['summary'] = $summary;			
			$res->data=$data;	
			$res->code = 0;
		}catch(\Exception $e){
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}

/**
	* 创建或更新
	* @param 
	*/
	public function save() {
		$res=model('Res');
		Db::startTrans();
		try{
			$data = []; 
			$fields=[
				'contract_id','pay_price','pay_date','remarks','update_time','update_user_id'
			];
			$now = date('Y-m-d H:i:s');
			$post=input('post.');
			$post['update_time'] = $now;
			$post['update_user_id'] = $this->user_id;
			if(!$post['id']){
				$fields[] = 'create_time';
				$fields[] = 'create_user_id';
				$fields[] = 'create_user_name';
				$post['create_time'] = $now;				 
				$post['create_user_id'] = $this->userId;				 
				$post['create_user_name'] = Db::table('sys_user')->where('id',$this->user_id)->value('name');
				$post['id']=Db::table($this->tableName)->field($fields)->insertGetId($post);
			}else{
				$data = Db::table($this->tableName)->find($post['id']);
				if(!$data){
					throw new \Exception('找不到该付款信息！');
				}
				Db::table($this->tableName)->field($fields)->update($post);
			}
			$data = array_merge($data,$post);
			$res->data = [
				'id'=>$data['id']
			];
			$res->code=0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message = $e->getMessage();
		}
		return json($res);
	}

	/*
	* 删除发货车辆
	*/
	public function del($id){
		$res=model('Res');
		Db::startTrans();
		try{			
			$contract = Db::table($this->tableName)->find($id);
			if(!$contract){
				throw new \Exception('找不到该合同付款记录！');
			}
			Db::table( $this->tableName )->delete($id);
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}



	/**
	* 根据记录id获取表单数据
	* @param 
	*/
	public function getSummaryData() {
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$data = Db::table( $this->tableName )
				->alias('car')
				->field([
					'count(*)'=>'car_total',
					'sum(amount_total)'=>'amount_total',
					'sum(area_total)'=>'area_total',
				])
				->join('yyzx_delivery_task task','car.task_id=task.id')
				->where($where)
				->where('car.input_status','>=',0)
				->find();
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 根据打印信息
	* @param 
	*/
	public function getPrint($id) {
		$res=model('Res');
		try{
			$data = Db::table($this->tableName)
				->alias('car')
				->field([
					'car.*',
					'task.no'=>'task_no',
					'task.method',
					'task.receive_unit',
					'task.receive_address',
					'task.receive_name',
					'task.receive_tel',
					'task.contract_no',
					'task.fh_no',
					'task.project',
					'task.salesman_tel',
					'task.salesman_name',
					'task.remarks'=>'task_remarks',
					'task.create_user_name'=>'task_user_name'
				])
				->join('yyzx_delivery_task task','car.task_id = task.id')
				->find($id);
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 装车完成
	* @param 
	*/
	public function loadFinish($task_id) {
		$res=model('Res');
		try{
			$task = Db::table('yyzx_delivery_task')->find($task_id);
			if($task['load_finish_time']){
				throw new \Exception('该发货任务已装车完成，无法重复操作！');
			}
			$c = Db::table('cy_delivery_car')
				->where('input_status',0)
				->where('task_id',$task_id)
				->count();
			if($c>0){
				throw new \Exception('该发货任务仍有未提交的车辆，请删除或提交后再完成装车！');
			}
			Db::table('yyzx_delivery_task')
				->where('id',$task_id)
				->update([
					'status'=>'LOADEND',
					'load_finish_time'=>date('Y-m-d H:i:s')
				]);
			$qywxUser = Db::table('sys_user')->where('id',$task['create_user'])->value('qywx_user');
			if($qywxUser){
				$qywx=new \Qywx;
				$notice['to']['touser']=$qywxUser;
				$notice['content']['title']='您的发货任务['.$task['no'].']已完成装车';
				$notice['content']['description']=
					'<div>项目名称：'.$task['project'].'</div><div>销售公司：'.$task['salesman_unit'].'</div><div>收货单位：'.$task['receive_unit'].'</div><div>发货工厂：'.$task['area_name'].'</div><div>发货车辆：'.$task['cy_car_total'].'辆</div><div>装车面积：'.$task['cy_load_area_total'].'㎡</div>';
				$notice["content"]["url"]=MOBILE_URL.'#/yyzx/deliveryTask/details/'.$task['id'];
				$qywx->sendCard($notice);
			}
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 撤销装车完成提交
	* @param 
	*/
	public function undoLoadFinish($task_id) {
		$res=model('Res');
		try{
			$task = Db::table('yyzx_delivery_task')->find($task_id);
			if($task['confirm_time']){
				throw new \Exception('该发货任务已被运营中心确认，无法撤销！');
			}
			Db::table('yyzx_delivery_task')
				->where('id',$task_id)
				->update([
					'status'=>'SUBMIT',
					'load_finish_time'=>null
				]);
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message = $e->getMessage();
		}
		return json($res);
	}
	/**
	* 发货车辆审核
	* @param 
	*/
	public function review($id) {
		$res=model('Res');
		Db::startTrans();
		try{
			$userName = Db::table('sys_user')->where('id',$this->user_id)->value('name');
			$car = Db::table($this->tableName)->find($id);
			if(!$car){
				throw new \Exception('找不到发货车辆信息！');
			}
			if($car['input_status']!=1){
				throw new \Exception('该发货车辆仍未提交，请先进行提交！');
			}
			if($car['status']!='RECEIVE'){
				throw new \Exception('该发货车辆任务状态异常，请刷新后再尝试！');
			}
			Db::table($this->tableName)
				->where('id',$id)
				->update([
					'status'=>'FINISH',
					'review_time'=>date('Y-m-d H:i:s'),
					'review_user_id'=>$this->user_id,
					'review_user_name'=>$userName
				]);
			// $summary = Db::table('cy_delivery_car_product')			
			// 	->where([
			// 		'car_id'=>$id
			// 	])
			// 	->select();
			// foreach ($summary as $item) {
			// 	Db::table('yyzx_delivery_task_product')
			// 		->where('id',$item['product_id'])
			// 		->inc('cy_finish_amount_total',$item['amount'])
			// 		->inc('cy_finish_area_total',$item['area'])
			// 		->update();
			// }			
			Db::table('yyzx_delivery_task')
				->where('id',$car['task_id'])
				->inc('cy_finish_amount_total',$car['amount_total'])
				->inc('cy_finish_area_total',$car['area_total'])
				->inc('cy_finish_car_total')
				->dec('cy_receive_car_total')
				->update();
			$this->qywxNotice($id);
			$res->code = 0 ;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 撤销
	* @param 
	*/
	public function undo($id) {
		$res=model('Res');
		Db::startTrans();
		try{
			$car = Db::table($this->tableName)->find($id);
			if(!$car){
				throw new \Exception('找不到发货车辆信息！');
			}
			if($car['status']!='SUBMIT'){
				throw new \Exception('该车辆已发货，无法撤销！');
			}
			if($car['create_user_id']!=$this->user_id){
				throw new \Exception('您不是该车辆的录入员，无法进行操作！');
			}
			Db::table($this->tableName)
				->where('id',$id)
				->update([
					'status'=>null,
					'submit_time'=>null,
					'input_status'=>0
				]);			
			Db::table('yyzx_delivery_task')
				->where('id',$car['task_id'])
				->dec('cy_load_amount_total',$car['amount_total'])
				->dec('cy_load_area_total',$car['area_total'])
				->dec('cy_load_car_total')
				->dec('cy_car_total')
				->update([
					'load_time'=>null
				]);
			$res->code = 0 ;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 撤销审核
	* @param 
	*/
	public function undoReview($id) {
		$res=model('Res');
		Db::startTrans();
		try{
			$car = Db::table($this->tableName)->find($id);
			if(!$car){
				throw new \Exception('找不到发货车辆信息！');
			}
			if($car['status']!='FINISH'){
				throw new \Exception('该车辆还未审核完成，无法撤销审核！');
			}
			if($car['review_user_id']!=$this->user_id){
				throw new \Exception('您不是该车辆的审核人员，无法进行撤销！');
			}
			Db::table($this->tableName)
				->where('id',$id)
				->update([
					'status'=>'RECEIVE',
					'review_time'=>null
				]);			
			Db::table('yyzx_delivery_task')
				->where('id',$car['task_id'])
				->dec('cy_finish_amount_total',$car['amount_total'])
				->dec('cy_finish_area_total',$car['area_total'])
				->dec('cy_finish_car_total')
				->inc('cy_receive_car_total')
				->update();
			$res->code = 0 ;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 根据记录id获取
	* @param 
	*/
	public function getDetails($id) {
		$res=model('Res');
		try{
			$data = Db::table( $this->tableName )
				->alias('contract')
				->field([
					'contract.*',
					'company.name'=>'company_name',
					'supplier.name'=>'supplier_name'
				])
				->join('sys_company company','company.id = contract.company_id')
				->join('it_supplier supplier','supplier.id = contract.supplier_id')
				->where('contract.id',$id)
				->find();
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 修改发货车辆司机信息
	* @param 
	*/
	public function driverSupply($id) {
		$res=model('Res');
		try{
			$post = input('post.');
			$data = Db::table( $this->tableName )
				->alias('car')
				->field([
					'driver_no',
					'driver_name',
					'driver_unit',
					'driver_tel'
				])
				->where('id',$id)
				->update($post);
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}
	/**
	* 获取最近6个月的统计数据
	* @param 
	*/
	public function getNearMonthSummary(){
		$res = model('Res');
		try{
			$data=[];
			for($i=5;$i>=0;$i--){
				$m = date('n',strtotime('-'.$i.' month'));
				$d=[
					'month'=>$m.'月',
					'delivery_area'=>0,
					'receive_area'=>0,
					'finish_area'=>0
				];
				$data[]=$d;
			}
			$beginDate = date('Y-m-01',strtotime('-5 month'));
			
			$deliveryData = Db::table($this->tableName)
				->field([
					'month(delivery_time)'=>'m',
					'ifnull(sum(area_total),0)'=>'delivery_area',
				])
				->where('delivery_time','>=',$beginDate)
				->group('month(delivery_time)')
				->order('delivery_time')
				->select();
			$receiveData = Db::table($this->tableName)
				->field([
					'month(receive_time)'=>'m',
					'ifnull(sum(area_total),0)'=>'receive_area',
				])
				->where('receive_time','>=',$beginDate)
				->group('month(receive_time)')
				->order('receive_time')
				->select();
			$finishData = Db::table($this->tableName)
				->field([
					'month(review_time)'=>'m',
					'ifnull(sum(area_total),0)'=>'finish_area',
				])
				->where('review_time','>=',$beginDate)
				->group('month(review_time)')
				->order('review_time')
				->select();
			foreach($data as &$d){
				foreach($deliveryData as $item){
					if($d['month']==$item['m'].'月'){
						$d['delivery_area'] = $item['delivery_area'];
						break;
					}
				}
				foreach($receiveData as $item){
					if($d['month']==$item['m'].'月'){
						$d['receive_area'] = $item['receive_area'];
						break;
					}
				}
				foreach($finishData as $item){
					if($d['month']==$item['m'].'月'){
						$d['finish_area'] = $item['finish_area'];
						break;
					}
				}
			}
			
			$res->data = $data;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 获取统计数据
	* @param 
	*/
	public function getTimeStatistic($unit,$time_begin=null,$time_end=null){
		$res = model('Res');
		try{
			if(!$time_end){
				$time_end = date('Y-m-d');
			}
			if(!$time_begin){
				$time_begin = date('Y-m-d',strtotime($time_begin.' -9 '.$unit));
			}
			if($unit=='year'){
				$sqlFormat = '%Y';
				$format = 'Y';
				$time_begin = date('Y-01-01',strtotime($time_begin));
				$time_end = date('Y-12-31',strtotime($time_end));
			}elseif($unit=='month'){
				$sqlFormat = '%Y-%m';
				$format = 'Y-m';
				$time_begin = date('Y-m-01',strtotime($time_begin));
				$time_end = date('Y-m-31',strtotime($time_end));
			}elseif($unit=='day'){
				$sqlFormat = '%Y-%m-%d';
				$format = 'Y-m-d';
			}

			$data=[];
			$timeTemp = $time_begin;
			while ($timeTemp <= $time_end) {
				$u = date($format,strtotime($timeTemp));
				$d=[
					'unit'=>$u,
					'price'=>0,
					'amount'=>0
				];
				$data[]=$d;
				$timeTemp = date('Y-m-d',strtotime($timeTemp.' +1 '.$unit));
			}
			$where = $this->getWhere();
			$list = Db::table( $this->tableName )
				->alias('pay')
				->field([
					'date_format(pay.pay_date,\''.$sqlFormat.'\')'=>'unit',
					'ifnull(sum(pay.pay_price),0)'=>'price',
					'count(*)'=>'amount',
				])
				->join('it_contract contract','contract.id = pay.contract_id')
				->join('sys_company company','contract.company_id = company.id')
				->join('it_supplier supplier','contract.supplier_id = supplier.id')
				->where($where)
				->where('pay.pay_date','>=',$time_begin)
				->where('pay.pay_date','<=',$time_end)
				->group('date_format(pay.pay_date,\''.$sqlFormat.'\')')
				->select();
			foreach($data as &$d){
				foreach($list as $item){
					if($d['unit']==$item['unit']){
						$d['price'] = $item['price'];
						$d['amount'] = $item['amount'];
						break;
					}
				}
			}
			$res->data = $data;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	public function uploadAttach($id){
		return action('Attach/upload',['table_name'=>'it_contract','table_id'=>$id]);
	}
	public function delAttach($id){
		return action('Attach/del',['id'=>$id]);
	}
}