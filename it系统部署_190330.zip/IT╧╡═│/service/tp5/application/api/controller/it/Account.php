<?php
namespace app\api\controller\it;
use think\Db;
use app\api\controller\Auth;

//送货任务书
class Account extends Auth{

	private $tableName = 'it_account';

	private function getWhere(){
		return function($query){
			$input_status=input('input_status');
			if($input_status!=null){
				$query->where('account.input_status',$input_status);
			}
			$inUser = input('inUser'); 
			if($inUser){
				$query->where('account.create_user_id',$this->user_id);
			}
			$inCompany = input('inCompany');
			if($inCompany){
				$companyIds = Db::table('sys_user')->where('id',$this->user_id)->value('company_ids');
				if($companyIds!=='*'){
					$query->where('account.company_id','in',$companyIds);
				}
			}			
			//
			$name=input("name");
			if($name){
				$query->where('account.name','like','%'.$name.'%');
			}
			$login_address=input("login_address");
			if($login_address){
				$query->where('account.login_address','like','%'.$login_address.'%');
			}
			$account = input("account");
			if($account){
				$query->where('account.account','like','%'.$account.'%');
			}
			$remarks = input("remarks");
			if($remarks){
				$query->where('account.remarks','like','%'.$remarks.'%');
			}
			//近期
			$isNear = input('get.isNear');
			if($isNear) {
				$nearDate = date('Y-m-d',strtotime('-10 days'));
				$query->where('asset.create_time','>=',$nearDate);
			}
		};
	}
			
	/*
	* 获取列表
	* 
	*/
	public function getList($currentPage=1,$pageSize=10,$noPage=0){
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$order = [];
			$sortProp=input('get.sortProp');
			if($sortProp){
				$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
			}else{
				$order['account.create_time'] = 'desc';
			}
			$fields = [
				'account.*',
				'company.name'=>'company_name',
			];
			$sql = Db::table( $this->tableName )
				->alias('account')
				->field($fields)
				->join('sys_company company','account.company_id = company.id')
				->where($where)
				->where('account.input_status','>=',0)
				->order($order);
			if($noPage){
				$list = $sql->select();
				$total = count($list);
			}else{
				$list = $sql->page($currentPage,$pageSize)->select();	
				$total = Db::table( $this->tableName )
					->alias('account')					
					->join('sys_company company','account.company_id = company.id')
					->where($where)
					->where('account.input_status','>=',0)
					->count();
			}
			// $summary = Db::table( $this->tableName )
			// 	->alias('account')				
			// 	->field([
			// 		 'sum(contract.price)'=>'price'
			// 	])
			// 	->join('sys_company company','account.company_id = company.id')
			// 	->where($where)
			// 	->where('account.input_status','>=',0)
			// 	->find();
			$data['list'] = $list;
			$data['total'] = $total;			
			// $data['summary'] = $summary;			
			$res->data=$data;	
			$res->code = 0;
		}catch(\Exception $e){
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	
	/**
	* 根据记录id获取表单数据
	* @param 
	*/
	public function getForm($id) {
		$res=model('Res');
		try{
			$data = Db::table($this->tableName)
				->find($id);
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	*
	* @param 
	*/
	public function getTaskForm($id) {
		$res=model('Res');
		try{
			$data = Db::table('yyzx_delivery_task')
				->find($id);
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 新增资产
	*
	*/
	public function create(){	
		$res=model('Res');
		Db::startTrans();
		try{
			$data = Db::table($this->tableName)
				->field('id,create_user_id')
				->where([			
				'create_user_id'=>$this->user_id,
				'input_status'=>-1
			])->find();
			if(!$data){
				$data['create_user_id'] = $this->user_id;
				$id=Db::table( $this->tableName )->field('id',true)->insertGetId($data);
				if(!$id) throw new \Exception('新增失败');
				$data['id'] = $id;
			}
			$res->data = $data;
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->success = false;
			$res->message = $e->getMessage();
		}
		return json($res);
	}

	/**
	* 更新
	* @param 
	*/
	public function update($id) {
		$res=model('Res');
		Db::startTrans();
		try{
			$data = Db::table($this->tableName)->find($id);
			if(!$data){
				throw new \Exception('找不到该账号信息！');
			}
			$fields=[
				'input_status','company_id','name','login_address','account','password','remarks','update_time','update_user_id'
			];
			$now = date('Y-m-d H:i:s');
			$post=input('post.');
			if($data['input_status']==-1){
				$fields[] = 'create_time';
				$fields[] = 'create_user_name';
				$post['create_time'] = $now;				 
				$post['create_user_name'] = Db::table('sys_user')->where('id',$this->user_id)->value('name');
			}
			if($post['action']==1){
				$post['input_status'] = 1;
			}elseif($post['action']==0){
				$post['input_status'] = 0;
			}
			$post['update_time'] = $now;
			$post['update_user_id'] = $this->user_id;
			Db::table($this->tableName)->field($fields)->update($post);
			$data = array_merge($data,$post);
			$res->data = [
				'input_status'=>$data['input_status']
			];
			$res->code=0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message = $e->getMessage();
		}
		return json($res);
	}
	/*
	* 删除发货车辆
	*/
	public function del($id){
		$res=model('Res');
		Db::startTrans();
		try{			
			$contract = Db::table($this->tableName)->find($id);
			if(!$contract){
				throw new \Exception('找不到该合同信息！');
			}
			Db::table('attach')
				->where('id','in',$contract['attach_ids'])
				->update([
					'del_time'=>date('Y-m-d H:i:s'),
					'del_user_id'=>$this->userId
				]);
			Db::table( $this->tableName )->delete($id);
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 更新任务
	* @param 
	*/
	public function syncData($id) {
		$car = Db::table($this->tableName)->find($id);
		
		// $summary = Db::table('cy_delivery_car_product')
		// 	->alias('car_product')
		// 	->field([
		// 		'product.name',
		// 		'product.area',
		// 		'product.amount',
		// 		// 'sum(car_product.amount)'=>'cy_load_amount_total',
		// 		// 'sum(car_product.area)'=>'cy_load_area_total',
		// 		'car_product.amount',
		// 		'car_product.area',
		// 		'car_product.product_id'
		// 	])
		// 	->join('cy_delivery_car car','car_product.car_id = car.id')
		// 	->join('yyzx_delivery_task_product product','car_product.product_id = product.id')
		// 	->where([
		// 		'car_product.car_id'=>$car['id'],
		// 		'car.input_status'=>1
		// 	])
		// 	->group('car_product.product_id')
		// 	->select();
		// foreach ($summary as $item) {
		// 	// if($item['cy_load_area_total']>$item['area']){
		// 	// 	throw new \Exception('产品 [ '.$item['name'].' ] 的装车面积已大于产品面积，请检查车辆装车产品！');
		// 	// }
		// 	$sql = Db::table('yyzx_delivery_task_product')
		// 		->where('id',$item['product_id'])
		// 		->inc('cy_load_amount_total',$item['amount'])
		// 		->inc('cy_load_area_total',$item['area']);

		// 	if($car['delivery_time']){
		// 		$sql->inc('cy_delivery_amount_total',$item['amount'])
		// 			->inc('cy_delivery_area_total',$item['area']);
		// 	}
		// 	if($car['receive_time']){
		// 		$sql->inc('cy_receive_amount_total',$item['amount'])
		// 			->inc('cy_receive_area_total',$item['area']);
		// 	}
		// 	$sql->update();
		// }
		
		$sql = Db::table('yyzx_delivery_task')
			->where('id',$car['task_id'])
			->inc('cy_car_total')
			->inc('cy_load_area_total',$car['area_total'])
			->inc('cy_load_amount_total',$car['amount_total']);
		if($car['delivery_time']){
			$sql->inc('cy_delivery_area_total',$car['area_total'])->inc('cy_delivery_amount_total',$car['amount_total']);
		}
		if($car['receive_time']){
			$sql->inc('cy_receive_area_total',$car['area_total'])->inc('cy_receive_amount_total',$car['amount_total']);
		}
		if($car['status']=='SUBMIT'){
			$sql->inc('cy_load_car_total');
		}elseif($car['status']=='DELIVERY'){
			$sql->inc('cy_delivery_car_total');
		}elseif($car['status']=='RECEIVE'){
			$sql->inc('cy_receive_car_total');
		}
		return $sql->update();
	}
	
	/**
	* 根据记录id获取表单数据
	* @param 
	*/
	public function getSummaryData() {
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$data = Db::table( $this->tableName )
				->alias('car')
				->field([
					'count(*)'=>'car_total',
					'sum(amount_total)'=>'amount_total',
					'sum(area_total)'=>'area_total',
				])
				->join('yyzx_delivery_task task','car.task_id=task.id')
				->where($where)
				->where('car.input_status','>=',0)
				->find();
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 根据打印信息
	* @param 
	*/
	public function getPrint($id) {
		$res=model('Res');
		try{
			$data = Db::table($this->tableName)
				->alias('car')
				->field([
					'car.*',
					'task.no'=>'task_no',
					'task.method',
					'task.receive_unit',
					'task.receive_address',
					'task.receive_name',
					'task.receive_tel',
					'task.contract_no',
					'task.fh_no',
					'task.project',
					'task.salesman_tel',
					'task.salesman_name',
					'task.remarks'=>'task_remarks',
					'task.create_user_name'=>'task_user_name'
				])
				->join('yyzx_delivery_task task','car.task_id = task.id')
				->find($id);
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 装车完成
	* @param 
	*/
	public function loadFinish($task_id) {
		$res=model('Res');
		try{
			$task = Db::table('yyzx_delivery_task')->find($task_id);
			if($task['load_finish_time']){
				throw new \Exception('该发货任务已装车完成，无法重复操作！');
			}
			$c = Db::table('cy_delivery_car')
				->where('input_status',0)
				->where('task_id',$task_id)
				->count();
			if($c>0){
				throw new \Exception('该发货任务仍有未提交的车辆，请删除或提交后再完成装车！');
			}
			Db::table('yyzx_delivery_task')
				->where('id',$task_id)
				->update([
					'status'=>'LOADEND',
					'load_finish_time'=>date('Y-m-d H:i:s')
				]);
			$qywxUser = Db::table('sys_user')->where('id',$task['create_user'])->value('qywx_user');
			if($qywxUser){
				$qywx=new \Qywx;
				$notice['to']['touser']=$qywxUser;
				$notice['content']['title']='您的发货任务['.$task['no'].']已完成装车';
				$notice['content']['description']=
					'<div>项目名称：'.$task['project'].'</div><div>销售公司：'.$task['salesman_unit'].'</div><div>收货单位：'.$task['receive_unit'].'</div><div>发货工厂：'.$task['area_name'].'</div><div>发货车辆：'.$task['cy_car_total'].'辆</div><div>装车面积：'.$task['cy_load_area_total'].'㎡</div>';
				$notice["content"]["url"]=MOBILE_URL.'#/yyzx/deliveryTask/details/'.$task['id'];
				$qywx->sendCard($notice);
			}
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 撤销装车完成提交
	* @param 
	*/
	public function undoLoadFinish($task_id) {
		$res=model('Res');
		try{
			$task = Db::table('yyzx_delivery_task')->find($task_id);
			if($task['confirm_time']){
				throw new \Exception('该发货任务已被运营中心确认，无法撤销！');
			}
			Db::table('yyzx_delivery_task')
				->where('id',$task_id)
				->update([
					'status'=>'SUBMIT',
					'load_finish_time'=>null
				]);
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message = $e->getMessage();
		}
		return json($res);
	}
	/**
	* 发货车辆审核
	* @param 
	*/
	public function review($id) {
		$res=model('Res');
		Db::startTrans();
		try{
			$userName = Db::table('sys_user')->where('id',$this->user_id)->value('name');
			$car = Db::table($this->tableName)->find($id);
			if(!$car){
				throw new \Exception('找不到发货车辆信息！');
			}
			if($car['input_status']!=1){
				throw new \Exception('该发货车辆仍未提交，请先进行提交！');
			}
			if($car['status']!='RECEIVE'){
				throw new \Exception('该发货车辆任务状态异常，请刷新后再尝试！');
			}
			Db::table($this->tableName)
				->where('id',$id)
				->update([
					'status'=>'FINISH',
					'review_time'=>date('Y-m-d H:i:s'),
					'review_user_id'=>$this->user_id,
					'review_user_name'=>$userName
				]);
			// $summary = Db::table('cy_delivery_car_product')			
			// 	->where([
			// 		'car_id'=>$id
			// 	])
			// 	->select();
			// foreach ($summary as $item) {
			// 	Db::table('yyzx_delivery_task_product')
			// 		->where('id',$item['product_id'])
			// 		->inc('cy_finish_amount_total',$item['amount'])
			// 		->inc('cy_finish_area_total',$item['area'])
			// 		->update();
			// }			
			Db::table('yyzx_delivery_task')
				->where('id',$car['task_id'])
				->inc('cy_finish_amount_total',$car['amount_total'])
				->inc('cy_finish_area_total',$car['area_total'])
				->inc('cy_finish_car_total')
				->dec('cy_receive_car_total')
				->update();
			$this->qywxNotice($id);
			$res->code = 0 ;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 撤销
	* @param 
	*/
	public function undo($id) {
		$res=model('Res');
		Db::startTrans();
		try{
			$car = Db::table($this->tableName)->find($id);
			if(!$car){
				throw new \Exception('找不到发货车辆信息！');
			}
			if($car['status']!='SUBMIT'){
				throw new \Exception('该车辆已发货，无法撤销！');
			}
			if($car['create_user_id']!=$this->user_id){
				throw new \Exception('您不是该车辆的录入员，无法进行操作！');
			}
			Db::table($this->tableName)
				->where('id',$id)
				->update([
					'status'=>null,
					'submit_time'=>null,
					'input_status'=>0
				]);			
			Db::table('yyzx_delivery_task')
				->where('id',$car['task_id'])
				->dec('cy_load_amount_total',$car['amount_total'])
				->dec('cy_load_area_total',$car['area_total'])
				->dec('cy_load_car_total')
				->dec('cy_car_total')
				->update([
					'load_time'=>null
				]);
			$res->code = 0 ;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 撤销审核
	* @param 
	*/
	public function undoReview($id) {
		$res=model('Res');
		Db::startTrans();
		try{
			$car = Db::table($this->tableName)->find($id);
			if(!$car){
				throw new \Exception('找不到发货车辆信息！');
			}
			if($car['status']!='FINISH'){
				throw new \Exception('该车辆还未审核完成，无法撤销审核！');
			}
			if($car['review_user_id']!=$this->user_id){
				throw new \Exception('您不是该车辆的审核人员，无法进行撤销！');
			}
			Db::table($this->tableName)
				->where('id',$id)
				->update([
					'status'=>'RECEIVE',
					'review_time'=>null
				]);			
			Db::table('yyzx_delivery_task')
				->where('id',$car['task_id'])
				->dec('cy_finish_amount_total',$car['amount_total'])
				->dec('cy_finish_area_total',$car['area_total'])
				->dec('cy_finish_car_total')
				->inc('cy_receive_car_total')
				->update();
			$res->code = 0 ;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 根据记录id获取
	* @param 
	*/
	public function getDetails($id) {
		$res=model('Res');
		try{
			$data = Db::table( $this->tableName )
				->alias('asset')
				->field([
					'asset.*',
					'asset.amount - asset.scrap_amount - asset.used'=>'remain',
					'asset.amount - asset.scrap_amount'=>'avaiable_amount'
				])
				->where('asset.id',$id)
				->find();
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 修改发货车辆司机信息
	* @param 
	*/
	public function driverSupply($id) {
		$res=model('Res');
		try{
			$post = input('post.');
			$data = Db::table( $this->tableName )
				->alias('car')
				->field([
					'driver_no',
					'driver_name',
					'driver_unit',
					'driver_tel'
				])
				->where('id',$id)
				->update($post);
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 导出excel
	* @param 
	*/
	public function exportExcel(){
		$titles = [ 
			'no'=>'车辆编号',
			'status'=>'车辆状态',
			'task_no'=>'任务编号',
			'project' => '项目名称',//项目名称
			'contract_no' => '合同号',//客户名称
			'salesman_unit' => '销售公司',//业绩公司
			'salesman_name'=>'业务员',
			'salesman_tel'=>'业务员联系电话',
			'db_no'=>'调拨单号',
			'fh_no'=>'发货申请编号',
			'area_name'=>'发货工厂',
			'receive_unit'=>'收货单位',
			'receive_address'=>'收货地址',
			'receive_name'=>'收货人',
			'receive_tel'=>'收货人联系电话',
			'amount_total'=>'装车数量',
			'area_total'=>'装车面积（㎡）',
			'delivery_time'=>'发货时间',
			'receive_time'=>'签收时间',
			'review_time'=>'审核完成时间',
			'create_user_name'=>'录入员',
			'create_time'=>'创建时间',
			'submit_time'=>'提交时间',
		];		
		$where = $this->getWhere();
		$order = [];
		$sortProp=input('get.sortProp');
		if($sortProp){
			$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
		}else{
			$order['car.id'] = 'desc';
		}
		$fields = [
			'car.*',
			'task.no'=>'task_no',
			'task.area_name'=>'area_name',
			'task.project',
			'task.contract_no',
			'task.db_no',
			'task.fh_no',
			'task.salesman_unit',
			'task.salesman_name',
			'task.salesman_tel',
			'task.plan_send_date',
			'task.receive_unit',
			'task.method',
			'task.receive_address',
			'task.receive_name',
			'task.receive_tel'
		];
		$list = Db::table( $this->tableName )
			->alias('car')
			->field($fields)
			->join('yyzx_delivery_task task','car.task_id=task.id')
			->where($where)
			->where('car.input_status','>=',0)
			->order($order)
			->select();
		exportExcel($list,$titles,'发货车辆列表');
	}

	/**
	* 获取最近6个月的统计数据
	* @param 
	*/
	public function getNearMonthSummary(){
		$res = model('Res');
		try{
			$data=[];
			for($i=5;$i>=0;$i--){
				$m = date('n',strtotime('-'.$i.' month'));
				$d=[
					'month'=>$m.'月',
					'delivery_area'=>0,
					'receive_area'=>0,
					'finish_area'=>0
				];
				$data[]=$d;
			}
			$beginDate = date('Y-m-01',strtotime('-5 month'));
			
			$deliveryData = Db::table($this->tableName)
				->field([
					'month(delivery_time)'=>'m',
					'ifnull(sum(area_total),0)'=>'delivery_area',
				])
				->where('delivery_time','>=',$beginDate)
				->group('month(delivery_time)')
				->order('delivery_time')
				->select();
			$receiveData = Db::table($this->tableName)
				->field([
					'month(receive_time)'=>'m',
					'ifnull(sum(area_total),0)'=>'receive_area',
				])
				->where('receive_time','>=',$beginDate)
				->group('month(receive_time)')
				->order('receive_time')
				->select();
			$finishData = Db::table($this->tableName)
				->field([
					'month(review_time)'=>'m',
					'ifnull(sum(area_total),0)'=>'finish_area',
				])
				->where('review_time','>=',$beginDate)
				->group('month(review_time)')
				->order('review_time')
				->select();
			foreach($data as &$d){
				foreach($deliveryData as $item){
					if($d['month']==$item['m'].'月'){
						$d['delivery_area'] = $item['delivery_area'];
						break;
					}
				}
				foreach($receiveData as $item){
					if($d['month']==$item['m'].'月'){
						$d['receive_area'] = $item['receive_area'];
						break;
					}
				}
				foreach($finishData as $item){
					if($d['month']==$item['m'].'月'){
						$d['finish_area'] = $item['finish_area'];
						break;
					}
				}
			}
			
			$res->data = $data;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	private function qywxNotice($id){
		$car = Db::table($this->tableName)
			->alias('car')
			->field([
				'car.*',
				'task.no'=>'task_no',
				'task.project',
				'task.area_name',
				'task.salesman_unit',
				'task.receive_unit',
				'task.cy_load_area_total',
				'task.cy_finish_area_total',
				'task.create_user'=>'task_create_user_id'
			])
			->join('yyzx_delivery_task task','car.task_id = task.id')
			->where('car.id',$id)
			->find();
		$qywxUser = Db::table('sys_user')->where('id',$car['task_create_user_id'])->value('qywx_user');
		if($car['status']=='SUBMIT'){
			$qywx=new \Qywx;
			if($qywxUser){				
				$notice['to']['touser']=$qywxUser;
				$notice['content']['title']='您的发货任务['.$car['task_no'].']已安排发货车辆';
				$notice['content']['description']=
					'<div>项目名称：'.$car['project'].'</div><div>销售公司：'.$car['salesman_unit'].'</div><div>收货单位：'.$car['receive_unit'].'</div><div>发货工厂：'.$car['area_name'].'</div><div></div><div>车辆编号：'.$car['no'].'</div><div>装车面积：'.$car['area_total'].'㎡</div><div>车辆录入：'.$car['create_user_name'].'</div>';
				$notice["content"]["url"] = MOBILE_URL.'#/yyzx/deliveryTask/details/'.$car['task_id'];
				$qywx->sendCard($notice);
			}
		}elseif($car['status']=='FINISH'){
			$qywx=new \Qywx;
			if($qywxUser){				
				$notice['to']['touser']=$qywxUser;
				$notice['content']['title']='您的发货任务['.$car['task_no'].']已有车辆审核完成';
				$notice['content']['description']=
					'<div>项目名称：'.$car['project'].'</div><div>销售公司：'.$car['salesman_unit'].'</div><div>收货单位：'.$car['receive_unit'].'</div><div>发货工厂：'.$car['area_name'].'</div><div>完成进度：'.$car['cy_finish_area_total'].'㎡ / '.$car['cy_load_area_total'].'㎡</div><div></div><div>车辆编号：'.$car['no'].'</div><div>装车面积：'.$car['area_total'].'㎡</div><div>审核人员：'.$car['review_user_name'].'</div>';				
				$notice["content"]["url"]=MOBILE_URL.'#/yyzx/deliveryTask/details/'.$car['task_id'];
				$qywx->sendCard($notice);
			}
			$qywxUser = Db::table('sys_user')->where('id',$car['create_user_id'])->value('qywx_user');
			if($qywxUser){				
				$notice['to']['touser']=$qywxUser;
				$notice['content']['title']='您的发货车辆['.$car['no'].']已审核完成';
				$notice['content']['description']=
					'<div>项目名称：'.$car['project'].'</div><div>销售公司：'.$car['salesman_unit'].'</div><div>收货单位：'.$car['receive_unit'].'</div><div>发货工厂：'.$car['area_name'].'</div><div>装车面积：'.$car['area_total'].'㎡</div><div>审核人员：'.$car['review_user_name'].'</div>';
				$notice["content"]["url"]=MOBILE_URL.'#/cy/deliveryCar/details/'.$car['id'];
				$qywx->sendCard($notice);
			}
		}
		
	}

	public function getDetailsQrcode($id){
		$url = MOBILE_URL.'#/it/asset/details/'.$id;
		qrcodeImg($url,'Q',4);
	}

	/**
	* 获取统计数据
	* @param 
	*/
	public function getTimeStatistic($unit,$time_begin=null,$time_end=null){
		$res = model('Res');
		try{
			if(!$time_end){
				$time_end = date('Y-m-d');
			}
			if(!$time_begin){
				$time_begin = date('Y-m-d',strtotime($time_begin.' -9 '.$unit));
			}
			if($unit=='year'){
				$sqlFormat = '%Y';
				$format = 'Y';
				$time_begin = date('Y-01-01',strtotime($time_begin));
				$time_end = date('Y-12-31',strtotime($time_end));
			}elseif($unit=='month'){
				$sqlFormat = '%Y-%m';
				$format = 'Y-m';
				$time_begin = date('Y-m-01',strtotime($time_begin));
				$time_end = date('Y-m-31',strtotime($time_end));
			}elseif($unit=='day'){
				$sqlFormat = '%Y-%m-%d';
				$format = 'Y-m-d';
			}

			$data=[];
			$timeTemp = $time_begin;
			while ($timeTemp <= $time_end) {
				$u = date($format,strtotime($timeTemp));
				$d=[
					'unit'=>$u,
					'price'=>0,
					'amount'=>0
				];
				$data[]=$d;
				$timeTemp = date('Y-m-d',strtotime($timeTemp.' +1 '.$unit));
			}
			$where = $this->getWhere();
			$list = Db::table( $this->tableName )
				->alias('asset')
				->field([
					'date_format(asset.inbound_date,\''.$sqlFormat.'\')'=>'unit',
					'ifnull(sum(asset.price),0)'=>'price',
					'sum(asset.amount)'=>'amount',
				])
				->where($where)
				->where('asset.inbound_date','>=',$time_begin)
				->where('asset.inbound_date','<=',$time_end)
				->group('date_format(asset.inbound_date,\''.$sqlFormat.'\')')
				->select();
			foreach($data as &$d){
				foreach($list as $item){
					if($d['unit']==$item['unit']){
						$d['price'] = $item['price'];
						$d['amount'] = $item['amount'];
						break;
					}
				}
			}
			$res->data = $data;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}
}