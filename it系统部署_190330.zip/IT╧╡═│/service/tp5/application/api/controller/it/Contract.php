<?php
namespace app\api\controller\it;
use think\Db;
use app\api\controller\Auth;

//送货任务书
class Contract extends Auth{

	private $tableName = 'it_contract';

	private function getWhere(){
		return function($query){
			$input_status=input('input_status');
			if($input_status!=null){
				$query->where('contract.input_status',$input_status);
			}
			$inUser = input('inUser'); 
			if($inUser){
				$query->where('contract.create_user_id',$this->user_id);
			}
			$inCompany = input('inCompany');
			if($inCompany){
				$companyIds = Db::table('sys_user')->where('id',$this->user_id)->value('company_ids');
				if($companyIds!=='*'){
					$query->where('contract.company_id','in',$companyIds);
				}
			}
			$keyword=input('keyword');
			if($keyword){
				$query->where('contract.no|contract.name','like','%'.$keyword.'%');
			}
			$no=input('no');
			if($no){
				$query->where('contract.no','like','%'.$no.'%');
			}
			$supplier_name = input('supplier_name');
			if($supplier_name){
				$query->where('supplier.name','like','%'.$supplier_name.'%');
			}
			//所属单位
			$company_ids=input("company_ids/a");
			if($company_ids){
				$query->where('contract.company_id','in',$company_ids);
			}
			$toExpire = input("toExpire");
			if($toExpire){
				$date1 = date('Y-m-d',strtotime('+1 month'));
				$query->where('contract.end_date','<=',$date1);
				$query->where('contract.end_date','>=',date('Y-m-d'));
				$query->where('contract.is_remind',1);
			}
			$toPay = input("toPay");
			if($toPay){
				$query->where('contract.price > ifnull(pay.pay_price_total,0)');
			}
			//
			$name=input("name");
			if($name){
				$query->where('contract.name','like','%'.$name.'%');
			}
			$remarks = input('remarks');
			if($remarks){
				$query->where('contract.remarks','like','%'.$remarks.'%');
			}
			//
			$price_begin=input("price_begin");
			if($price_begin){
				$query->where('contract.price','>=',$price_begin);
			}
			$price_end=input("price_end");
			if($price_end){
				$query->where('contract.price','<=',$price_end);
			}
			//
			$sign_date_begin=input("sign_date_begin");
			if($sign_date_begin){
				$query->where('contract.sign_date','>=',$sign_date_begin);
			}
			$sign_date_end=input("sign_date_end");
			if($sign_date_end){
				$query->where('contract.sign_date','<=',$sign_date_end);
			}
			$begin_date_begin=input("begin_date_begin");
			if($begin_date_begin){
				$query->where('contract.begin_date','>=',$begin_date_begin);
			}
			$begin_date_end=input("begin_date_end");
			if($begin_date_end){
				$query->where('contract.begin_date','<=',$begin_date_end);
			}
			$end_date_begin=input("end_date_begin");
			if($end_date_begin){
				$query->where('contract.end_date','>=',$end_date_begin);
			}
			$end_date_end=input("end_date_end");
			if($end_date_end){
				$query->where('contract.end_date','<=',$end_date_end);
			}
			//近期
			$isNear = input('get.isNear');
			if($isNear) {
				$nearDate = date('Y-m-d',strtotime('-10 days'));
				$query->where('contract.create_time','>=',$nearDate);
			}
		};
	}
			
	/*
	* 获取列表
	* 
	*/
	public function getList($currentPage=1,$pageSize=10,$noPage=0){
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$order = [];
			$sortProp=input('get.sortProp');
			if($sortProp){
				$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
			}else{
				$order['contract.create_time'] = 'desc';
			}
			$fields = [
				'contract.*',
				'ifnull(pay.pay_price_total,0)'=>'pay_price_total',
				'pay.last_pay_date',
				'contract.price - ifnull(pay.pay_price_total,0)'=>'unpay',
				'round(ifnull(pay.pay_price_total,0) / contract.price * 100,2)'=>'pay_progress',
				'company.name'=>'company_name',
				'supplier.name'=>'supplier_name'
			];
			$subSql = Db::table('it_contract_pay_record')
				->field([
					'sum(pay_price)'=>'pay_price_total',
					'contract_id',
					'max(pay_date)'=>'last_pay_date'
				])
				->group('contract_id')
				->buildSql();
			$sql = Db::table( $this->tableName )
				->alias('contract')
				->field($fields)
				->join($subSql.' pay','pay.contract_id = contract.id','left')
				->join('sys_company company','contract.company_id = company.id')
				->join('it_supplier supplier','contract.supplier_id = supplier.id')
				->where($where)
				->where('contract.input_status','>=',0)
				->order($order);
			if($noPage){
				$list = $sql->select();
				$total = count($list);
			}else{
				$list = $sql->page($currentPage,$pageSize)->select();	
				$total = Db::table( $this->tableName )
					->alias('contract')					
					->join($subSql.' pay','pay.contract_id = contract.id','left')
					->join('sys_company company','contract.company_id = company.id')
					->join('it_supplier supplier','contract.supplier_id = supplier.id')
					->where($where)
					->where('contract.input_status','>=',0)
					->count();
			}
			$summary = Db::table( $this->tableName )
				->alias('contract')				
				->field([
					 'sum(contract.price)'=>'price'
				])
				->join($subSql.' pay','pay.contract_id = contract.id','left')
				->join('sys_company company','contract.company_id = company.id')
				->join('it_supplier supplier','contract.supplier_id = supplier.id')
				->where($where)
				->where('contract.input_status','>=',0)
				->find();
			$data['list'] = $list;
			$data['total'] = $total;			
			$data['summary'] = $summary;			
			$res->data=$data;	
			$res->code = 0;
		}catch(\Exception $e){
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	
	/**
	* 根据记录id获取表单数据
	* @param 
	*/
	public function getForm($id) {
		$res=model('Res');
		try{
			$data = Db::table($this->tableName)
				->find($id);
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	*
	* @param 
	*/
	public function getTaskForm($id) {
		$res=model('Res');
		try{
			$data = Db::table('yyzx_delivery_task')
				->find($id);
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 新增资产
	*
	*/
	public function create(){	
		$res=model('Res');
		Db::startTrans();
		try{
			$data = Db::table($this->tableName)
				->field('id,create_user_id,attach_ids')
				->where([			
				'create_user_id'=>$this->user_id,
				'input_status'=>-1
			])->find();
			if(!$data){
				$data['create_user_id'] = $this->user_id;
				$id=Db::table( $this->tableName )->field('id',true)->insertGetId($data);
				if(!$id) throw new \Exception('新增失败');
				$data['id'] = $id;
			}
			$res->data = $data;
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->success = false;
			$res->message = $e->getMessage();
		}
		return json($res);
	}

	/**
	* 更新
	* @param 
	*/
	public function update($id) {
		$res=model('Res');
		Db::startTrans();
		try{
			$data = Db::table($this->tableName)->find($id);
			if(!$data){
				throw new \Exception('找不到该合同信息！');
			}
			$fields=[
				'input_status','company_id','supplier_id','no','name','price','pay','sign_date','begin_date','end_date','is_remind','remarks','update_time','update_user_id'
			];
			$now = date('Y-m-d H:i:s');
			$post=input('post.');
			if(!$post['end_date']){
				$post['end_date'] = null;
			}
			if($data['input_status']==-1){
				$fields[] = 'create_time';
				$fields[] = 'create_user_name';
				$post['create_time'] = $now;				 
				$post['create_user_name'] = Db::table('sys_user')->where('id',$this->user_id)->value('name');
			}
			if($post['action']==1){
				$post['input_status'] = 1;
			}elseif($post['action']==0){
				$post['input_status'] = 0;
			}
			$post['update_time'] = $now;
			$post['update_user_id'] = $this->user_id;
			Db::table($this->tableName)->field($fields)->update($post);
			$data = array_merge($data,$post);
			$res->data = [
				'input_status'=>$data['input_status']
			];
			$res->code=0;
			Db::commit();
			if(isset($post['create_time'])){
				$notice = controller('Notice','helper');
				$notice->sendQywxMessage('IT_CONTRACT_CREATE',$data);
			}	
		}catch(\Exception $e){
			Db::rollback();
			$res->message = $e->getMessage();
		}
		return json($res);
	}
	/*
	* 删除发货车辆
	*/
	public function del($id){
		$res=model('Res');
		Db::startTrans();
		try{			
			$contract = Db::table($this->tableName)->find($id);
			if(!$contract){
				throw new \Exception('找不到该合同信息！');
			}
			if(Db::table('it_contract_pay_record')->where('contract_id',$id)->count()>0){
				throw new \Exception('该合同有付款记录，请先删除付款记录再进行删除！');
			}
			Db::table('attach')
				->where('id','in',$contract['attach_ids'])
				->update([
					'del_time'=>date('Y-m-d H:i:s'),
					'del_user_id'=>$this->userId
				]);
			Db::table( $this->tableName )->delete($id);
			$res->code = 0;
			Db::commit();
		}catch(\Exception $e){
			Db::rollback();
			$res->success=false;
			$res->message=$e->getMessage();
		}
		return json($res);
	}
	

	/**
	* 根据记录id获取表单数据
	* @param 
	*/
	public function getSummaryData() {
		$res=model('Res');
		try{
			$where = $this->getWhere();
			$data = Db::table( $this->tableName )
				->alias('car')
				->field([
					'count(*)'=>'car_total',
					'sum(amount_total)'=>'amount_total',
					'sum(area_total)'=>'area_total',
				])
				->join('yyzx_delivery_task task','car.task_id=task.id')
				->where($where)
				->where('car.input_status','>=',0)
				->find();
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 根据打印信息
	* @param 
	*/
	public function getPrint($id) {
		$res=model('Res');
		try{
			$data = Db::table($this->tableName)
				->alias('car')
				->field([
					'car.*',
					'task.no'=>'task_no',
					'task.method',
					'task.receive_unit',
					'task.receive_address',
					'task.receive_name',
					'task.receive_tel',
					'task.contract_no',
					'task.fh_no',
					'task.project',
					'task.salesman_tel',
					'task.salesman_name',
					'task.remarks'=>'task_remarks',
					'task.create_user_name'=>'task_user_name'
				])
				->join('yyzx_delivery_task task','car.task_id = task.id')
				->find($id);
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}


	/**
	* 根据记录id获取
	* @param 
	*/
	public function getDetails($id) {
		$res=model('Res');
		try{
			$data = Db::table( $this->tableName )
				->alias('contract')
				->field([
					'contract.*',
					'company.name'=>'company_name',
					'supplier.name'=>'supplier_name'
				])
				->join('sys_company company','company.id = contract.company_id')
				->join('it_supplier supplier','supplier.id = contract.supplier_id')
				->where('contract.id',$id)
				->find();
			$summary = Db::table('it_contract_pay_record')
				->field([
					'ifnull(sum(pay_price),0)'=>'pay_price_total',
					'max(pay_date)'=>'last_pay_date'
				])
				->where('contract_id',$id)
				->find();
			$data['pay_price_total'] = $summary['pay_price_total'];
			$data['unpay'] = $data['price'] - $summary['pay_price_total'];
			$data['last_pay_date'] = $summary['last_pay_date'];
			$res->data = $data;
			$res->code = 0 ;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 导出excel
	* @param 
	*/
	public function exportExcel(){
		$titles = [ 
			'no'=>'车辆编号',
			'status'=>'车辆状态',
			'task_no'=>'任务编号',
			'project' => '项目名称',//项目名称
			'contract_no' => '合同号',//客户名称
			'salesman_unit' => '销售公司',//业绩公司
			'salesman_name'=>'业务员',
			'salesman_tel'=>'业务员联系电话',
			'db_no'=>'调拨单号',
			'fh_no'=>'发货申请编号',
			'area_name'=>'发货工厂',
			'receive_unit'=>'收货单位',
			'receive_address'=>'收货地址',
			'receive_name'=>'收货人',
			'receive_tel'=>'收货人联系电话',
			'amount_total'=>'装车数量',
			'area_total'=>'装车面积（㎡）',
			'delivery_time'=>'发货时间',
			'receive_time'=>'签收时间',
			'review_time'=>'审核完成时间',
			'create_user_name'=>'录入员',
			'create_time'=>'创建时间',
			'submit_time'=>'提交时间',
		];		
		$where = $this->getWhere();
		$order = [];
		$sortProp=input('get.sortProp');
		if($sortProp){
			$order[$sortProp]=input('get.sortOrder')=='ascending'?'':'desc';
		}else{
			$order['car.id'] = 'desc';
		}
		$fields = [
			'car.*',
			'task.no'=>'task_no',
			'task.area_name'=>'area_name',
			'task.project',
			'task.contract_no',
			'task.db_no',
			'task.fh_no',
			'task.salesman_unit',
			'task.salesman_name',
			'task.salesman_tel',
			'task.plan_send_date',
			'task.receive_unit',
			'task.method',
			'task.receive_address',
			'task.receive_name',
			'task.receive_tel'
		];
		$list = Db::table( $this->tableName )
			->alias('car')
			->field($fields)
			->join('yyzx_delivery_task task','car.task_id=task.id')
			->where($where)
			->where('car.input_status','>=',0)
			->order($order)
			->select();
		exportExcel($list,$titles,'发货车辆列表');
	}

	public function getDetailsQrcode($id){
		$url = MOBILE_URL.'#/it/contract/details/'.$id;
		qrcodeImg($url,'Q',4);
	}

	/**
	* 获取统计数据
	* @param 
	*/
	public function getTimeStatistic($unit,$time_begin=null,$time_end=null){
		$res = model('Res');
		try{
			if(!$time_end){
				$time_end = date('Y-m-d');
			}
			if(!$time_begin){
				$time_begin = date('Y-m-d',strtotime($time_begin.' -9 '.$unit));
			}
			if($unit=='year'){
				$sqlFormat = '%Y';
				$format = 'Y';
				$time_begin = date('Y-01-01',strtotime($time_begin));
				$time_end = date('Y-12-31',strtotime($time_end));
			}elseif($unit=='month'){
				$sqlFormat = '%Y-%m';
				$format = 'Y-m';
				$time_begin = date('Y-m-01',strtotime($time_begin));
				$time_end = date('Y-m-31',strtotime($time_end));
			}elseif($unit=='day'){
				$sqlFormat = '%Y-%m-%d';
				$format = 'Y-m-d';
			}
			$data=[];
			$timeTemp = $time_begin;
			while ($timeTemp <= $time_end) {
				$u = date($format,strtotime($timeTemp));
				$d=[
					'unit'=>$u,
					'price'=>0,
					'amount'=>0
				];
				$data[]=$d;
				$timeTemp = date('Y-m-d',strtotime($timeTemp.' +1 '.$unit));
			}
			$where = $this->getWhere();
			$list = Db::table( $this->tableName )
				->alias('contract')
				->field([
					'date_format(contract.sign_date,\''.$sqlFormat.'\')'=>'unit',
					'ifnull(sum(contract.price),0)'=>'price',
					'count(*)'=>'amount',
				])
				->join('sys_company company','contract.company_id = company.id')
				->join('it_supplier supplier','contract.supplier_id = supplier.id')
				->where($where)
				->where('contract.sign_date','>=',$time_begin)
				->where('contract.sign_date','<=',$time_end)
				->group('date_format(contract.sign_date,\''.$sqlFormat.'\')')
				->select();
			foreach($data as &$d){
				foreach($list as $item){
					if($d['unit']==$item['unit']){
						$d['price'] = $item['price'];
						$d['amount'] = $item['amount'];
						break;
					}
				}
			}
			$res->data = $data;
			$res->code = 0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	public function uploadAttach($id){
		return action('Attach/upload',['table_name'=>'it_contract','table_id'=>$id]);
	}
	public function delAttach($id){
		return action('Attach/del',['id'=>$id]);
	}
}