<?php
namespace app\api\controller;
use think\Db;
//登录
class Login{
	public function validate($username,$password){
		$request=request();
		if($request->isPost()){
			$res=model('Res');
			try{			
				$user=Db::table('sys_user')->where('login_name',$username)->find();
				if(!$user) {
					//$res->code=1;
					throw new \Exception('用户名不存在');
				}
				if($user['id']!=-1){
					$value = Db::table('sys_config')->where('key','login')->value('value');
					if($value=='off'){
						throw new \Exception('升级正在升级中，暂时无法登录。');
					}
				}
				if($user['pwd']!==$password){
					//$res->code=2;
					throw new \Exception('密码错误');
				}
				session('user_id',$user['id']);
				Db::table('sys_user')->where('id',$user['id'])->setField('last_login_time',date('Y-m-d H:i:s'));
				Db::table('sys_user_login_log')->insertGetId([
					'user_id'=>$user['id'],
					'login_time'=>date('Y-m-d H:i:s'),
					'ip'=>request()->ip()
				]);
				$res->code=0;
			}catch(\Exception $e){
				$res->message=$e->getMessage();
			}
			return json($res);
		}
	}

	public function logout(){
		$res=model('Res');
		try{
			session(null);
			$res->code=0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}
	public function test(){
		$arr_task=Db::table('prod_send_task')->select();
		foreach ($arr_task as $task) {
			$car=Db::table('prod_send_task_car')->where('task_id',$task['id'])->order('id')->find();
			if($car){
				Db::table('prod_send_task')->where('id',$task['id'])->setField('arrange_time',$car['create_time']);
			}
			
			$arr_car[]=$car;
		}
		
		Db::table('prod_send_task')->where('state','SUBMIT')->setField('state','RECEIVE');
		return $count;
	}

	private function _messageNotice($user,$title,$content){
		$qywx=new \Libs\WxApi;
		if(is_array($user)){
			$user=implode("|",$user);
		}
	}
	public function test2(){
		set_time_limit(0);
		$ht=new \HttpTool;
		$post=[
			'form'=>[
				'wsiteGuid'=>'htqbhm',
				'pageId'=>'7',
				'elemId'=>'68',
				'name'=>'标题'
			]
		];
		$str_post=http_build_query($post);
		$count=500;
		for($i=1;$i<=$count;$i++){
			$ht->httpsPost('res.rrxiu.net/interactData/add',$str_post);
		}		
		echo $count;
	}
}