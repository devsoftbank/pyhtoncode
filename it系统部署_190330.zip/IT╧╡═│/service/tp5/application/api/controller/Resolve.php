<?php
namespace app\api\controller;
use think\Db;
use app\api\controller\Auth;

class Resolve extends Auth {
	/**
	* 获取处理日志
	* @param 
	*/
	public function getList() {
		$res=model('Res');
		try{
			$res->data=Db::table('fh_resolve')->alias('t1')->field('t1.*,p.project_name,p.project_no')->join('fh_project p','t1.project_id=p.id')->order('t1.update_time desc')->select();
			$res->code=0;
		}catch(\Exception $e){
			$res->message=$e->getMessage();
		}
		return json($res);
	}

	/**
	* 获取处理日志
	* @param 
	*/
	public function create() {
		$res=model('Res');
		try{
			$post=input('post.');
			$post['create_time'] = $post['update_time'] = date('Y-m-d H:i:s');
			$id=Db::table('fh_resolve')->field('id',true)->insertGetId($post);
			$res->data=$id;
			$res->code=0;
		}catch(\Exception $e){
			$res->message = $e->getMessage();
		}
		return json($res);
	}

	/**
	* 更新处理日志
	* @param 
	*/
	public function update($id) {
		$res=model('Res');
		try{
			$post=input('post.');
			$post['update_time'] = date('Y-m-d H:i:s');
			Db::table('fh_resolve')->field('create_time',true)->update($post);
			$res->code=0;
		}catch(\Exception $e){
			$res->message = $e->getMessage();
		}
		return json($res);
	}

	/**
	* 删除处理日志
	* @param $id 处理日志id
	*/
	public function del($id) {
		$res=model('Res');
		try{
			Db::table('fh_resolve')->delete($id);
			$res->code=0;
		}catch(\Exception $e){
			$res->message = $e->getMessage();
		}
		return json($res);
	}
}