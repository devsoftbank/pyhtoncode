<?php
namespace app\api\controller;
use think\Db;
use app\api\controller\Auth;

class Wx  {
	public function a(){
		$qywx=new \Qywx;
		$user=$qywx->getAuthUser();

		if(false===$user) exit($qywx->errmsg);
		$errorUrl = MOBILE_URL.'#/error/';
		if(!isset($user['UserId'])){
			$url = $errorUrl.'当前用户非企业员工';
			header("Location:".$url.'?t='.time());
			exit;
		}
		$user_id=\think\Db::table('sys_user')->where('qywx_user',$user['UserId'])->value('id');

		if(!$user_id){
			$url = $errorUrl.'当前用户非管理人员';
			header("Location:".$url.'?t='.time());
			exit;
		}
		session('qywx_user_id',$user['UserId']);
		session('user_id',$user_id);
		$url = cookie('last_url');
		header("Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0"); // HTTP/1.1
		header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past
		header("Pragma: no-cache"); 
		header("Location:".$url.'?t='.time());
		exit;
		//header("Location:http://www.baidu.com");
		//exit;
		//exit($url);
	}
}