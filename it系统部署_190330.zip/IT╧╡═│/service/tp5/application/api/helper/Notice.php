<?php
namespace app\api\helper;
use think\Db;

class Notice{
	public function sendMail($code,$id){
		$mail = Db::table('sys_mail')->where('id','DEFAULT')->find();
		if($mail['mail']){
			$template = Db::table('sys_mail_template')->where('id',$code)->where('is_disabled',0)->find();
			if($template){
				switch($template['id']){
					case 'IT_ASSET_USE':
						$record = Db::table('it_asset_use_record')->where('id',$id)->find();
						$employee = Db::table('hr_employee')->where('id',$record['employee_id'])->find();
						if($employee['mail']){
							$assetList = Db::table('it_asset_use_record_detail')
								->alias('detail')
								->field([
									'detail.amount',
									'asset.no',
									'asset.model',
								])
								->join('it_asset asset','asset.id = detail.asset_id')
								->where('detail.record_id',$id)
								->select();
							$assetListContent = '<table border="1" cellspacing="0"></tr><th>资产编号</th><th>资产型号</th><th>领用数量</th></tr>';
							foreach ($assetList as $asset) {
								$assetListContent .='<tr><td>'.$asset['no'].'</td><td>'.$asset['model'].'</td><td>'.$asset['amount'].'</td></tr>';
							}
							$assetListContent.='</table>';
							$mailTitle = str_replace([
								'[no]',
								'[user]',
								'[date]',
								'[place]',
								'[remarks]',
							],[
								$record['no'],
								$employee['name'],
								$record['record_date'],
								$record['place'],
								$record['remarks']
							],$template['title_template']);
							$mailContent = str_replace([
								'[no]',
								'[user]',
								'[date]',
								'[place]',
								'[remarks]',
								'[asset_list]',
								"\n"
							],[
								$record['no'],
								$employee['name'],
								$record['record_date'],
								$record['place'],
								$record['remarks'],
								$assetListContent,
								'<br/>'
							],$template['content_template']);
							sendMail($mail,[
								'mail'=>$employee['mail'],
								'title'=>$mailTitle,
								'content'=>$mailContent
							]);
						}
						break;
					case 'IT_ASSET_RETURN':
						$record = Db::table('it_asset_use_record')->where('id',$id)->find();
						$returnList = Db::table('it_asset_use_record_detail')
							->field([
								'employee_id',
								'GROUP_CONCAT(id)'=>'ids'
							])
							->where('record_id',$record['id'])
							->group('employee_id')
							->select();
							// dump($returnList);
						foreach ($returnList as $item) {
							$employee = Db::table('hr_employee')->where('id',$item['employee_id'])->find();
							if($employee['mail']){
								$assetList = Db::table('it_asset_use_record_detail')
									->alias('detail')
									->field([
										'abs(sum(detail.amount))'=>'amount',
										'asset.no',
										'asset.model',
									])
									->join('it_asset asset','asset.id = detail.asset_id')
									->where('detail.id','in',$item['ids'])
									->where('detail.record_id',$record['id'])
									->group('asset_id')
									->select();
								$assetListContent = '<table border="1" cellspacing="0"></tr><th>资产编号</th><th>资产型号</th><th>交还数量</th></tr>';
								foreach ($assetList as $asset) {
									$assetListContent .='<tr><td>'.$asset['no'].'</td><td>'.$asset['model'].'</td><td>'.$asset['amount'].'</td></tr>';
								}
								$assetListContent.='</table>';
								$mailTitle = str_replace([
									'[no]',
									'[user]',
									'[date]',
									'[place]',
									'[remarks]',
								],[
									$record['no'],
									$employee['name'],
									$record['record_date'],
									$record['place'],
									$record['remarks']
								],$template['title_template']);
								$mailContent = str_replace([
									'[no]',
									'[user]',
									'[date]',
									'[place]',
									'[remarks]',
									'[asset_list]',
									"\n"
								],[
									$record['no'],
									$employee['name'],
									$record['record_date'],
									$record['place'],
									$record['remarks'],
									$assetListContent,
									'<br/>'
								],$template['content_template']);
								sendMail($mail,[
									'mail'=>$employee['mail'],
									'title'=>$mailTitle,
									'content'=>$mailContent
								]);
							}
						}
						
						break;
				}		
			}
		}	
	}
	public function sendQywxMessage($code,$data){
		$message = Db::table('sys_message')->where('is_disabled',0)->where('code',$code)->find();
		if($message&&$message['user']){
			switch($code){
				//IT资产入库
				case 'IT_ASSET_CREATE':
					$qywxList = Db::table('sys_user')
						->where('login_name','in',$message['user'])
						->where('FIND_IN_SET('.$data['company_id'].',company_ids)')
						->where('qywx_user','not null')
						->column('qywx_user');
					if($qywxList){
						$typeName = Db::table('it_asset_type')->where('id',$data['type_id'])->value('name');
						$companyName = Db::table('sys_company')->where('id',$data['company_id'])->value('name');
						$notice['to']['touser']=implode('|',$qywxList);
						$notice['content']['title']='有新的IT资产入库';
						$notice['content']['description']=
							'<div>资产编号：'.$data['no'].'</div><div>资产型号：'.$data['model'].'</div><div>资产类型：'.$typeName.'</div><div>所属公司：'.$companyName.'</div><div>入库日期：'.$data['inbound_date'].'</div><div>入库数量：'.$data['amount'].'</div><div>来源方式：'.$data['source'].'</div><div>资产价格：￥'.$data['price'].'</div><div></div><div>录入员：'.$data['create_user_name'].'</div>';
						$notice["content"]["url"] = MOBILE_URL.'#/it/asset/details/'.$data['id'];
						$qywx=new \Qywx;
						if($qywx->sendCard($notice,1000011) == false){
							throw new \Exception( $qywx->errmsg );
						}
					}
					break;
				//IT资产入库
				case 'IT_CONTRACT_CREATE':
					$qywxList = Db::table('sys_user')
						->where('login_name','in',$message['user'])
						->where('FIND_IN_SET('.$data['company_id'].',company_ids)')
						->where('qywx_user','not null')
						->column('qywx_user');
					if($qywxList){
						$supplierName = Db::table('it_supplier')->where('id',$data['supplier_id'])->value('name');
						$companyName = Db::table('sys_company')->where('id',$data['company_id'])->value('name');
						$notice['to']['touser']=implode('|',$qywxList);
						$notice['content']['title']='有新的IT部门合同创建';
						$notice['content']['description']=
							'<div>合同编号：'.$data['no'].'</div><div>合同名称：'.$data['name'].'</div><div>合作商：'.$supplierName.'</div><div>所属公司：'.$companyName.'</div><div>合同金额：￥'.$data['price'].'</div><div>签订日期：'.$data['sign_date'].'</div><div>生效日期：'.$data['begin_date'].'</div><div>失效日期：'.$data['end_date'].'</div><div></div><div>录入员：'.$data['create_user_name'].'</div>';
						$notice["content"]["url"] = MOBILE_URL.'#/it/contract/details/'.$data['id'];
						$qywx=new \Qywx;
						if($qywx->sendCard($notice,1000011) == false){
							throw new \Exception( $qywx->errmsg );
						}
					}
					break;
			}
			
		}
	}
}

