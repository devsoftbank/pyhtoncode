<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件

function test(){
	return '123';
}

/**
* 导出excel
* @param $data 要导出的数据
* @param $fields 字段名及标题，类似这样的数组['name'=>'名称']
* @param $title 工作表标题及导出文件名称
*/
function exportExcel($data,$fields,$title='导出列表'){
	$objPHPExcel = new \PHPExcel();
	$sheet = $objPHPExcel->getActiveSheet();
	$sheet->setTitle($title);// 设置工作表标题
	//excel列字母
	$letters=['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ', 'AK', 'AL', 'AM', 'AN', 'AO', 'AP', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AV', 'AW', 'AX', 'AY', 'AZ'];		
	//设置标题
	// for($i=0;$i<count($fields);$i++){
	// 	$sheet->setCellValue($letters[$i].'1', $title[$i]);
	// }
	$letterIndex=0;
	foreach($fields as $k=>$t){
		$sheet->setCellValue($letters[$letterIndex].'1', $t);
		$letterIndex++;
	}
	foreach($data as $i=>$item){
		$letterIndex=0;
		foreach($fields as $k=>$t){
			$sheet->setCellValue($letters[$letterIndex].($i+2),$item[$k]);
			$letterIndex++;
		}
	}		
	//告诉浏览器输出07Excel文件
	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	//header('Content-Type:application/vnd.ms-excel');//告诉浏览器将要输出Excel03版本文件
	$filename=$title.date('YmdHis');
	header('Content-Disposition: attachment;filename="'.$filename.'.xlsx"');;//告诉浏览器输出浏览器名称
	header('Cache-Control: max-age=0');//禁止缓存
	$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');//生成excel07版本
	//$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');//生成excel03版本
	$objWriter->save('php://output');
	exit;
}
/**
* 导入excel并返回数组
* @param $name 上传文件的name值
*/
function importExcel($beginRow=2,$dateColumn=[],$name='file'){
	$file = request()->file($name);
	$filename = $file->getPathName();
	$excel = \PHPExcel_IOFactory::load($filename); 		
	$sheet = $excel->getSheet(0);
	$row = $sheet->getHighestRow();		
	$column = $sheet->getHighestColumn();	
	$data = [];	
	for($r=$beginRow;$r<=$row;$r++){
		$d=[];
		for($c='A';$c<=$column;$c++){
			$cell = $sheet->getCell($c.$r);
			$value = $cell->getValue();
			// if(in_array($c,$dateColumn)){
			// 	$value = date("Y-m-d",\PHPExcel_Shared_Date::ExcelToPHP($value));
			// }
			if($cell->getDataType()==\PHPExcel_Cell_DataType::TYPE_NUMERIC){  
        $cellstyleformat = $cell->getStyle($cell->getCoordinate())->getNumberFormat();
        $formatcode = $cellstyleformat->getFormatCode(); 
        if (preg_match('/^(\[\$[A-Z]*-[0-9A-F]*\])*[hmsdy]/i', $formatcode)) {  
          $value = gmdate("Y-m-d", \PHPExcel_Shared_Date::ExcelToPHP($value));  
        }else{  
          $value=\PHPExcel_Style_NumberFormat::toFormattedString($value,$formatcode);
        }  
     }
			$d[] = $value;
		}
		$data[] = $d;
	}
	return ($data);
}

/**
* 导出excel
* @param $data 要导出的数据
* @param $fields 字段名及标题，类似这样的数组['name'=>'名称']
* @param $title 工作表标题及导出文件名称
*/
function getUploadFileError( ){
	$file=$_FILES['file'];
	if(($file_err=$file['error'])>0){
		$err_msg='';
		switch ($file_err) {
			case 1:
				$err_msg='上传文件大小超过服务器允许上传的最大值';
				break;
			case 2:
				$err_msg='上传文件大小超过HTML表单中隐藏域MAX_FILE_SIZE选项指定的值';
				break;
			case 3:
				$err_msg='文件只有部分被上传';
				break;
			case 6:
				$err_msg='没有找不到临时文件夹';
				break;
			case 7:
				$err_msg='文件写入失败';
				break;
			case 8:
				$err_msg='php文件上传扩展没有打开';
				break;
		}
		return $err_msg;
	}else{
		return false;
	}
}

/**
* 上传附件
* @param $name 上传name值
*/
function uploadAttach($name='file'){
	if($error = getUploadFileError()){
		throw new \Exception($error);
	}
	$file = request()->file($name);
	if($file){
		$info = $file->validate(['size'=>10*1024*1024 ])->move(WEB_PATH . 'upload' . DS . 'attach');
		if($info){
			$data = [
				'name'=>$info->getInfo()['name'],
				'size'=>$info->getSize(),
				'ext'=>$info->getExtension(),
				'save_name'=>$info->getSaveName(),
				'upload_user'=>session('user_id'),
				'upload_time'=>date('Y-m-d H:i:s')
			];
			$id = think\Db::table('attach')->insertGetId($data);
			$data['id'] = $id;
			return $data;
		}else{
			// 上传失败获取错误信息
			throw new \Exception($file->getError());
		}
	}else{
		throw new \Exception('检测不到上传文件！');
	}
}

/**
* 上传附件
* @param $name 
*/
function delAttach($attach_id){
	$attach = think\Db::table('attach')->find($attach_id);
	think\Db::table('attach')->delete($attach_id);
	$file = WEB_PATH . 'upload' . DS . 'attach'.DS.$attach['save_name'];
	if(file_exists($file)){
		if(false===unlink($file)) throw new \Exception("附件删除失败！");
	}
}
/**
* 输出二维码图片
* @param $content表示生成二位的的信息文本；参数$outfile表示是否输出二维码图片 文件，默认否；参数$level表示容错率，也就是有被覆盖的区域还能识别，分别是 L（QR_ECLEVEL_L，7%），M（QR_ECLEVEL_M，15%），Q（QR_ECLEVEL_Q，25%），H（QR_ECLEVEL_H，30%）； 参数$size表示生成图片大小，默认是3；参数$margin表示二维码周围边框空白区域间距值；参数$saveandprint表示是否保存二维码并 显示。
*/
function qrcodeImg($content,$l="M",$size=2.5,$border=0){
	\QRcode::png($content,false,$l,$size,$border);
	exit;
}

function sendMail($sendMail,$receiveMail){
	$mail = new \PHPMailer();
	$mail->Charset='UTF-8';
	$mail->isSMTP();                                      // Set mailer to use SMTP
	$mail->Host = $sendMail['smtp_host'];  // Specify main and backup SMTP servers
	$mail->SMTPAuth = true;                               // Enable SMTP authentication
	$mail->Username = $sendMail['user_name'];                 // SMTP username
	$mail->Password = $sendMail['password'];   // SMTP password
	if($sendMail['is_ssl']){
		$mail->SMTPSecure = 'ssl';  
	}                                                  
	$mail->Port = $sendMail['port']?$sendMail['port']:($sendMail['is_ssl']?465:25);
	$mail->setFrom($sendMail['mail'], $sendMail['sender_name']?$sendMail['sender_name']:$sendMail['mail']);
	// $mail->addAddress('joe@example.net', 'Joe User');     // Add a recipient
	$mail->addAddress($receiveMail['mail']);               // Name is optional
	// $mail->addReplyTo('info@example.com', 'Information');
	// $mail->addCC('cc@example.com');
	// $mail->addBCC('bcc@example.com');
	// $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
	// $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
	$mail->isHTML(true);                                  // Set email format to HTML
	$mail->Subject = $receiveMail['title'];
	$mail->Body    = $receiveMail['content'];
	if(!$mail->send()) {
		throw new \Exception('邮件发送失败，请检查相关参数！');
	}
}
