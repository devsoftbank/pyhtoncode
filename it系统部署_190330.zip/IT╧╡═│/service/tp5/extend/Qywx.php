<?php


class Qywx{	

	protected $_corpId;
	protected $_secret;
	protected $_http;
	public $errcode;
	public $errmsg;
	function __construct(){
		$this->_corpId='';
		$this->_secret='';
		$this->_http=new \HttpTool;
		$this->errcode=0;
	}
	//检查请求是否成功
	private function isSuccess($obj){
		if(isset($obj["errcode"])){
			if($obj["errcode"]!==0){
				$this->errcode=$obj['errcode'];
				if(array_key_exists($obj["errcode"],$this->_err)){
					$this->errmsg=$this->_err[$obj["errcode"]];
				}else{
					$this->errmsg=$obj["errmsg"];
				}
				return false;		
			}
		}
		return true;
	}
	//获取access_token
	public function getAccessToken(){
		$access_token='';
		if(!$access_token){
			$url="https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={$this->_corpId}&corpsecret={$this->_secret}";
			$res=$this->_http->httpsGet($url);
			$obj= json_decode($res,true);
			if($this->isSuccess($obj)){
				$access_token=$obj["access_token"];
				cache('qy_access_token',$access_token,$obj["expires_in"]-100);
			}else{
				return false;
			}			
		}
		return $access_token;
	}	
	private function getJsApiTicket() {
		$jsapi_ticket=S('qy_jsapi_ticket');
		if(!$jsapi_ticket){			
			$ht=new HttpTools;
			//$url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token={$this->getAccessToken()}";
			$url = "https://qyapi.weixin.qq.com/cgi-bin/get_jsapi_ticket?access_token={$this->getAccessToken()}";
			$res=$ht->httpsGet($url);
			$obj= json_decode($res,true);
			$this->isErr($obj);
			$jsapi_ticket=$obj["ticket"];
			S('qy_jsapi_ticket',$jsapi_ticket,$obj["expires_in"]-100);
		}		
		return $jsapi_ticket;
	}
	private function createNonceStr($length = 16) {
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$str = "";
		for ($i = 0; $i < $length; $i++) {
		  $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	  }
	  //获取当前完整url
	private function getCurrentUrl(){
		$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
		return "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	}
	public function getJsSignPackage(){
		$jsapiTicket = $this->getJsApiTicket();
		// 注意 URL 一定要动态获取，不能 hardcode.
		 
		$url = $this->getCurrentUrl();

		$timestamp = time();
		$nonceStr = $this->createNonceStr();

		// 这里参数的顺序要按照 key 值 ASCII 码升序排序
		$string = "jsapi_ticket=$jsapiTicket&noncestr=$nonceStr&timestamp=$timestamp&url=$url";

		$signature = sha1($string);

		$signPackage = array(
		  "appId"     => $this->_corpId,
		  "nonceStr"  => $nonceStr,
		  "timestamp" => $timestamp,
		  "url"       => $url,
		  "signature" => $signature,
		  "rawString" => $string
		);
		return $signPackage; 
	}

	//微信网页授权
	public function getAuthUser(){
		//判断链接是否code参数，否则跳转到授权链接
		if(isset($_GET["code"])){
			//取得用户id
			$user=$this->getUserIdByCode($_GET["code"]);
			//设置cookie
			//setcookie("fwauth_openid",$auth_token["openid"],time()+$auth_token["expires_in"]-200,"/");
			return $user;
		}else{
			header("Location:".$this->buildAuthUrl());
			exit;
		}
	}

	//获取身份验证链接
	public function getAuthUrl(){
		$redirect_uri=urlencode($this->getCurrentUrl());
		return "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$this->_corpId}&redirect_uri={$redirect_uri}&response_type=code&scope=snsapi_base&state=STATE#wechat_redirect";
	}
	//获取身份验证链接
	public function buildAuthUrl($url=null){
		if(!$url)
			$url=$this->getCurrentUrl();
		$redirect_uri=urlencode($url);
		return "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$this->_corpId}&redirect_uri={$redirect_uri}&response_type=code&scope=snsapi_base&state=STATE#wechat_redirect";
	}
	/************************************管理部门************************************/
	//创建部门
	public function createDep($arr_dep){
		$url="https://qyapi.weixin.qq.com/cgi-bin/department/create?access_token={$this->getAccessToken()}";
		$str_data=json_encode($arr_dep,JSON_UNESCAPED_UNICODE);
		$ht=new HttpTools;
        $res= $ht->httpsPost($url,$str_data);
		$obj= json_decode($res,true);
		$this->isErr($obj);
		return $obj["id"];
	}
	
	//修改部门
	public function updateDep($arr_dep){
		$url="https://qyapi.weixin.qq.com/cgi-bin/department/update?access_token={$this->getAccessToken()}";
		$str_data=json_encode($arr_dep,JSON_UNESCAPED_UNICODE);
		$ht=new HttpTools;
        $res= $ht->httpsPost($url,$str_data);
		$obj=json_decode($res,true);
		$this->isErr($obj);
		return true;
	}
	//删除部门
	public function delDep($id){
		$url="https://qyapi.weixin.qq.com/cgi-bin/department/delete?access_token={$this->getAccessToken()}&id=$id";
		$ht=new HttpTools;
        $res= $ht->httpsGet($url);
		$obj= json_decode($res,true);
		$this->isErr($obj);
		return true;
	}
	
	//部门列表
	public function getDepList($id=1){
		$url="https://qyapi.weixin.qq.com/cgi-bin/department/list?access_token={$this->getAccessToken()}&id=$id";
		$ht=new HttpTools;
        $res= $ht->httpsGet($url);
		$obj= json_decode($res,true);
		$this->isErr($obj);
		return $obj["department"];
	}


	/************************************管理成员************************************/
	//创建成员
	private function _createUser($arr_user){
		$url="https://qyapi.weixin.qq.com/cgi-bin/user/create?access_token={$this->getAccessToken()}";
		$str_data=json_encode($arr_user,JSON_UNESCAPED_UNICODE);
		$ht=new HttpTools;
    $res= $ht->httpsPost($url,$str_data);
		return json_decode($res,true);
	}
	//创建成员
	public function createUser($arr_user){
		$obj=$this->_createUser($arr_user);
		$this->isErr($obj);
	}
	//创建成员并判断如果存在则修改
	public function forceCreateUser($arr_user){
		$obj=$this->_createUser($arr_user);
		if($obj->errcode===60102){
			$this->updateUser($arr_user);
		}else{
			$this->isErr($obj);
		}
	}
	//修改成员
	private function _updateUser($arr_user){
		$url="https://qyapi.weixin.qq.com/cgi-bin/user/update?access_token={$this->getAccessToken()}";
		$str_data=json_encode($arr_user,JSON_UNESCAPED_UNICODE);
		$ht=new HttpTools;
        $res= $ht->httpsPost($url,$str_data);
		return json_decode($res,true);
	}
	//修改成员
	public function updateUser($arr_user){
		$obj=$this->_updateUser($arr_user);		 
		$this->isErr($obj);
		 
	}
	//修改成员
	public function forceUpdateUser($arr_user){
		$obj=$this->_updateUser($arr_user);
		if($obj->errcode===60111){
			$this->createUser($arr_user);
		}else{
			$this->isErr($obj);
		}
	}
	//删除成员
	public function delUser($userid){
		$url="https://qyapi.weixin.qq.com/cgi-bin/user/delete?access_token={$this->getAccessToken()}&userid=$userid";
		$ht=new HttpTools;
        $res= $ht->httpsGet($url);
		$obj= json_decode($res,true);
		$this->isErr($obj);
		return true;
	}
	//批量删除成员
	public function delUserList($arr_userid){
		$url="https://qyapi.weixin.qq.com/cgi-bin/user/batchdelete?access_token={$this->getAccessToken()}";
		$ht=new HttpTools;
		$list_userid=array("useridlist"=>$arr_userid);
		$str_data=json_encode($list_userid,256);
		$res= $ht->httpsPost($url,$str_data);
		$obj= json_decode($res,true);
		$this->isErr($obj);
		return true;
	}
	//获取成员详细信息
	public function getUser($userid){
		$url="https://qyapi.weixin.qq.com/cgi-bin/user/get?access_token={$this->getAccessToken()}&userid=$userid";
		$ht=new HttpTools;
        $res= $ht->httpsGet($url);
		$obj= json_decode($res,true);
		$this->isErr($obj);
		return $obj;
	}

	//根据部门获取成员简单信息
	public function getSimpleUserListByDep($dep_id,$child=0,$status=0){
		$url="https://qyapi.weixin.qq.com/cgi-bin/user/simplelist?access_token={$this->getAccessToken()}&department_id=$dep_id&fetch_child=$child&status=$status";
		$ht=new HttpTools;
        $res= $ht->httpsGet($url);
		$obj= json_decode($res,true);
		$this->isErr($obj);
		return $obj["userlist"];
	}

	//根据部门获取成员详细信息
	public function getUserListByDep($dep_id,$child=0,$status=0){
		$url="https://qyapi.weixin.qq.com/cgi-bin/user/list?access_token={$this->getAccessToken()}&department_id=$dep_id&fetch_child=$child&status=$status";
		$ht=new HttpTools;
        $res= $ht->httpsGet($url);
		$obj= json_decode($res,true);
		$this->isErr($obj);
		return $obj["userlist"];
	}
	//邀请成员关注
	public function inviteUser($userid,$message=null){
		$data=new \stdClass;
		$data->userid=$userid;
		if($message){
			$data->invite_tips=$message;
		}
		$url="https://qyapi.weixin.qq.com/cgi-bin/invite/send?access_token={$this->getAccessToken()}";
		$ht=new HttpTools;
		 
		$str_data=json_encode($data,256);
		$res= $ht->httpsPost($url,$str_data);
		$obj= json_decode($res,true);
		$this->isErr($obj);
		return $obj["type"];
	}

	/************************************管理标签************************************/
	//创建标签
	public function createTag($tag_name){
		$url="https://qyapi.weixin.qq.com/cgi-bin/tag/create?access_token={$this->getAccessToken()}";
		$str_data="{\"tagname\":\"".$tag_name."\"}";
		$ht=new HttpTools;
        $res= $ht->httpsPost($url,$str_data);
		return json_decode($res);
	}
	//修改标签
	public function updateTag($tag_id,$tag_name){
		$url="https://qyapi.weixin.qq.com/cgi-bin/tag/update?access_token={$this->getAccessToken()}";
		$str_data="{\"tagid\":$tag_id,\"tagname\":\"$tag_name\"}";
		$ht=new HttpTools;
        $res= $ht->httpsPost($url,$str_data);
		return json_decode($res);
	}
	//删除标签
	public function delTag($tag_id){
		$url="https://qyapi.weixin.qq.com/cgi-bin/tag/delete?access_token={$this->getAccessToken()}&tagid=$tag_id";
		$ht=new HttpTools;
        $res= $ht->httpsGet($url);
		return json_decode($res);
	}
	//获取标签成员[未测]
	public function getTagUserList($tag_id){
		$url="https://qyapi.weixin.qq.com/cgi-bin/tag/get?access_token={$this->getAccessToken()}&tagid=$tag_id";
		$ht=new HttpTools;
        $res= $ht->httpsGet($url);
		return json_decode($res);
	}
	//添加标签成员[未测]
	public function addTagUserList($arr_data){
		$url="https://qyapi.weixin.qq.com/cgi-bin/tag/addtagusers?access_token={$this->getAccessToken()}";
		$str_data=json_encode($arr_data,256);
		$ht=new HttpTools;
        $res= $ht->httpsPost($url,$str_data);
		return json_decode($res);
	}
	//删除标签成员[未测]
	public function delTagUserList($arr_data){
		$url="https://qyapi.weixin.qq.com/cgi-bin/tag/deltagusers?access_token={$this->getAccessToken()}";
		$str_data=json_encode($arr_data,256);
		$ht=new HttpTools;
        $res= $ht->httpsPost($url,$str_data);
		return json_decode($res);
	}
	//获取标签列表[未测]
	public function getTag(){
		$url="https://qyapi.weixin.qq.com/cgi-bin/tag/list?access_token={$this->getAccessToken()}";
		$ht=new HttpTools;
        $res= $ht->httpsGet($url);
		return json_decode($res);
	}


	public function get(){
		return	$this->getAccessToken();
	}
	public function del(){
		S('access_token',null);
	}
	
	public function getUserIdByCode($code){
		$token=$this->getAccessToken();
		if(false===$token) return false;
		$url="https://qyapi.weixin.qq.com/cgi-bin/user/getuserinfo?access_token={$token}&code={$code}";
		$res= $this->_http->httpsGet($url);
		$obj= json_decode($res,true);
		if(false===$this->isSuccess($obj)) return false;
		return $obj;
	}

	public function sendText(){
		$token=$this->getAccessToken();
		if(!$token)return false;
		$url="https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={$token}";
		$data=array(
			"msgtype"=>"text",
			"agentid"=>"0",
			"text"=>array(
				"content"=> "testtesttest"
			),
			"touser"=>"102577"
		);
		$str_data=json_encode($data,256);
		$res= $this->_http->httpsPost($url,$str_data);
		$obj= json_decode($res,true);
		if(!$this->isSuccess($obj)) return false;
		return $obj;
	}
	public function _send($data){
		$url="https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={$this->getAccessToken()}";
		$ht=new HttpTools;
		$str_data=json_encode($data,256);
		$res= $ht->httpsPost($url,$str_data);
		$obj= json_decode($res,true);
		$this->isErr($obj);
		return $obj;
	}
	public function _sendMessage($data){
		$token=$this->getAccessToken();
		if(!$token) return false;
		$url="https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={$this->getAccessToken()}";
		$str_data=json_encode($data,256);
		$res= $this->_http->httpsPost($url,$str_data);
		$obj= json_decode($res,true);
		if(!$this->isSuccess($obj)) return false;
		return true;
	}
	public function sendNotice($notice,$agentid=0){
		$data=array_merge(array(
			"msgtype"=>"news",
			"agentid"=>$agentid),$notice["to"]);
		$data["news"]=array(
				"articles"=> array(
					$notice["content"]
				)
		);
		return $this->_sendMessage($data,$agentid);
	}
	public function sendCard($notice,$agentid=0){
		$data=array_merge(array(
			"msgtype"=>"textcard",
			"agentid"=>$agentid),$notice["to"]);
		$data["textcard"]=$notice["content"];
		return $this->_sendMessage($data);
	}

	//创建标签
	public function getTempMedia($media_id){
		$url="https://qyapi.weixin.qq.com/cgi-bin/media/get?access_token={$this->getAccessToken()}&media_id={$media_id}";
		$ht=new HttpTools;
        $res= $ht->httpsGet($url);
		$obj= json_decode($res,true);
		if($obj){
			$this->isErr($obj);
		}
		return $res;
	}


	protected $_err=array(
		-1=>"系统繁忙",
		0=>"请求成功",
		40001=>"获取access_token时Secret错误，或者access_token无效",
		40002=>"不合法的凭证类型",
		40003=>"不合法的UserID",
		40004=>"不合法的媒体文件类型",
		40005=>"不合法的文件类型",
		40006=>"不合法的文件大小",
		40007=>"不合法的媒体文件id",
		40008=>"不合法的消息类型",
		40013=>"不合法的corpid",
		40014=>"不合法的access_token",
		40015=>"不合法的菜单类型",
		40016=>"不合法的按钮个数",
		40017=>"不合法的按钮类型",
		40018=>"不合法的按钮名字长度",
		40019=>"不合法的按钮KEY长度",
		40020=>"不合法的按钮URL长度",
		40021=>"不合法的菜单版本号",
		40022=>"不合法的子菜单级数",
		40023=>"不合法的子菜单按钮个数",
		40024=>"不合法的子菜单按钮类型",
		40025=>"不合法的子菜单按钮名字长度",
		40026=>"不合法的子菜单按钮KEY长度",
		40027=>"不合法的子菜单按钮URL长度",
		40028=>"不合法的自定义菜单使用成员",
		40029=>"不合法的oauth_code",
		40031=>"不合法的UserID列表",
		40032=>"不合法的UserID列表长度",
		40033=>"不合法的请求字符，不能包含\uxxxx格式的字符",
		40035=>"不合法的参数",
		40038=>"不合法的请求格式",
		40039=>"不合法的URL长度",
		40040=>"不合法的插件token",
		40041=>"不合法的插件id",
		40042=>"不合法的插件会话",
		40048=>"url中包含不合法domain",
		40054=>"不合法的子菜单url域名",
		40055=>"不合法的按钮url域名",
		40056=>"不合法的agentid",
		40057=>"不合法的callbackurl",
		40058=>"不合法的红包参数",
		40059=>"不合法的上报地理位置标志位",
		40060=>"设置上报地理位置标志位时没有设置callbackurl",
		40061=>"设置应用头像失败",
		40062=>"不合法的应用模式",
		40063=>"参数为空",
		40064=>"管理组名字已存在",
		40065=>"不合法的管理组名字长度",
		40066=>"不合法的部门列表",
		40067=>"标题长度不合法",
		40068=>"不合法的标签ID",
		40069=>"不合法的标签ID列表",
		40070=>"列表中所有标签（成员）ID都不合法",
		40071=>"不合法的标签名字，标签名字已经存在",
		40072=>"不合法的标签名字长度",
		40073=>"不合法的openid",
		40074=>"news消息不支持指定为高保密消息",
		40077=>"不合法的预授权码",
		40078=>"不合法的临时授权码",
		40079=>"不合法的授权信息",
		40080=>"不合法的suitesecret",
		40082=>"不合法的suitetoken",
		40083=>"不合法的suiteid",
		40084=>"不合法的永久授权码",
		40085=>"不合法的suiteticket",
		40086=>"不合法的第三方应用appid",
		41001=>"缺少access_token参数",
		41002=>"缺少corpid参数",
		41003=>"缺少refresh_token参数",
		41004=>"缺少secret参数",
		41005=>"缺少多媒体文件数据",
		41006=>"缺少media_id参数",
		41007=>"缺少子菜单数据",
		41008=>"缺少oauth code",
		41009=>"缺少UserID",
		41010=>"缺少url",
		41011=>"缺少agentid",
		41012=>"缺少应用头像mediaid",
		41013=>"缺少应用名字",
		41014=>"缺少应用描述",
		41015=>"缺少Content",
		41016=>"缺少标题",
		41017=>"缺少标签ID",
		41018=>"缺少标签名字",
		41021=>"缺少suiteid",
		41022=>"缺少suitetoken",
		41023=>"缺少suiteticket",
		41024=>"缺少suitesecret",
		41025=>"缺少永久授权码",
		42001=>"access_token超时",
		42002=>"refresh_token超时",
		42003=>"oauth_code超时",
		42004=>"插件token超时",
		42007=>"预授权码失效",
		42008=>"临时授权码失效",
		42009=>"suitetoken失效",
		43001=>"需要GET请求",
		43002=>"需要POST请求",
		43003=>"需要HTTPS",
		43004=>"需要成员已关注",
		43005=>"需要好友关系",
		43006=>"需要订阅",
		43007=>"需要授权",
		43008=>"需要支付授权",
		43010=>"需要处于回调模式",
		43011=>"需要企业授权",
		44001=>"多媒体文件为空",
		44002=>"POST的数据包为空",
		44003=>"图文消息内容为空",
		44004=>"文本消息内容为空",
		45001=>"多媒体文件大小超过限制",
		45002=>"消息内容超过限制",
		45003=>"标题字段超过限制",
		45004=>"描述字段超过限制",
		45005=>"链接字段超过限制",
		45006=>"图片链接字段超过限制",
		45007=>"语音播放时间超过限制",
		45008=>"图文消息超过限制",
		45009=>"接口调用超过限制",
		45010=>"创建菜单个数超过限制",
		45015=>"回复时间超过限制",
		45016=>"系统分组，不允许修改",
		45017=>"分组名字过长",
		45018=>"分组数量超过上限",
		45024=>"账号数量超过上限",
		45027=>"mpnews消息每天只能发送100次",
		46001=>"不存在媒体数据",
		46002=>"不存在的菜单版本",
		46003=>"不存在的菜单数据",
		46004=>"不存在的成员",
		47001=>"解析JSON/XML内容错误",
		48001=>"Api未授权",
		48002=>"Api禁用",
		48003=>"suitetoken无效",
		48004=>"授权关系无效",
		50001=>"redirect_uri未授权",
		50002=>"成员不在权限范围",
		50003=>"应用已停用",
		50004=>"成员状态不正确，需要成员为企业验证中状态",
		50005=>"企业已禁用",
		60001=>"部门长度不符合限制",
		60002=>"部门层级深度超过限制",
		60003=>"部门不存在",
		60004=>"父亲部门不存在",
		60005=>"不允许删除有成员的部门",
		60006=>"不允许删除有子部门的部门",
		60007=>"不允许删除根部门",
		60008=>"部门名称已存在",
		60009=>"部门名称含有非法字符",
		60010=>"部门存在循环关系",
		60011=>"管理员权限不足，（user/department/agent）无权限",
		60012=>"不允许删除默认应用",
		60013=>"不允许关闭应用",
		60014=>"不允许开启应用",
		60015=>"不允许修改默认应用可见范围",
		60016=>"不允许删除存在成员的标签",
		60017=>"不允许设置企业",
		60019=>"不允许设置应用地理位置上报开关",
		60020=>"访问ip不在白名单之中",
		60023=>"应用已授权予第三方，不允许通过分级管理员修改菜单",
		60102=>"UserID已存在",
		60103=>"手机号码不合法",
		60104=>"手机号码已存在",
		60105=>"邮箱不合法",
		60106=>"邮箱已存在",
		60107=>"微信号不合法",
		60108=>"微信号已存在",
		60109=>"QQ号已存在",
		60110=>"用户同时归属部门超过20个",
		60111=>"UserID不存在",
		60112=>"成员姓名不合法",
		60113=>"身份认证信息（微信号/手机/邮箱）不能同时为空",
		60114=>"性别不合法",
		60115=>"已关注成员微信不能修改",
		60116=>"扩展属性已存在",
		60118=>"成员无有效邀请字段（微信，邮箱，手机号）",
		60119=>"成员已关注",
		60120=>"成员已禁用",
		60121=>"找不到该成员",
		60122=>"邮箱已被外部管理员使用",
		60123=>"无效的部门id",
		60124=>"无效的父部门id",
		60125=>"部门名字长度超过限制",
		60126=>"创建部门失败",
		60127=>"缺少部门id",
		60128=>"字段不合法，可能存在主键冲突或者格式错误",
		80001=>"可信域名没有IPC备案，后续将不能在该域名下正常使用jssdk",
		82001=>"发送消息或者邀请的参数全部为空或者全部不合法",
		82002=>"不合法的PartyID列表长度",
		82003=>"不合法的TagID列表长度",
		82004=>'微信版本号过低',
84013 =>	'企业会话、客服套件已下线',
85002 =>	'包含不合法的词语',
86001 	=>'不合法的会话ID',
86003 	=>'不存在的会话ID',
86004 	=>'不合法的会话名',
86005 	=>'不合法的会话管理员',
86006 	=>'不合法的成员列表大小',
86007 	=>'不存在的成员',
86101 	=>'需要会话管理员权限',
86201 	=>'缺少会话ID',
86202 	=>'缺少会话名',
86203 	=>'缺少会话管理员',
86204 	=>'缺少成员',
86205 	=>'非法的会话ID长度',
86206 	=>'非法的会话ID数值',
86207 	=>'会话管理员不在用户列表中',
86208 	=>'消息服务未开启',
86209 	=>'缺少操作者',
86210 	=>'缺少会话参数',
86211 	=>'缺少会话类型（单聊或者群聊）',
86213 	=>'缺少发件人',
86214 	=>'非法的会话类型',
86215 	=>'会话已存在',
86216 	=>'非法会话成员',
86217 	=>'会话操作者不在成员列表中',
86218 	=>'非法会话发件人',
86219 	=>'非法会话收件人',
86220 	=>'非法会话操作者',
86221 	=>'单聊模式下，发件人与收件人不能为同一人',
86222 	=>'不允许消息服务访问的API',
86304 	=>'不合法的消息类型',
86305 	=>'客服服务未启用',
86306 	=>'缺少发送人',
86307 	=>'缺少发送人类型',
86308 	=>'缺少发送人id',
86309 	=>'缺少接收人',
86310 	=>'缺少接收人类型',
86311 	=>'缺少接收人id',
86312 	=>'缺少消息类型',
86313 	=>'缺少客服，发送人或接收人类型，必须有一个为kf',
86314 	=>'客服不唯一，发送人或接收人类型，必须只有一个为kf',
86315 	=>'不合法的发送人类型',
86316 	=>'不合法的发送人id。Userid不存在、openid不存在、kf不存在',
86317 	=>'不合法的接收人类型',
86318 	=>'不合法的接收人id。Userid不存在、openid不存在、kf不存在',
86319 	=>'不合法的客服，kf不在客服列表中',
86320 	=>'不合法的客服类型',
88001 	=>'缺少seq参数',
88002 	=>'缺少offset参数',
88003 	=>'非法seq',
90001 	=>'未认证摇一摇周边',
90002 	=>'缺少摇一摇周边ticket参数',
90003 	=>'摇一摇周边ticket参数不合法',
90004 	=>'摇一摇周边ticket过期',
90005 	=>'未开启摇一摇周边服务',
91004 	=>'卡券已被核销',
91011 	=>'无效的code',
91014 	=>'缺少卡券详情',
91015 	=>'代金券缺少least_cost或者reduce_cost参数',
91016 	=>'折扣券缺少discount参数',
91017 	=>'礼品券缺少gift参数',
91019 	=>'缺少卡券sku参数',
91020 	=>'缺少卡券有效期',
91021 	=>'缺少卡券有效期类型',
91022 	=>'缺少卡券logo_url',
91023 	=>'缺少卡券code类型',
91025 	=>'缺少卡券title',
91026 	=>'缺少卡券color',
91027 	=>'缺少offset参数',
91028 	=>'缺少count参数',
91029 	=>'缺少card_id',
91030 	=>'缺少卡券code',
91031 	=>'缺少卡券notice',
91032 	=>'缺少卡券description',
91033 	=>'缺少ticket类型',
91036 	=>'不合法的有效期',
91038 	=>'变更库存值不合法',
91039 	=>'不合法的卡券id',
91040 	=>'不合法的ticket type',
91041 	=>'没有创建，上传卡券logo，以及核销卡券的权限',
91042 	=>'没有该卡券投放权限',
91043 	=>'没有修改或者删除该卡券的权限',
91044 	=>'不合法的卡券参数',
91045 	=>'缺少团购券groupon结构',
91046 	=>'缺少现金券cash结构',
91047 	=>'缺少折扣券discount 结构',
91048 	=>'缺少礼品券gift结构',
91049 	=>'缺少优惠券coupon结构',
91050 	=>'缺少卡券必填字段',
91051 	=>'商户名称超过12个汉字',
91052 	=>'卡券标题超过9个汉字',
91053 	=>'卡券提醒超过16个汉字',
91054 	=>'卡券描述超过1024个汉字',
91055 	=>'卡券副标题长度超过18个汉字',
91058 	=>'未开通卡券服务，不允许调用卡券接口', 
	);

}