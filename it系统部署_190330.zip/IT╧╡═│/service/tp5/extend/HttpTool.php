<?php

class HttpTool{
	
	//向一个https链接发起一个get请求
	public function httpsGet($url){
		$ch=\curl_init();
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,2);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
		$res=curl_exec($ch);
		curl_close($ch);
		return $res;
	}
	//向一个https链接发起一个get请求
	public function httpGet($url){
		$ch=\curl_init();
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		$res=curl_exec($ch);
		curl_close($ch);
		return $res;
	}

	//向一个https链接发起一个post请求
	public function httpsPost($url,$data){
		$ch=\curl_init();		
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,2);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);			
		curl_setopt($ch,CURLOPT_POST,true);
		curl_setopt($ch,CURLOPT_POSTFIELDS,$data);			 
		$res=curl_exec($ch);
		curl_close($ch);
		return $res;
	}

	public function httpPost($url,$data){
		$ch=\curl_init();		
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);			
		curl_setopt($ch,CURLOPT_POST,true);
		curl_setopt($ch,CURLOPT_POSTFIELDS,$data);			 
		$res=curl_exec($ch);
		curl_close($ch);
		return $res;
	}

}