<?php

//服务号api
class Fwwx{	

	protected $_appId;
	protected $_appSecret;
	
	function __construct(){
		$this->_appId='';//服务号appId
		$this->_appSecret='';//服务号appSecret
		$this->_token='';//服务号token 回调url使用的
	}

	public function checkSignature(){
		$signature = $_GET["signature"];
		$timestamp = $_GET["timestamp"];
		$nonce = $_GET["nonce"];					
		$token = $this->_token;
		$tmpArr = array($token, $timestamp, $nonce);
		sort($tmpArr, SORT_STRING);
		$tmpStr = implode( $tmpArr );
		$tmpStr = sha1( $tmpStr );		
		if($tmpStr == $signature ){
			return true;
		}else{
			return false;
		}
	}
	
	//检查是否有错误，并throw错误
	private function isErr($obj,$method_name){
		if(isset($obj["errcode"])){
			if($obj["errcode"]!==0){
				$error_msg;
				if(array_key_exists($obj["errcode"],$this->_err)){
					$error_msg=$this->_err[$obj["errcode"]];
				}else{
					$error_msg=$obj["errmsg"];
				}				
				throw new \Exception($method_name."：".$error_msg);
			}
		}
	}
	//获取access_token
	public function getAccessToken(){
		$access_token=cache('fw_access_token');
		if(!$access_token){
			$ht=new \HttpTool;
			$url="https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={$this->_appId}&secret={$this->_appSecret}";
			$res=$ht->httpsGet($url);
			$obj= json_decode($res,true);
			$this->isErr($obj,__METHOD__);
			$access_token=$obj["access_token"];
			cache('fw_access_token',$access_token,$obj["expires_in"]-200);
		}
		return $access_token;
	}


	/**********************微信jssdk**************************/
	//获取jsapi_ticket，用于调用微信js接口
	private function getJsApiTicket() {
		$jsapi_ticket=cache('jsapi_ticket');
		if(!$jsapi_ticket){			
			$ht=new \HttpTool;
			$url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token={$this->getAccessToken()}";
			$res=$ht->httpsGet($url);
			$obj= json_decode($res,true);
			$this->isErr($obj,__METHOD__);
			$jsapi_ticket=$obj["ticket"];
			cache('jsapi_ticket',$jsapi_ticket,$obj["expires_in"]-100);
		}		
		return $jsapi_ticket;
	}

	//生成16位的随机字符
	private function createNonceStr($length = 16) {
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$str = "";
		for ($i = 0; $i < $length; $i++) {
		  $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	}

	//获取当前完整url
	private function getCurrentUrl(){
		$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
		return "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	}

	//获取js签名包
	public function getJsSignPackage($url){
		$jsapiTicket = $this->getJsApiTicket();
		// 注意 URL 一定要动态获取，不能 hardcode.	
		if(!$url)	$url = $this->getCurrentUrl(); 
		
		$timestamp = time();
		$nonceStr = $this->createNonceStr();

		// 这里参数的顺序要按照 key 值 ASCII 码升序排序
		$string = "jsapi_ticket=$jsapiTicket&noncestr=$nonceStr&timestamp=$timestamp&url=$url";

		$signature = sha1($string);

		$signPackage = array(
		  "appId"     => $this->_appId,
		  "nonceStr"  => $nonceStr,
		  "timestamp" => $timestamp,
		  "url"       => $url,
		  "signature" => $signature,
		  "rawString" => $string
		);
		return $signPackage; 
	}

	//获取微信jssdk引入html代码
	public function getJsHtml($debug=false){
		$signPackage=$this->getJsSignPackage();
		if($debug){
			$debug="true";
		}else{
			$debug="false";
		}
		$signPackage["debug"]=$debug;
		$html_str="<script type='text/javascript' src='http://res.wx.qq.com/open/js/jweixin-1.0.0.js'></script> <script type='text/javascript' > wx.config({debug: {$debug}, appId: '{$signPackage["appId"]}', timestamp: '{$signPackage["timestamp"]}', nonceStr: '{$signPackage["nonceStr"]}', signature: '{$signPackage["signature"]}', jsApiList:  ['onMenuShareTimeline', 'onMenuShareAppMessage', 'onMenuShareQQ', 'onMenuShareWeibo', 'onMenuShareQZone', 'startRecord', 'stopRecord', 'onVoiceRecordEnd', 'playVoice', 'pauseVoice', 'stopVoice', 'onVoicePlayEnd', 'uploadVoice', 'downloadVoice', 'chooseImage', 'previewImage', 'uploadImage', 'downloadImage', 'translateVoice', 'getNetworkType', 'openLocation', 'getLocation', 'hideOptionMenu', 'showOptionMenu', 'hideMenuItems', 'showMenuItems', 'hideAllNonBaseMenuItem', 'showAllNonBaseMenuItem', 'closeWindow', 'scanQRCode']});</script>";
		return $html_str;
	}
/*******************结束微信jssdk*********************/

/******************微信网页授权认证*************************/
	
	//微信网页授权，返回授权获得微信用户信息openid、access_token
	public function getAuthInfo($is_userinfo=false){
		//判断链接是否code参数，否则跳转到授权链接
		if(isset($_GET["code"])){
			//取得身份授权access_token
			$auth_token=$this->getAuthAccessToken($_GET["code"]);
			//设置cookie
			//setcookie("fwauth_openid",$auth_token["openid"],time()+$auth_token["expires_in"]-200,"/");
			return [
				"openid"=>$auth_token["openid"],
				"access_token"=>$auth_token["access_token"],
				"expires"=>$auth_token["expires_in"]
			];
		}else{
			header("Location:".$this->authUrl(null,$is_userinfo));
			exit;
		}
	}

	//微信网页授权页面，访问这个页面后，微信会跳转回redirect_uri参数所指向的网址，并带上code参数
	public function authUrl($link=null,$is_userinfo=false){
		$is_userinfo=$is_userinfo?"userinfo":"base";
		if($link){
			$redirect_uri=urlencode($link);
		}else{
			$redirect_uri=urlencode($this->getCurrentUrl());
		}
		return "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$this->_appId}&redirect_uri={$redirect_uri}&response_type=code&scope=snsapi_{$is_userinfo}&state=jg_wx#wechat_redirect";
	}

	/*通过授权页面返回的code参数获取授权access_token跟微信用户openid
	返回json结构
	{
   	"access_token":"ACCESS_TOKEN",
   	"expires_in":7200,
   	"refresh_token":"REFRESH_TOKEN",
   	"openid":"OPENID",
   	"scope":"SCOPE"
	}*/
	public function getAuthAccessToken($code){
		$ht=new \HttpTool;
		$url="https://api.weixin.qq.com/sns/oauth2/access_token?appid={$this->_appId}&secret={$this->_appSecret}&code={$code}&grant_type=authorization_code";
		$res=$ht->httpsGet($url);
		$obj= json_decode($res,true);
		$this->isErr($obj,__METHOD__);
		return $obj;
	}

	/*刷新授权access_token，用上面方法得到的refresh_token
	返回的json结构
	{
   	"access_token":"ACCESS_TOKEN",
   	"expires_in":7200,
   	"refresh_token":"REFRESH_TOKEN",
   	"openid":"OPENID",
   	"scope":"SCOPE"
	}*/
	public function refresh_token($refresh_token){
		$ht=new HttpTools;
		$url="https://api.weixin.qq.com/sns/oauth2/refresh_token?appid={$this->_appId}&grant_type=refresh_token&refresh_token={$refresh_token}";
		$res=$ht->httpsGet($url);
		$obj= json_decode($res,true);
		$this->isErr($obj,__METHOD__);
		return $obj;
	}

	/*获取用户信息，微信开发文档上写需scope为snsapi_userinfo，但发现用snsapi_base也能获取用户信息
	返回的json结构
	{
   	"openid":" OPENID",用户的唯一标识
   	" nickname": NICKNAME,用户昵称
   	"sex":"1",用户的性别，值为1时是男性，值为2时是女性，值为0时是未知
   	"province":"PROVINCE" 用户个人资料填写的省份 
   	"city":"CITY",普通用户个人资料填写的城市 
   	"country":"COUNTRY",国家，如中国为CN 
    "headimgurl":"http://wx.qlogo.cn/mmopen/g3MonUZtNHkdmzicIlibx6iaFqAc56vxLSUfpb6n5WKSYVY0ChQKkiaJSgQ1dZuTOgvLLrhJbERQQ4eMsv84eavHiaiceqxibJxCfHe/46", 
    用户头像，最后一个数值代表正方形头像大小（有0、46、64、96、132数值可选，0代表640*640正方形头像），用户没有头像时该项为空。若用户更换头像，原有头像URL将失效。 
		"privilege":[
			"PRIVILEGE1"
			"PRIVILEGE2"
    ],用户特权信息，json 数组，如微信沃卡用户为（chinaunicom） 
    "unionid": "o6_bmasdasdsad6_2sgVt7hMZOPfL" 	只有在用户将公众号绑定到微信开放平台帐号后，才会出现该字段。详见：获取用户个人信息（UnionID机制）
	}*/
	public function getAuthUserInfo($openid,$access_token){
		$ht=new \HttpTool;
		$url="https://api.weixin.qq.com/sns/userinfo?access_token={$access_token}&openid={$openid}&lang=zh_CN";
		$res=$ht->httpsGet($url);
		$obj= json_decode($res,true);
		$this->isErr($obj,__METHOD__);
		return $obj;
	}
	//创建二维码
	public function createQrcode($id){
		$arr["expire_seconds"]=604800;
		$arr["action_name"]="QR_SCENE";
		$arr["action_info"]=array("scene"=>array("scene_id"=>$id));
		$str_data=json_encode($arr,JSON_UNESCAPED_UNICODE);
		$url="https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token={$this->getAccessToken()}";
		$ht=new HttpTools;
        $res= $ht->httpsPost($url,$str_data);
		$obj= json_decode($res,true);
		$this->isErr($obj,__METHOD__);
		return file_get_contents("https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket={$obj['ticket']}");
	}
	public function createQrcode2($id){
		$arr["action_name"]="QR_LIMIT_SCENE";
		$arr["action_info"]=array("scene"=>array("scene_id"=>$id));
		$str_data=json_encode($arr,JSON_UNESCAPED_UNICODE);
		$url="https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token={$this->getAccessToken()}";
		$ht=new HttpTools;
        $res= $ht->httpsPost($url,$str_data);
		$obj= json_decode($res,true);
		$this->isErr($obj,__METHOD__);
		return file_get_contents("https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket={$obj['ticket']}");
	}
	public function getUserInfo($openid){
		$ht=new HttpTools;
		$url="https://api.weixin.qq.com/cgi-bin/user/info?access_token={$this->getAccessToken()}&openid={$openid}&lang=zh_CN";
		$res=$ht->httpsGet($url);
		$obj= json_decode($res,true);
		$this->isErr($obj,__METHOD__);
		return $obj;
	}
	
	public function createMenu($menu){
		$ht=new HttpTools;
		$url="https://api.weixin.qq.com/cgi-bin/menu/create?access_token={$this->getAccessToken()}";
		$res=$ht->httpsPost($url,$menu);
		$obj= json_decode($res,true);
		$this->isErr($obj,__METHOD__);
		return $obj;
	}

	protected $_err=array(
		-1=>"系统繁忙，此时请开发者稍候再试",
		0=>"请求成功",
		40001=>"获取access_token时AppSecret错误，或者access_token无效。请开发者认真比对AppSecret的正确性，或查看是否正在为恰当的公众号调用接口",
		40002=>"不合法的凭证类型",
		40003=>"不合法的OpenID，请开发者确认OpenID（该用户）是否已关注公众号，或是否是其他公众号的OpenID",
40004=>"不合法的媒体文件类型",
40005=>"不合法的文件类型",
40006=>"不合法的文件大小",
40007=>"不合法的媒体文件id",
40008=>"不合法的消息类型",
40009=>"不合法的图片文件大小",
40010=>"不合法的语音文件大小",
40011=>"不合法的视频文件大小",
40012=>"不合法的缩略图文件大小",
40013 =>"不合法的AppID，请开发者检查AppID的正确性，避免异常字符，注意大小写",
40014 =>"不合法的access_token，请开发者认真比对access_token的有效性（如是否过期），或查看是否正在为恰当的公众号调用接口",
40015 =>"不合法的菜单类型",
40016 =>"不合法的按钮个数",
40017 =>"不合法的按钮个数",
40018 =>"不合法的按钮名字长度",
40019 =>"不合法的按钮KEY长度",
40020 =>"不合法的按钮URL长度",
40021 =>"不合法的菜单版本号",
40022 =>"不合法的子菜单级数",
40023 =>"不合法的子菜单按钮个数",
40024 =>"不合法的子菜单按钮类型",
40025 =>"不合法的子菜单按钮名字长度",
40026 =>"不合法的子菜单按钮KEY长度",
40027 =>"不合法的子菜单按钮URL长度",
40028 =>"不合法的自定义菜单使用用户",
40029 =>"不合法的oauth_code",
40030 =>"不合法的refresh_token",
40031 =>"不合法的openid列表",
40032 =>"不合法的openid列表长度",
40033 =>"不合法的请求字符，不能包含\uxxxx格式的字符",
40035 =>"不合法的参数",
40038 =>"不合法的请求格式",
40039 =>"不合法的URL长度",
40050 =>"不合法的分组id",
40051 =>"分组名字不合法",
40117 =>"分组名字不合法",
40118 =>"media_id大小不合法",
40119 =>"button类型错误",
40120 =>"button类型错误",
40121 =>"不合法的media_id类型",
40132 =>"微信号不合法",
41001 =>"缺少access_token参数",
41002 =>"缺少appid参数",
41003 =>"缺少refresh_token参数",
41004 =>"缺少secret参数",
41005 =>"缺少多媒体文件数据",
41006 =>"缺少media_id参数",
41007 =>"缺少子菜单数据",
41008 =>"缺少oauth code",
41009 =>"缺少openid",
42001 =>"access_token超时，请检查access_token的有效期，请参考基础支持-获取access_token中，对access_token的详细机制说明",
42002 =>"refresh_token超时",
42003 =>"oauth_code超时",
43001 =>"需要GET请求",
43002 =>"需要POST请求",
43003 =>"需要HTTPS请求",
43004 =>"需要接收者关注",
43005 =>"需要好友关系",
44001 =>"多媒体文件为空",
44002 =>"POST的数据包为空",
44003 =>"图文消息内容为空",
44004 =>"文本消息内容为空",
45001 =>"多媒体文件大小超过限制",
45002 =>"消息内容超过限制",
45003 =>"标题字段超过限制",
45004 =>"描述字段超过限制",
45005 =>"链接字段超过限制",
45006 =>"图片链接字段超过限制",
45007 =>"语音播放时间超过限制",
45008 =>"图文消息超过限制",
45009 =>"接口调用超过限制",
45010 =>"创建菜单个数超过限制",
45015 =>"回复时间超过限制",
45016 =>"系统分组，不允许修改",
45017 =>"分组名字过长",
45018 =>"分组数量超过上限",
46001 =>"不存在媒体数据",
46002 =>"不存在的菜单版本",
46003 =>"不存在的菜单数据",
46004 =>"不存在的用户",
47001 =>"解析JSON/XML内容错误",
48001 =>"api功能未授权，请确认公众号已获得该接口，可以在公众平台官网-开发者中心页中查看接口权限",
50001 =>"用户未授权该api",
50002 =>"用户受限，可能是违规后接口被封禁",
61451 =>"参数错误(invalid parameter)",
61452 =>"无效客服账号(invalid kf_account)",
61453 =>"客服帐号已存在(kf_account exsited)",
61454 =>"客服帐号名长度超过限制(仅允许10个英文字符，不包括@及@后的公众号的微信号)(invalid kf_acount length)",
61455 =>"客服帐号名包含非法字符(仅允许英文+数字)(illegal character in kf_account)",
61456 =>"客服帐号个数超过限制(10个客服账号)(kf_account count exceeded)",
61457 =>"无效头像文件类型(invalid file type)",
61450 =>"系统错误(system error)",
61500 =>"日期格式错误",
61501 =>"日期范围错误",
9001001 =>"POST数据参数不合法",
9001002 =>"远端服务不可用",
9001003 =>"Ticket不合法",
9001004 =>"获取摇周边用户信息失败",
9001005 =>"获取商户信息失败",
9001006 =>"获取OpenID失败",
9001007 =>"上传文件缺失",
9001008 =>"上传素材的文件类型不合法",
9001009 =>"上传素材的文件尺寸不合法",
9001010 =>"上传失败",
9001020 =>"帐号不合法",
9001021 =>"已有设备激活率低于50%，不能新增设备",
9001022 =>"设备申请数不合法，必须为大于0的数字",
9001023 =>"已存在审核中的设备ID申请",
9001024 =>"一次查询设备ID数量不能超过50",
9001025 =>"设备ID不合法",
9001026 =>"页面ID不合法",
9001027 =>"页面参数不合法",
9001028 =>"一次删除页面ID数量不能超过10",
9001029 =>"页面已应用在设备中，请先解除应用关系再删除",
9001030 =>"一次查询页面ID数量不能超过50",
9001031 =>"时间区间不合法",
9001032 =>"保存设备与页面的绑定关系参数错误",
9001033 =>"门店ID不合法",
9001034 =>"设备备注信息过长",
9001035 =>"设备申请参数不合法",
9001036 =>"查询起始值begin不合法" 
	);

}